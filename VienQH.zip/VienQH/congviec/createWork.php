        <div class="col-md-12 col-sm-12 col-xs-12">

            <div class="panel panel-default">
                <div class="panel-heading">
                    Tạo mới công việc
                </div> 
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    
                                    <th>Tên công việc</th>
                                    <th>Nội dung công việc</th>
                                    <th>Nơi nhận</th>
                                    <th>Trích yếu</th>
                                    <th>Loại công việc</th>
									<th>File đính kèm</th>
									<th>Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody>  
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>