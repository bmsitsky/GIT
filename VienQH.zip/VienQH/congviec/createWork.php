<?php
	session_start();
	$tencongviec = $_SESSION['tencongviec'];
	$trangthai = $_SESSION['trangthai'];
	$mota = $_SESSION['mota'];
	$noisanxuat = $_SESSION['noisanxuat'];
	$ngaytaocv = $_SESSION['ngaytaocv'];
	//$ngaytao_ = $_REQUEST['ngaytao'];
	$thoihan = $_SESSION['thoihan'];
	$maphonguser = $_SESSION['MaphongUser'];
	$noinhan = $_SESSION['noinhan'];
	$currentID = $_SESSION['idlogin'];
	$target = $_REQUEST['target'];
	$type = $_REQUEST['type'];
	
	$link = "congviec/createProcess.php";
	if ($type == "chuyentiep"){
		$target = "nothing";
		$link = "congviec/chuyentiep.php";
	}
	if ($type == "tuychon"){
		$target = "nothing";
		$link = "congviec/bangiao.php";
	}	
	
	$idcongviec = $_REQUEST['idcv'];
	
	$idGoc = '';
	$manguoiduyet='';
	if(!empty($_REQUEST['maduyet']))
	$manguoiduyet = $_REQUEST['maduyet'];
	if (!empty($_REQUEST['id']))
	$idGoc = $_REQUEST['id'];
	if ($idGoc == '') $tieude = "Thông tin công việc";
	else $tieude = "Phản hồi công việc gốc có MCV = ".$idGoc;
	if ($type == "chuyentiep"){
		$tieude = "Chuyển tiếp công việc có MCV = ".$idcongviec;
	}
	if ($type == "tuychon"){
		$tieude = "Bàn giao công việc có MCV = ".$idcongviec;
	}	
	//$maphongnhan = $_SESSION['maphongnhan'];
?>
		<div class="uplaoder-container__container___1JPbU" style = "width: 100%; padding-top: 60px;">		
		<div id="page-inner">
                <div class="row">
				  <div class="col-md-12 col-sm-12 col-xs-12 text-center" >
				  	<label class=" control-label col-sm-122" ><h3><b><?php echo $tieude; ?></b></h3></label>
				  </div><br><br>
            
			<div class="col-md-7 col-sm-12 col-xs-12" style = "padding-top: 60px;">

			<form class="form-horizontal" name="Myform" id="Myform" action= "<?php echo $link; ?>" method="post" enctype="multipart/form-data" accept-charset="utf-8">

		  <div class="form-group">
			<label class="control-label col-sm-2" for="product-name">Tên công việc:</label>
			<div class="col-sm-10">
			<?php 
				if (!empty($target)){
			$findName = mysqli_query ($con, "select `Tên công việc` from `Công việc` where `Mã công việc` = '$idGoc'");
			list($targetName) = mysqli_fetch_array($findName);
			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">'.$targetName.'</p>';
			echo '<input type ="hidden" name ="tencongviec" value = "'.$targetName.'"/>';
			} else {
				echo '<input name = "tencongviec" id="tencongviec" type="text" value ="'.$tencongviec.'" required="">';
			}
			?>
			  
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-sm-2" for="product-name">Mô tả công việc:</label>
			<div class="col-sm-10">
			<?php
			
			if (!empty($target)){
			$findName = mysqli_query ($con, "select `Mô tả` from `Công việc` where `Mã công việc` = '$idGoc'");
			list($targetName) = mysqli_fetch_array($findName);
			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">'.$targetName.'</p>'
			.'<input type ="hidden" name ="mota" value = "'.$targetName.'"/>';
	
			} else {
			echo '<input class="form-control" name = "mota" id="mota" type="text" value ="'.$mota.'" required="">';
			}
			?>			  
			</div>
		  </div>

	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-10">
		<table width ="100%">
		<tr>
		<?php
		if ($type != "chuyentiep" && $type != "tuychon"){
			echo '
		<td width = "20%" align ="left">
			<div style="display: inline-block; position: relative;">
			<button class="btn btn-primary" tabindex="0" type="button" style ="bottom:0;">
				<span class="MuiButton-label">Thêm mới</span>
			</button>
			<input id="703c5a21-b86b-4842-95d4-7a06c4ac7fc0" onchange ="onClickHandler(\'add\')" name ="add" type="file" 
					style="bottom: 0px; height: 100%; left: 0px; margin: 0px; opacity: 0; padding: 0px; position: absolute; right: 0px; top: 0px; width: 100%;">
			</div>
			</td><td width = "20%" align ="left" id ="dk0">
			<div style="display: inline-block; position: relative;" id = "dinhkem0">
			<button class="btn btn-primary" tabindex="0" type="button" style ="bottom:0;">
				<span class="MuiButton-label">Đính kèm</span>

			</button>
			<input id="'.$count.'" onchange ="onClickHandler(\'attach\',\''.$count.'\')" onclick ="createAttach(\''.$count.'\')" class="react-fine-uploader-file-input" name = "attach" type="file" 
					style="bottom: 0px; height: 100%; left: 0px; margin: 0px; opacity: 0; padding: 0px; position: absolute; right: 0px; top: 0px; width: 100%;">
			</div>
			</td>';
		}
			?>
			<td align = "right" id = "send0">
	<?php
	if (!empty($target) && $target != "nothing"){
	$findName = mysqli_query ($con, "select pb.`Tên phòng` from user INNER JOIN `Phòng ban` pb 
								ON user.`Mã phòng` = pb.`Mã phòng` where `Mã nhân viên` = '$target'");
	list($targetName) = mysqli_fetch_array($findName);
	echo "Gửi đến: ".$targetName;
	echo '<input type ="hidden" name ="noinhan" value = "'.$target.'"/>';
	} else {
	echo "<select class='form-control' style='width: 130px;' name='noinhan' id='noinhan0' onchange=\"createSend('".$send."')\" onkeydown='HideError()'>";
	echo "<option value=''>Gửi đến</option>";
	$sql = mysqli_query ($con, "select * from user INNER JOIN `Phòng ban` pb 
								ON user.`Mã phòng` = pb.`Mã phòng` where user.`Mã chức vụ` = '01' or user.`Mã chức vụ` = 'PVT' or user.`Mã chức vụ` = 'VT' or user.`Mã phòng` = '$maphonguser'") or die(mysqli_error());
	while($row = mysqli_fetch_array($sql)){
	$idUser = $row['Mã nhân viên'];
	$sendtoUser = $row['Họ tên'];
	$sendtoPhong = $row['Tên phòng'];
	if ($idUser == $currentID){
		$sendtoUser = "Tôi";
	} else {
	if ($row['Mã chức vụ'] == '01'){
		$sendtoUser = $sendtoPhong;
	}
	//	if ($row['Mã chức vụ'] == '02'){
	//	$sendtoUser = 'Phó phòng '.$sendtoPhong;
	//}
	if ($row['Mã chức vụ']=='PVT'){
		$sendtoUser = 'Phó Viện Trưởng';
	}
		if ($row['Mã chức vụ']=='VT'){
		$sendtoUser = 'Viện Trưởng';
	}
	}
	$select	= "";
	if ($noinhan == $idUser){
		$select = " selected";  
		//$maphongnhan = $row['Mã phòng'];
	}
	echo '<option style="color:black;" value="'.$idUser.'"'.$select.'>'.$sendtoUser.'</option>';
	}
	echo "</select>";
	}
					
	?>
			</td></tr>
			</table>
		</div>
	</div>
	
	<div class="form-group">
	<div class="col-sm-offset-2 col-sm-10">
		<table width ="100%"><tr>
		<?php
		if ($type != "chuyentiep" && $type != "tuychon"){
			echo '
		<td width = "20%" style ="padding-right:60px;">
				<div class="progress">
				<div class="progress-bar progress-bar-striped active" id="add" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="color: #F5F5F5; width:0%;">
				</div>
				</div>
		</td>
		<td width = "20%" style ="padding-right:60px;">	
				<div class="progress">
				<div class="progress-bar progress-bar-striped active" id="attach" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="color: #F5F5F5; width:0%;">
				</div>
				</div>
		</td>';
		}
		?>
		<td align ="right"><button name="submit" type="submit"  class="btn btn-success" id="upload">Gửi đi</button></td>		
		</tr></table>
		</div>			
	</div>

	</div>

    <div class="col-md-5 col-sm-12 col-xs-12" style = "padding-top: 60px;">
		
		<div class="form-group">
			<label class="control-label col-sm-4" for="product-name">Trạng thái</label>
			<div class="col-sm-8">
			
			<?php 
			if ($type == "chuyentiep"){

			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">Giao việc</p>';
			echo '<input type ="hidden" name ="trangthai" value = "Giao việc"/>';
			} if ($type == "tuychon"){

			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">Đã xong</p>';
			echo '<input type ="hidden" name ="trangthai" value = "Đã xong"/>';
			} if (!empty($target) && $target != "nothing" && $type != "tuychon" && $type != "chuyentiep" && $currentID != $manguoiduyet) {
				echo '<select class="form-control" style="width: 130px; height: 32px;" name="trangthai" id="trangthai" onkeydown="HideError()">
						<option value="Đã xong" selected>Đã xong</option>
						<option value="Giao việc">Giao việc</option>
						<option value="Chưa đạt">Chưa đạt</option>						
						</select>';
			} else {
				echo '<select class="form-control" style="width: 130px; height: 32px;" name="trangthai" id="trangthai" onkeydown="HideError()">
						<option value="Giao việc" selected>Giao việc</option>
						<option value="Chưa đạt">Chưa đạt</option>
						<option value="Đã xong">Đã xong</option>																	
						</select>';
			} 
			?>			
			  
			</div>
		 </div>
		 <div class="form-group">
			<label class="control-label col-sm-4" for="product-name">Nơi sản xuất chính</label>
			<div class="col-sm-8">			  
			  <?php
		if (!empty($target)){
	$findName = mysqli_query ($con, "select `Nơi sản xuất` from `Công việc` where `Mã công việc` = '$idGoc'");
	list($targetName) = mysqli_fetch_array($findName);
	echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">'.$targetName.'</p>'
	.'<input type ="hidden" name ="noisanxuat" value = "'.$targetName.'"/>';
	
	} else {
	
	echo "<select class='form-control' style='width: 130px;' name='noisanxuat' id='noisanxuat' onkeydown='HideError()' required=''>";
	echo "<option value=''>Chọn</option>";
	$sql = mysqli_query ($con, "select * from user INNER JOIN `Phòng ban` pb 
								ON user.`Mã phòng` = pb.`Mã phòng` where user.`Mã chức vụ` = '01'") or die(mysqli_error());
	while($row = mysqli_fetch_array($sql)){
	$idUser = $row['Mã nhân viên'];
	$sendtoUser = $row['Họ tên'];
	$sendtoPhong = $row['Tên phòng'];
	
	if ($row['Mã chức vụ'] == '01'){
		$sendtoUser = $sendtoPhong;
	}
	//	if ($row['Mã chức vụ'] == '02'){
	//	$sendtoUser = 'Phó phòng '.$sendtoPhong;
	//}
	
	$select	= "";
	if ($noisanxuat == $idUser){
		$select = " selected";  
		//$maphongnhan = $row['Mã phòng'];
	}
	echo '<option style="color:black;" value="'.$sendtoUser.'"'.$select.'>'.$sendtoUser.'</option>';
	}
	echo "</select>";
	}
			  
			  ?>
			</div>
		 </div>
		 <div class="form-group">
			<label class="control-label col-sm-4" for="product-name">Thời hạn</label>
			<div class="col-sm-8">
			  <input class="form-control" name = "thoihan" type="date" value="<?php  if (!empty($_SESSION['thoihan'])) echo $_SESSION['thoihan'];
																								else{
																									$date = date('Y-m-d');
																									$newdate = date('Y-m-d', strtotime($date.' + 2 days'));
																									echo $newdate; 
																								}?>" required=""/>
			</div>
		 </div>
		   <div class="form-group">
			<label class="control-label col-sm-4" for="pwd">Ngày tạo</label>
			<div class="col-sm-8">
			<?php
			if ($type == "chuyentiep" || $type == "tuychon"){
			$findNgaytao = mysqli_query ($con, "select `Ngày tạo` from `Công việc` where `Mã công việc` = '$idGoc'");
			list($ngaytao_) = mysqli_fetch_array($findNgaytao);
			
			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">'.$ngaytao_.'</p>';
			echo '<input type ="hidden" name ="ngaytaocv" value = "'.$ngaytao_.'"/>';
			} else {
				echo '<input class="form-control" name = "ngaytaocv" type="date" value="';
				if (isset($_SESSION['ngaytaocv'])) echo $_SESSION["ngaytaocv"];
				else echo date("Y-m-d");
				echo '" required="">';
			}
			?>
			  
			  <input type = "hidden" name ="idGoc" value = "<?php echo $idGoc; ?>">	
			  <input type = "hidden" name ="idcongviec" value = "<?php echo $idcongviec; ?>">	
			</div>
		 </div>

		 </div>
		<input id= "count" type ="hidden" name = "count" value = "0"/>
		<input id= "send" type ="hidden" name = "send" value = "0"/>
		<input id= "manguoiduyet" type ="hidden" name = "manguoiduyet" value = "<?php echo $manguoiduyet; ?>"/>
		<input id= "checkAttach" type ="hidden" name = "checkAttach" value = "false"/>
		</form>
		 </div>
		 
    </div>
            
</div>        
</div>
</div>

				
              