<?php
	session_start();
	$id = $_SESSION['idlogin'];
	$rulelogin = $_SESSION['rule'];
	$idcv = $_REQUEST['data'];
	$manhan = $_REQUEST['manhan'];
	$currentPhong = $_SESSION['tenphongUser'];
	$checkDuyet = False;
	if ($type == 'sent'){
		$title = 'Đã gửi đến';
	} else {
		$title = 'Được gửi bởi';
	}
	$sql_ = "select cv.`Mã công việc`, cv.`Tên công việc`, cv.`Mô tả`, cv.`Ngày tạo`, cv.`Nơi sản xuất`,cv.`Loại File`, cv.`Nơi lưu`,
								qhcv.`MCV gốc`, u1.`Họ tên` as `Tên người nhận`,
								u2.`Họ tên` as `Tên người gửi`,
								pb.`Tên phòng` as `Tên phòng nhận`, pb2.`Tên phòng` as `Tên phòng gửi`, gvn.* 
								from `Phòng ban` pb INNER JOIN user u1	
								ON pb.`Mã phòng` = u1.`Mã phòng` INNER JOIN `gửi và nhận cv` gvn								
								ON u1.`Mã nhân viên` = gvn.`Mã người nhận` INNER JOIN user u2 
								ON gvn.`Mã người gửi` = u2.`Mã nhân viên` INNER JOIN `Phòng ban` pb2
								ON pb2.`Mã phòng` = u2.`Mã phòng` INNER JOIN `Công việc` cv
								ON gvn.`Mã công việc` = cv.`Mã công việc` INNER JOIN `Quan hệ công việc` qhcv
								ON cv.`Mã công việc` = qhcv.`MCV con` LEFT JOIN `Đính kèm cv` dkcv
								ON cv.`Mã công việc` = dkcv.`Mã công việc` LEFT JOIN `file đính kèm` fdk
								ON dkcv.`Mã File` = fdk.`Mã File` Where cv.`Mã công việc` = '$idcv' AND gvn.`Mã người nhận` = '$manhan' order by gvn.`Thời gian gửi`";
								
	$qrydk = mysqli_query ($con,"select fdk.`Mã File`, fdk.`Tên file`, fdk.`Loại file`, fdk.`Nơi lưu` as noiluu 
								from `Công việc` cv LEFT JOIN `Đính kèm cv` dkcv
								ON cv.`Mã công việc` = dkcv.`Mã công việc` LEFT JOIN `file đính kèm` fdk
								ON dkcv.`Mã File` = fdk.`Mã File` Where cv.`Mã công việc` = '$idcv'");
	
	$goc = "Select * from `Quan hệ công việc` where `MCV gốc` = '$idcv'";
	$qrygoc =  mysqli_query ($con, $goc);
	
	if ($rowgoc = mysqli_fetch_array($qrygoc))
		$checkgoc = "true";
								
	$qry_ = mysqli_query ($con, $sql_);							
    $qry = mysqli_query ($con, $sql_);
	
	if ($row_ = mysqli_fetch_array($qry_)){
		if ($row_['Mã người duyệt'] == $id){
			$checkDuyet = True;
		}
	}
								
    while($row = mysqli_fetch_array($qry)){
		$target = ($row['Mã người gửi'] == $id) ? $row['Mã người nhận'] : $row['Mã người gửi'];		
		$macv = $row['Mã công việc'];
		$maGoc = $row['MCV gốc'];
        $tencv = $row['Tên công việc'];
		$nguoigui = $row['Tên người gửi'];
		$nguoinhan = $row['Tên người nhận'];
		$manguoinhan = $row['Mã người nhận'];
		$manguoiduyet = $row['Mã người duyệt'];
		$manguoigui = $row['Mã người gửi'];

		$trangthai = $row['Trạng thái duyệt']; //sohieu
		$mota = $row['Mô tả'];
		$ngaytao = $row['Ngày tạo'];
		$noisanxuat = $row['Nơi sản xuất']; //loaivanban
		$loaifile = $row['Loại File'];		
		$thoihan = $row['Thời hạn']; //bancung
		$noinhan = $row['Tên phòng nhận'];
		$noigui = $row['Tên phòng gửi'];
		$thoigiangui = $row['Thời gian gửi'];
		$thoigiannhan = $row['Thời gian nhận'];
		$saveVB = $row['Nơi lưu'];
		
		$tennguoigui = $row['Tên người gửi'];
		$tennguoinhan = $row['Tên người nhận'];
		
		if ($row['Mã người gửi'] == $currentID){
			$tennguoigui = 'Bạn'; $target = $row['Mã người nhận'];
		}
		if ($row['Mã người nhận'] == $currentID){
			$tennguoinhan = 'Bạn'; $target = $row['Mã người gửi'];
		}
		if ($manguoiduyet == $manguoinhan) $tennguoiduyet = $tennguoinhan;
		if ($manguoiduyet == $manguoigui) $tennguoiduyet = $tennguoigui;		
		
		if (empty($thoigiannhan) && (($noinhan == $currentPhong && $noigui != $currentPhong) || ($manguoigui == $id && $manguoinhan == $id))){
		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiannhan = date("Y-m-d H:i:s", time());
		$queryTime = "UPDATE `gửi và nhận cv` SET `Thời gian nhận` = '$thoigiannhan' WHERE `Mã công việc` = '$macv' AND `Mã người gửi` = '$manguoigui' AND `Mã người nhận` = '$manguoinhan'";
		$qryTime = mysqli_query ($con, $queryTime);
	}
		
		if ($noinhan != $currentPhong){
			$noinhan = 'Phòng '.$noinhan;
		} else $noinhan = $nguoinhan;
		if ($noigui != $currentPhong){
			$noigui = 'Phòng '.$noigui;
		} else $noigui = $nguoigui;
    }
?>
<script type="text/javascript" src="assets/js/Registration.js"></script>

<h2 style="text-align: center;">Thông tin chi tiết công việc MCV = <?php echo $macv; ?></h2><br>
<form name="Myform" id="Myform" action="congviec/update.php" method="post">
    <table align = "center" id="viewdata">
			<tr>
			<td>				
			</td>
			<td></td>
			</tr>
			<tr>
                <td class ="info">Tên công việc</td>
				<td class ="info"><?php echo $tencv; ?></td>
            </tr> 
			<tr>			
                <td class ="info">Trạng thái</td>   
				<!--td class ="info"></td-->
				<?php
								$s = " selected";
								$s1 = $s2 = $s3 = $s4 = $s5 = '';
								if ($trangthai == 'Giao việc') $s1 = $s;
								if ($trangthai == 'Đang tiến hành') $s2 = $s;
								if ($trangthai == 'Đã xong') $s3 = $s;
								if ($trangthai == 'Phê duyệt') $s4 = $s;
								if ($trangthai == 'Hoàn thành') $s5 = $s;
								if ($trangthai == 'Chưa đạt') $s6 = $s;
								
								if ($checkDuyet != True) 
								{
									echo "<td>
										<select class='form-control' style='width: 150px; height: 32px;' name='trangthai' id='trangthai' onkeydown='HideError()'>
										<option value='Giao việc' $s1>Giao việc</option>
										<option value='Đang tiến hành' $s2>Đang tiến hành</option>
										<option value='Đã xong' $s3>Đã xong</option>";
										if ($trangthai == 'Hoàn thành' || $trangthai == 'Chưa đạt' || $trangthai == 'Phê duyệt'){
											echo "<option value='$trangthai' selected>$trangthai</option>";
										}
								}
								elseif ($checkDuyet == True)
								{
									echo"<td>
										<select class='form-control' style='width: 150px; height: 32px;' name='trangthai' id='trangthai' onkeydown='HideError()'>
										<option value='Giao việc' $s1>Giao việc</option>
										<option value='Chưa đạt' $s6>Chưa đạt</option>
										<option value='Phê duyệt' $s4>Phê duyệt</option>
										<option value='Hoàn thành' $s5>Hoàn thành</option>
										";
										if ($trangthai == 'Giao việc' || $trangthai == 'Đang tiến hành' || $trangthai == 'Đã xong'){
											echo "<option value='$trangthai' selected>$trangthai</option>";
										}
								}
									echo "</select>";
				?>
				
			</tr>
            <tr> 
                <td class ="info">Mô tả công việc</td>
				<td class ="info"><?php echo $mota; ?></td>
            </tr> 
			<tr>
                <td class ="info">Ngày tạo</td> 
				<td class ="info"><?php echo $ngaytao; ?></td>
            </tr> 
			<tr>
                <td class ="info">Nơi sản xuất</td>  
				<td class ="info"><?php echo $noisanxuat; ?></td>
			</tr>
			<tr>
                <td class ="info">Thời hạn</td>
				
				<?php 
				if ($checkDuyet == True){
				echo '<td><input style ="width: 160px; height: 32px;" class="form-control" name = "thoihan" type="date" value="'.$thoihan.'" required =""/></td>';
				}
				else echo '<td class ="info">'.$thoihan.'</td>
				<input type = "hidden" name = "thoihan" value = "'.$thoihan.'">	';
			?>
            </tr> 	
			<tr>			
				<td class ="info">Người gửi</td>
				<td class ="info"><?php echo $tennguoigui; ?></td>
            </tr>
			<tr>			
				<td class ="info">Người nhận</td>
				<td class ="info"><?php echo $tennguoinhan; ?></td>
            </tr>
			<tr>			
				<td class ="info">Người duyệt</td>
				<td class ="info"><?php echo $tennguoiduyet; ?></td>
            </tr>			
			<tr>			
				<td class ="info">Thời gian gửi</td>
				<td class ="info"><?php echo $thoigiangui; ?></td>
            </tr> 
			<tr>			
				<td class ="info">Thời gian nhận</td>
				<td class ="info">				
				<?php 
				if (!empty($thoigiannhan))
				echo $thoigiannhan; 
				else 
				echo "Chưa có";
				?></td>
            </tr> 
			<tr>			
				<td class ="info">Tải công việc</td>
				<td class ="info"><a align = "center" href="congviec/download.php?type=congviec&data=<?php echo $idcv; ?>">Download </a>(.<?php echo  $loaifile;?>)</td>
			</tr>
				<?php $downfile='';
				while($row = mysqli_fetch_array($qrydk)){
					$tendinhkem = $row['Tên file'];
					$loaidk = $row['Loại file'];		
					$saveDK = $row['noilưu'];
					$idfile = $row['Mã File'];
				if (!empty($idfile)){
				$downfile = 
				'<tr> 				
				<td class ="info">Tải tệp đính kèm</td>
				<td class ="info"><a align = "center" href="congviec/download.php?type=file&data='.$idfile.'">Download </a>(.'.$loaidk.')</td>
				</tr>';
				} 
				echo $downfile;
				}
				?>
			<tr>
                <td style = "text-align: center; padding-right: 70px;" colspan ='2'>	
				<input type = "hidden" name = "id" value = "<?php echo $maGoc; ?>">	
				<input type = "hidden" name = "idcv" value = "<?php echo $idcv; ?>">	
				<input type = "hidden" name = "manguoinhan" value = "<?php echo $manguoinhan; ?>">
				<input type = "hidden" name = "manguoigui" value = "<?php echo $manguoigui; ?>">
				<input type = "hidden" name = "manguoiduyet" value = "<?php echo $manguoiduyet; ?>">
				<a href = "?page=createWork&id=<?php echo $maGoc; ?>&target=<?php echo $target; ?>&maduyet=<?php echo $manguoiduyet; ?>">
				
				<button align = "left" name="phanhoi" type="button"  class="btn btn-primary">Phản hồi</button>
				
				</a> 
				
				<button align = "center" name="submit" type="submit"  class="btn btn-primary">Cập nhật</button>				

				<?php
				if ($checkgoc == "true"){
					echo '<a align = "right" href = "?page=createWork&id='.$maGoc.'&idcv='.$idcv.'&type=chuyentiep">
				
						  <button align = "right" name="chuyentiep" type="button"  class="btn btn-primary">Chuyển tiếp</button>
				
						</a>';
				} elseif ($manguoiduyet == $id && $manguoigui != $id) {
					echo '<a href = "bangiao.php?id='.$idcv.'">
				
						  <button align = "right" name="bangiao" type="button"  class="btn btn-primary">Bàn giao</button>
				
						</a>';
					echo '<a align = "right" href = "?page=createWork&id='.$maGoc.'&idcv='.$idcv.'&type=tuychon">
				
						 <button align = "right" name="tuychon" type="button"  class="btn btn-primary">Tùy chọn</button>
				
					</a>';	
				}
				?>
				</td>				
	
            </tr>

    </table>
	
</form>

