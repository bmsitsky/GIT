
<?php
include '../connection.php';
if(isset($_REQUEST['data']) && $_REQUEST['type']=='congviec') 
{
    $id =$_REQUEST['data'];

$query = "SELECT `Nơi lưu`, `Tên công việc`
         FROM `Công việc` WHERE `Mã công việc` = '$id'";
$result = mysqli_query ($con, $query) or die('Error, query failed');
list($content, $name) = mysqli_fetch_array($result);
//$date = date('m/d/Y h:i:s a', time());
$list = explode('/',$content);
$filepath = '../congviec/'.$content;
$con -> close();
if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . $list[2]);
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filepath));
		ob_clean();
		flush();
        readfile($filepath);
		exit;
		//echo $filepath.'<br>'.basename($filepath).'<br>'.$content;
}
else {
	header('location:../?msg=Tệp không tồn tại hoặc bị xóa!&page=viewWorkDetails&data='.$id);
	exit;
}
}

elseif(isset($_REQUEST['data']) && $_REQUEST['type']=='file') 
{
    $id =$_REQUEST['data'];

$query = "SELECT `Nơi lưu`
         FROM `file đính kèm` WHERE `Mã File` = '$id'";
$result = mysqli_query ($con, $query) or die('Error, query failed');
list($content) = mysqli_fetch_array($result);
//$date = date('m/d/Y h:i:s a', time());
$list = explode('/',$content);
$filepath = '../congviec/'.$content;
$con -> close();
if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . $list[2]);
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filepath));
		ob_clean();
		flush();
        readfile($filepath);
		exit;
		//echo $filepath.'<br>'.basename($filepath).'<br>'.$content;
}
else {
	header('location:../?msg=Tệp đính kèm không tồn tại!&page=viewWorkDetails&data='.$id);
	exit;
}
} else {
	header('location:../');
}
?>
