<?php
	session_start();
	include_once 'connection.php';

	if(isset($_POST['submit'])){
		//echo "submit form";
		
		$con = mysqli_connect('localhost', 'root', '12345678') or die(mysqli_error($con));
		$db = mysqli_select_db($con,'quanlyvanban');
		$con -> autocommit(TRUE);
		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiangui = date("Y-m-d H:i:s", time());
		
		$trangthai = $_POST['trangthai'];
		$MaGoc = $_POST['idGoc'];
		$thoihan = $_POST['thoihan'];
		//$noinhan = $_POST['noinhan'];
		$idcongviec = $_POST['idcongviec'];
		$ngaytaocv = $_POST['ngaytaocv'];
		$countSend = $_POST['send'];
		$capdo = 1;
		$manguoigui = $_SESSION['idlogin'];
		$maphonggui = $_SESSION['MaphongUser'];
		for ($i=0; $i<=$countSend; $i++){
			echo 'dong 20 count send = '.$countSend.'<br>';
			$j = ($i==0) ? '' : $i;
			$noi = 'noinhan'.$j.'';
			$noinhan[$i] = $_POST[$noi];
			$noiduyet[$i] = $noinhan[$i];
				
			$noi_ = $noinhan[$i];
			$sqls = mysqli_query ($con, "select * from user where user.`Mã nhân viên` = '$noi_'") or die(mysqli_error());
			while($rows=mysqli_fetch_assoc($sqls)){
			$maphongnhan[$i] = $rows['Mã phòng'];
			}
		}

		for ($i=0; $i<=$countSend; $i++){
			for ($j=$i+1; $j<=$countSend; $j++){
				$m = ($i==0) ? '' : $i;
				$n = ($j==0) ? '' : $j;
			$attm = 'noinhan'.$m.'';
			$attn = 'noinhan'.$n.'';
			if ($_POST[$attm] == $_POST[$attn]){
				header('location:../?msg=Người nhận trùng nhau!&page=createWork&id='.$MaGoc.'&idcv='.$idcongviec.'&type=chuyentiep');
				exit;
				break;
			}
		}
		}
		
		$qry = "select `MCV gốc` from `Quan hệ công việc` Where `MCV con` = $idcv";
		$res = mysqli_query ($con, $qry);
		while($row=mysqli_fetch_assoc($res)){
			$MCV = $row['MCV gốc'];
		}

		$sql = "select `Mã người gửi`, `Mã phòng gửi`, `Mã phòng nhận` from `Gửi và nhận cv` Where `Mã người nhận` = '$manguoigui' AND `Mã người duyệt` != '$manguoigui' AND `Mã công việc` = '$MCV'";
		$sql2 = "select `Mã người nhận`, `Mã phòng nhận`, `Mã phòng gửi` from `Gửi và nhận cv` Where `Mã người gửi` = '$manguoigui' AND `Mã người duyệt` != '$manguoigui' AND `Mã công việc` = '$MCV'";
		
		$res = mysqli_query ($con, $sql);
		$res2 = mysqli_query ($con, $sql2);
		
		for ($k=0; $k<=$countSend; $k++){
			$t = 0;
			$checks = false;
			$check = false;
			$nguoi_nhan = $noinhan[$k];
		while($row=mysqli_fetch_assoc($res)){
			$nguoinhan[$t] = $row['Mã người gửi'];
			$phonggui[$t] = $row['Mã phòng nhận'];
			$phongnhan[$t] = $row['Mã phòng gửi'];
			$checks = True;
			$guitu = $manguoigui;
			$guituphong = $maphonggui;
			if ($nguoinhan[$t] == $noinhan[$k] && !empty($nguoinhan[$t])){	
				$check = true;
			}
			$t++;
		}
		
		while($row=mysqli_fetch_assoc($res2)){
			$nguoinhan = $row['Mã người nhận'];
			$phonggui = $row['Mã phòng gửi'];
			$phongnhan = $row['Mã phòng nhận'];
			$checks = True;
			$guitu = $manguoigui;
			$guituphong = $maphonggui;
			if ($nguoinhan[$t] == $noinhan[$k] && !empty($nguoinhan[$t])){	
				$check = true;
			}
			$t++;
		}
			if ($check == false){
				$guitu = $noinhan[$k];
				$noinhan[$k] = $manguoigui;
				$guituphong = $maphongnhan[$k];
				$maphongnhan[$k] = $maphonggui;
				
				$nguoi_nhan = $guitu;
			}

		$GuiNhanGoc = "INSERT INTO `gửi và nhận cv` (`Mã công việc`,`Mã người gửi`, `Mã người nhận`, `Mã người duyệt`, `Thời gian gửi`,`Thời hạn`, `Mã phòng gửi`, `Mã phòng nhận`, `Trạng thái duyệt`) ".
					"VALUES ('$MaGoc', '$guitu', '$noinhan[$k]', '$noiduyet[$k]', '$thoigiangui', '$thoihan', '$guituphong', '$maphongnhan[$k]', 'Giao việc' )";
		if ($check == false)
		$GuiNhanGoc = "INSERT INTO `gửi và nhận cv` (`Mã công việc`,`Mã người gửi`, `Mã người nhận`, `Mã người duyệt`, `Thời gian gửi`,`Thời hạn`, `Mã phòng gửi`, `Mã phòng nhận`, `Trạng thái duyệt`) ".
					"VALUES ('$MaGoc', '$manguoigui', '$nguoi_nhan', '$noiduyet[$k]', '$thoigiangui', '$thoihan', '$guituphong', '$maphongnhan[$k]', 'Giao việc' )";
					
		$getGuiNhan = mysqli_query ($con,$GuiNhanGoc);
		$GuiNhan = "INSERT INTO `gửi và nhận cv` (`Mã công việc`,`Mã người gửi`, `Mã người nhận`, `Mã người duyệt`, `Thời gian gửi`,`Thời hạn`, `Mã phòng gửi`, `Mã phòng nhận`, `Trạng thái duyệt`) ".
					"VALUES ('$idcongviec', '$manguoigui', '$nguoi_nhan', '$noiduyet[$k]', '$thoigiangui', '$thoihan', '$guituphong', '$maphongnhan[$k]', 'Đã xong' )";
		if ($guitu != $noinhan[$k])
		$getGuiNhan = mysqli_query ($con,$GuiNhan);

		

		}
			$con -> close();
			header("location:../?page=listWork&msg=Bàn giao công việc thành công!");
			//echo $qry.'<br>'.$sql.'<br>'.$query;
			exit();	
			
	
	}
	
?>
