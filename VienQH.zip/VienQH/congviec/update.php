<?php
	session_start();
	ob_start();
    include_once '../connection.php';
	if(isset($_POST['submit'])){
		//echo "submit form";
		$id = $_POST['id'];
		$trangthai = $_POST['trangthai'];
		if (isset($_POST['trangthai'])){
			$q1 = "Update `Công việc` set `Trạng thái` = '$trangthai' where `Mã công việc` = '$id'";
			$q2 = "Update `gửi và nhận cv` set `Trạng thái duyệt` = '$trangthai' where `Mã công việc` = '$id'";
		mysqli_query($con, $q1);
		mysqli_query($con, $q2);
		}
		//echo $q1.'<br>'.$q2.' tt '.$trangthai;
		header("location:../?msg=Cập nhật trạng thái công việc thành công!&page=viewWorkDetails&data=$id");
		exit;			
	}
		ob_end_flush();
		exit;
?>
