<?php session_start();
	
include './connection.php';
$currentID = $_SESSION['idlogin'];
$sql="select cv.`Tên công việc`, cv.`Mã công việc`, gvn.`Thời gian gửi`, gvn.`Thời gian nhận`, u2.`Họ tên` as `Tên người nhận`, u2.`Mã nhân viên` as `Mã người nhận`,
	  u1.`Họ tên` as `Tên người gửi`, u1.`Mã nhân viên` as `Mã người gửi`, cv.`Mô tả`, cv.`Trạng thái`, cv.`Thời hạn` from `user` u1 INNER JOIN `gửi và nhận cv` gvn
	  ON u1.`Mã nhân viên` = gvn.`Mã người gửi` INNER JOIN `Công việc` cv
	  ON gvn.`Mã công việc` = cv.`Mã công việc` INNER JOIN `user` u2
	  ON gvn.`Mã người duyệt` = u2.`Mã nhân viên` where (u1.`Mã nhân viên` = '$currentID' OR u2.`Mã nhân viên` = '$currentID') 
	  AND cv.`Mã công việc` IN (Select `MCV gốc` from `Quan hệ công việc`)";
		$res=mysqli_query ($con, $sql) or die(mysqli_error());
		$res2=mysqli_query ($con, $sql) or die(mysqli_error());
?>         


<?php
								$dem=1;
								$begin = '
								<div class="panel panel-default">
								<div class="panel-heading">
								Bạn chưa có công việc nào ở đây
								</div> 
								<div class="panel-body">
								<div class="table-responsive">
								<table class="table table-striped table-bordered table-hover">						
								';
								if (!$row2=mysqli_fetch_assoc($res2)) echo $begin;
								while($row=mysqli_fetch_assoc($res))
								{
								if ($begin != '')
								$begin = '
								<div class="panel panel-default">
								<div class="panel-heading">
								Danh sách tất cả công việc gốc
								</div> 
								<div class="panel-body">
								<div class="table-responsive">
								<table class="table table-striped table-bordered table-hover">
								<tr>                                    
                                    <th>STT</th>
									<th>Tên công việc</th>
                                    <th>Thời gian gửi</th>
									<th>Thời gian nhận</th>
									<th>Thời hạn</th>
									<th>Người giao việc</th>
									<th>Người nhận việc</th>									
                                    <th>Mô tả</th>
									<th style = "text-align: center;">Tác vụ</th>
									<th style = "text-align: center;">Trạng thái</th>
                                </tr>								
								';
									echo $begin;
									$begin='';
								$tennguoigui = $row['Tên người gửi'];
								$tennguoinhan = $row['Tên người nhận'];
								if ($row['Mã người gửi'] == $currentID){
									$tennguoigui = 'Bạn';
								}
								if ($row['Mã người nhận'] == $currentID){
									$tennguoinhan = 'Bạn';
								}
								if (empty($row['Thời gian nhận'])){
									$view = "<td width = '10%' style = 'text-align: center;'><a style ='color: red;' href=\"?page=listWorkDetails&data=".$row['Mã công việc']."\">Xem</a></td>
											<td width = '10%' style = 'text-align: center;'>".$row['Trạng thái']."</td></tr>";
								} else {
									$view = "<td width = '10%' style = 'text-align: center; font-weight: bold;'><a href=\"?page=listWorkDetails&data=".$row['Mã công việc']."\">Xem</a></td>
											<td width = '10%' style = 'text-align: center; font-weight: bold;'>".$row['Trạng thái']."</td></tr>";
								}									
								echo "</td><td>";
								echo $dem++;
								echo "</td><td>";
								echo $row['Tên công việc'];
								echo "</td><td>";
								echo $row['Thời gian gửi'];
								echo "</td><td>";
								if (empty($row['Thời gian nhận'])) echo "Chưa có"; else echo $row['Thời gian nhận'];
								echo "</td><td>";
								echo $row['Thời hạn'];
								echo "</td><td>";
								echo $tennguoigui;
								echo "</td><td>";
								echo $tennguoinhan;
								echo "</td><td>";
								echo $row['Mô tả'];
								echo "</td>";
								echo $view;
								}
								$con -> close();
?>
                        </table>
                    </div>
                </div>
            </div>

        </div>		