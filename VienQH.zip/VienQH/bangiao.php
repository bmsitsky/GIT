<?php
	session_start();
	include_once 'connection.php';  
	if (!empty($_REQUEST['id'])){
		$idcv = $_REQUEST['id'];
		$nguoigui = $_SESSION['idlogin'];
		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiangui = date("Y-m-d H:i:s", time());
		
		$qry = "select `MCV gốc` from `Quan hệ công việc` Where `MCV con` = $idcv";
		$res = mysqli_query ($con, $qry);
		while($row=mysqli_fetch_assoc($res)){
			$MCV = $row['MCV gốc'];
		}
		
		$sql = "select `Mã người gửi`, `Mã phòng gửi`, `Mã phòng nhận` from `Gửi và nhận cv` Where `Mã người nhận` = '$nguoigui' AND `Mã công việc` = '$MCV'";
		
		$res = mysqli_query ($con, $sql);
		while($row=mysqli_fetch_assoc($res)){
			$nguoinhan = $row['Mã người gửi'];
			$phonggui = $row['Mã phòng nhận'];
			$phongnhan = $row['Mã phòng gửi'];
		}
		
		$query = "INSERT INTO `Gửi và nhận cv` (`Mã công việc`,`Mã người gửi`,`Mã người nhận`,`Mã người duyệt`,`Trạng thái duyệt`,`Thời gian gửi`, `Mã phòng nhận`, `Mã phòng gửi`) 
				values ('$idcv','$nguoigui','$nguoinhan','$nguoinhan','Đã xong','$thoigiangui','$phongnhan','$phonggui')";
		$check =  mysqli_query ($con, $query);
	}
	if ($check){
	header("Location:/VienQH?page=listWorkDetails&msg=Bàn giao công việc thành công!&manhan=".$nguoinhan."&data=".$MCV);
	exit();
	} else {
	header("Location:/VienQH?page=viewWorkDetails&msg=Bàn giao không thành công hoặc bạn chính là người duyệt cuối cùng!&manhan=".$nguoigui."&data=".$idcv);
	//echo $qry.'<br>'.$sql.'<br>'.$query;
	exit();	
	}
	
?>
