<?php
session_start();
echo "test".$_SESSION['rule'];
?>