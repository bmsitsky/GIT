<?php
session_start();
echo "test".$_SESSION['rule'];
echo "test".$_SESSION['MaphongUser'];
$id = $_SESSION['idlogin'];
$destination = "Tên này khó viết lắm!";
//$destination = utf8_encode($destination);
$destination=iconv('utf-8','cp936', $destination);
echo $id;
?>