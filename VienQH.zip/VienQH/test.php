<?php
include_once '../connection.php';
$qry = mysqli_query ($con, "select * from user where `Mã nhân viên`='1'");
while($row = mysqli_fetch_array($qry)){ 
echo $row['Họ tên']." hi <br>";
}	
?>