<?php session_start();
		include_once 'loginSession.php';
		include_once '../VienQH/connection.php'; 		
		$uname = $_SESSION['username'];
		$userqry = mysqli_query ($con, "select * from user u1 INNER JOIN `Phòng ban` pb 
								ON pb.`Mã phòng` = u1.`Mã phòng` where username = '$uname'");
        $countUser = mysqli_num_rows($userqry);
        if($countUser == 1)
        {
           $row = mysqli_fetch_array($userqry);
           $_SESSION['rule'] = $row['rule'];
		   $_SESSION['MaphongUser'] = $row['Mã phòng'];	
		   $_SESSION['tenphongUser'] = $row['Tên phòng'];		   
           if($_SESSION['rule'] != '0' && $_SESSION['rule'] != '1' && $_SESSION['rule'] != '2'){
              header('location:../VienQH/login.php?msg=Xin lỗi, bạn không có quyền truy cập!');	
			  exit;
			}
			
			if($_SESSION['rule'] != '0' && ($_REQUEST['page'] == 'listusers' || $_REQUEST['page'] == 'adduser')){
              header('location:../VienQH');	
			  exit;
			}
			
			if ($_SESSION['rule'] != '2' && ($_REQUEST['page'] == "vanthu" || $_REQUEST['page'] == 'viewSaved')){
			  header('location:../VienQH?msg=Chỉ văn thư mới có thể xem trang này!');	
			  exit;
			}
		}
		
$rulelogin = $_SESSION['rule'];
		
date_default_timezone_set('Asia/Ho_Chi_Minh');
$currentTime = date("Y-m-d", time());		
$currentID = $_SESSION['idlogin'];
$sql="select cv.`Tên công việc`, cv.`Mã công việc`, gvn.`Thời gian gửi`, gvn.`Thời gian nhận`, u2.`Họ tên` as `Tên người nhận`, u2.`Mã nhân viên` as `Mã người nhận`,
	  u1.`Họ tên` as `Tên người gửi`, u1.`Mã nhân viên` as `Mã người gửi`, cv.`Mô tả`, cv.`Trạng thái`, cv.`Thời hạn` from `user` u1 INNER JOIN `gửi và nhận cv` gvn
	  ON u1.`Mã nhân viên` = gvn.`Mã người gửi` INNER JOIN `Công việc` cv
	  ON gvn.`Mã công việc` = cv.`Mã công việc` INNER JOIN `user` u2
	  ON gvn.`Mã người duyệt` = u2.`Mã nhân viên` where (u1.`Mã nhân viên` = '$currentID' OR u2.`Mã nhân viên` = '$currentID') 
	  AND cv.`Mã công việc` IN (Select `MCV gốc` from `Quan hệ công việc`) AND cv.`Trạng thái` != 'Phê duyệt' AND cv.`Trạng thái` != 'Hoàn thành'
	  AND DATEDIFF(cv.`Thời hạn`, '$currentTime')<='2'";
$res=mysqli_query ($con, $sql) or die(mysqli_error());
$res2=mysqli_query ($con, $sql) or die(mysqli_error());
$checkNotification = "Style = ''";
$demNotification = 0;
while ($row2=mysqli_fetch_assoc($res2)) {
	$checkNotification = "Style = 'color: red;'";
	$demNotification++;
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Hệ thống quản lý văn bản</title>
	<?php 
	 if ($_REQUEST['page'] == 'uploadVanban' || $_REQUEST['page'] == 'createWork' || $_REQUEST['page'] == 'vanthu'){
		echo '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="assets/css/main.1d326c5a01ca4cbd32c8.css">';
	 }
	?>


    <!-- Bootstrap Styles-->
	<link href="assets/css/css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="assets/js/Lightweight-Chart/cssCharts.css"> 
	<style> 
	input, select{
	width: 100%;
	padding: 6px 10px;
	margin: 7px 0;
	box-sizing: border-box;
	}
	.info{
	width: 50%;
	padding: 6px 10px;
	margin: 7px 0;
	box-sizing: border-box;
	font-size:18px;
	}
	#update
	{
	height:40px;
	width:100px;
	
	}
	</style>
	 <script>
            function getPage(url){
                $('#content').hide(0,function(){
                $('#content').load(url);
                $('#content').show(0,function(){});
                });
            }
     </script>
<script>
function onClickHandler(where) {
	  document.getElementById(where).style = 'width: 100%;';
}
</script>

</head>

<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" style ="background-color: #003D7E;" role="navigation">
            <div class="navbar-header">
                
                <a class="navbar-brand" style ="background-color: #003D7E;" href="index.php"><strong></strong></a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
              
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li>
						<a href="?page=userinfo"><i class="fa fa-sign-out fa-fw"></i> Thông tin tài khoản</a>
						<?php
						if ($rulelogin == 0){
							$addUser = '<a href="?page=adduser"><i class="fa fa-sign-out fa-fw"></i> Thêm User</a>
										<a href="?page=listusers"><i class="fa fa-sign-out fa-fw"></i> Danh sách User</a>';
							echo $addUser;
						}
						?>
						<a href="?page=changepass"><i class="fa fa-sign-out fa-fw"></i> Đổi mật khẩu</a>
						<a href="logout.php" onclick=""><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
        <div id="sideNav" href=""><i class=""></i></div>
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a style ="background-color: #003D7E;" href="../VienQH"><i class="fa fa-dashboard"></i>Trang chủ</a>
                    </li>
                    <li>
						<?php
						if ($rulelogin == 2){
							$vanthu1 = '<a href="?page=vanthu"><i class="fa fa-sign-out fa-fw"></i>Nhập văn bản</a>';
							$vanthu2 = '<a href="?page=viewSaved"><i class="fa fa-sign-out fa-fw"></i>Văn bản đã lưu</a>';									
							echo $vanthu1; echo $vanthu2;
						} 
						?>
                        <a href="?page=uploadVanban" ><i class="fa fa-desktop"></i>Tạo văn bản</a>
						<a href="?page=viewSent"><i class="fa fa-desktop"></i>Văn bản đã gửi</a>
						<a href="?page=viewReceived"><i class="fa fa-desktop"></i>Văn bản đã nhận</a>
						<a href="?page=createWork" ><i class="fa fa-desktop"></i>Tạo công việc</a>
						<a href="?page=listWork"><i class="fa fa-desktop"></i>Danh sách công việc</a>
                    </li>
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->
      
        <div id="page-wrapper">
          <div class="header"> 
						
                        <h1 class="page-header">
						<?php
						if ($_REQUEST['page'] != 'createWork')
                        echo "Hệ thống Quản lý văn bản";						
						?>
                        </h1>
						
				<ol class="breadcrumb">
                <li><a href="../VienQH">Trang chủ</a></li>
                <li>
				<ul>             
                <!-- /.dropdown -->
                <li class="dropdown">&nbsp; &nbsp;
                    <a <?php echo $checkNotification; ?> class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        Thông báo <?php if ($demNotification > 0) echo "($demNotification)"; ?>
                    </a>
                    
					   <ul class="dropdown-menu dropdown-user">					  
                      <li>
					  <?php
						while($row=mysqli_fetch_assoc($res))
							{
							$macongviec = $row['Mã công việc'];
							echo "<a href='?page=listWorkDetails&data=".$macongviec."'>Công việc có mã $macongviec sắp đến hạn hoặc đã quá hạn!</a>";
							}
					  ?>
					  </li>
					  </ul>
                    </li> 
				</ul>
				</li>
				</ol>
                
					
                                    
        </div>
				<!-- Vùng hiển thị nội dung chính -->
				
				<?php
				$msg = '&ensp;&ensp; ';
				if (!empty($_REQUEST['msg']) && isset($_REQUEST['msg'])){
				$msg = $msg.$_REQUEST['msg'];
				}				
				echo $msg.'<br><br>';			
				?>
				
                <div id="content">
                <?php
				if (isset($_REQUEST['page'])){
				$page = $_REQUEST['page'];
					if ($page == 'uploadVanban' || $page == 'vanthu'){
						$url = "upload/".$page.".php";
					} elseif ($page == 'viewSent' || $page == 'viewDetails' || $page == 'viewReceived' || $page == 'viewSaved') {
						$url = "vanban/".$page.".php";
					} elseif ($page == 'createWork' || $page == 'listWork' || $page == 'listWorkDetails' || $page == 'viewWorkDetails' || $page == 'approveWork') {
						$url = "congviec/".$page.".php";
					} else					
					{
						$url = "user/".$page.".php";
					}				
				include($url);
				}			
				?>
                </div>
				
                <!-- /. ROW  -->
                <!--<footer><p>&ensp;&ensp;Copyright @ 2020 - Viện quy hoạch xây dựng Hà Nội</p>
                </footer>-->
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
     
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- Morris Chart Js -->
    <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
    
    <script src="assets/js/easypiechart.js"></script>
    <script src="assets/js/easypiechart-data.js"></script>
    
     <script src="assets/js/Lightweight-Chart/jquery.chart.js"></script>
    
    <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
	<script src="assets/js/Registration.js"></script>
      
<?php
	$page = $_REQUEST['page'];
	if($page == 'listusers' && $rulelogin == '0')
  {
?>

	<script type="text/javascript">
	getPage('user/listusers.php');         
	</script>

<?php
  }
?>

<?php
	$page = $_REQUEST['page'];
	if($page == 'adduser' && $rulelogin == '0')
  {
?>

	<script type="text/javascript">
	getPage('user/adduser.php');         
	</script>

<?php
  }
?>

</body>
</html>