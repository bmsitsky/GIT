<?php
include_once '../connection.php';
session_start();
$rulelogin = $_SESSION['rule'];
if ($rulelogin != '0'){	
	header('location:../?page=listusers');
	exit;
}
$sql2="UPDATE user SET rule = '1' WHERE `Mã nhân viên` = '".$_REQUEST['data']."'";
$res2=mysqli_query ($con, $sql2) or die(mysql_error());
$con -> close();
if($res2)
{
header("location:../?msg=Cấp quyền thành công!&page=listusers");
}
?> 
