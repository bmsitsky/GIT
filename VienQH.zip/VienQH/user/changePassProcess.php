<?php 
    include_once '../connection.php';
	session_start();
	$id = $_SESSION['idlogin'];
    if(isset($_POST['submit'])){
		$qry = mysqli_query ($con, "select * from user where `Mã nhân viên`='$id'");
		while($row = mysqli_fetch_array($qry)){     
		$password = $row['password'];
		}
        $oldpass = htmlentities(stripslashes($con -> real_escape_string($_POST['oldpass'])));
        $newpass = htmlentities(stripslashes($con -> real_escape_string($_POST['newpass'])));
        $renewpass = htmlentities(stripslashes($con -> real_escape_string($_POST['renewpass'])));
		//echo "old ".$oldpass." new ".$newpass." renew ".$renewpass."<br>".$password;
		if ($oldpass == "" || $newpass.$renewpass == ""){
				header("location:../?msg=Vui lòng nhập thông tin vào các hạng mục!&page=changepass");

		} else if ($newpass != $renewpass){
				header("location:../?msg=Mật khẩu nhập lại không khớp mật khẩu mới!&page=changepass");

		} else if ($oldpass != $password){
				header("location:../?msg=Mật khẩu sai, vui lòng kiểm tra lại!&page=changepass");

		} else {
			$insertqry = mysqli_query ($con, "Update user set `password` = '$newpass' where `Mã nhân viên` = '$id'");
			if ($insertqry)
			header("location:../?msg=Đổi mật khẩu thành công!&page=changepass");
		}
        
    }    
?>
