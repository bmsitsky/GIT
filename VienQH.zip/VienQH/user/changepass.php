<?php
	session_start();
	$curentId = $_SESSION['idlogin'];
?>
<script type="text/javascript" src="assets/js/Registration.js"></script>
<h2 style="text-align: center;">Đổi mật khẩu </h2><br>
<form name="Myform" id="Myform" action="user/changePassProcess.php" method="post">
   <div id="error" align = "center" style="color:red; font-size:18px; font-weight:bold;"></div>
    <table align = "center" id="viewdata">
        <thead></thead>
        <tbody>
            <tr>
                <td>Mật khẩu hiện tại &ensp;</td>
                <td><input type="password" size="45" name="oldpass" id="oldpass" onkeydown="HideError()" value = ""/></td>
            </tr>
            <tr>
                <td>Mật khẩu mới</td>
                <td><input type="password" size="45" name="newpass" id="newpass" onkeydown="HideError()" value = ""/></td>
            </tr>
            <tr>
                <td>Nhập lại mật khẩu</td>
                <td><input type="password" size="45" name="renewpass" id="renewpass" onkeydown="HideError()" value = ""/></td>
            </tr>

            <tr>
                <td style="color:#F8F8FF;"></td>
                <td><input id = "update" type="submit" name="submit" value="Cập nhật" /></td>
            </tr>
        
        </tbody>
    </table>
</form>