<?php
	session_start();
	$curentId = $_SESSION['idlogin'];
?>
<script type="text/javascript" src="assets/js/Registration.js"></script>
<h3 class=" control-label col-sm-122" style="text-align: center;">Đổi mật khẩu</h3><br>
<form name="Myform" id="Myform" action="user/changePassProcess.php" method="post">
   <div id="error" align = "center" style="color:red; font-size:18px; font-weight:bold;"></div>
    <table align = "center" id="viewdata">
        <thead></thead>
        <tbody>
            <tr>
                <td class="control-label col-sm-4"><b>Mật khẩu hiện tại</td>
                <td ><input class="form-control" type="password" size="45" name="oldpass" id="oldpass" onkeydown="HideError()" value = ""/></td>
            </tr>
            <tr>
                <td class="control-label col-sm-4"><b>Mật khẩu mới</td>
                <td><input class="form-control" type="password" size="45" name="newpass" id="newpass" onkeydown="HideError()" value = ""/></td>
            </tr>
            <tr>
                <td class="control-label col-sm-4"><b>Nhập lại mật khẩu</td>
                <td><input class="form-control" type="password" size="45" name="renewpass" id="renewpass" onkeydown="HideError()" value = ""/></td>
            </tr>

            <tr>
                <td style="color:#F8F8FF;"></td>
                <td style= "padding-top:10px;">
					<button name="submit" type="submit"  class="btn btn-primary">Cập nhật</button>
				</td>
            </tr>
        
        </tbody>
    </table>
</form>