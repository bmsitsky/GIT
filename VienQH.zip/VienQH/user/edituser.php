<?php
	session_start();
	$id = $_SESSION['iduser'];
	$idlogin = $_SESSION['idlogin'];
	$rulelogin = $_SESSION['rule'];
	if ($rulelogin != '0'){
		$id = $idlogin;
	}
    $qry = mysqli_query ($con, "select * from user LEFT JOIN `Phòng ban` pb
	  ON user.`Mã phòng` = pb.`Mã phòng` LEFT JOIN `Chức vụ` cv
	  ON user.`Mã chức vụ` = cv.`Mã chức vụ` where `Mã nhân viên`='$id'") or die(mysqli_error());
    while($row = mysqli_fetch_array($qry)){
        $id = $row['Mã nhân viên'];
        $name=$row['Họ tên'];
        $username =$row['username'];
        $phong = $row['Tên phòng'];
		$maphong = $row['Mã phòng'];
        $birthday = $row['birthday'];
		$chucvu = $row['Tên chức vụ'];
		$machucvu = $row['Mã chức vụ'];
		$rule = $row['rule'];
    }
?>
<script type="text/javascript" src="../assets/js/Registration.js"></script>
<script type="text/javascript" src="assets/js/Registration.js"></script>
<script>
            function getPageAdmin(url){
                $('#admin').hide(0,function(){
                $('#admin').load(url);
                $('#admin').show(0,function(){});
                });
            }
</script>

<h2 style="text-align: center;">Sửa thông tin user </h2><br>
<form name="Myform" id="Myform" action="user/editProcess.php?id=<?php echo $id;?>" method="post" onsubmit="return(Validate());">
   <div id="error" align = "center" style="color:red; font-size:18px; font-weight:bold;"></div>
    <table align = "center" id="viewdata">
        <thead></thead>
        <tbody>
            <tr>
                <td>Username/Email &ensp;</td>
                <td><input type="email" size="45" name="username" id="username" onkeydown="HideError()" value = "<?php echo $username; ?>"/></td>
            </tr>
            <tr>
                <td>Mã nhân viên</td>
				<td style = "text-align: center;">
                
				<?php 
				if ($rulelogin == '0'){
					echo '<input type="text" size="45" name="userid" id="userid" onkeydown="HideError()" value = "'.$id.'"/>';
				} else
				echo $id; ?>
				</td>
            </tr>
            <tr>
                <td>Họ tên</td>
                <td><input type="text" name="name" id="name" onkeydown="HideError()" value = "<?php echo $name; ?>"/></td>
            </tr>
            <tr>
                <td>Ngày sinh</td>
                <td><input type="text" name="birthday" id="birthday" onkeydown="HideError()" value = "<?php echo $birthday; ?>"/></td>
            </tr>
			<tr>
                <td>Phòng ban</td>
				<td>
                
						<?php
						if ($rulelogin == '0'){
						echo "<select style='width: 180px;' name='phong' id='phong' onkeydown='HideError()'>";
						echo "<option value=''>Chọn phòng ban</option>";
						$sql = mysqli_query ($con, "select * from `Phòng ban`") or die(mysqli_error());
						while($row = mysqli_fetch_array($sql)){
						$idphong = $row['Mã phòng'];
						$tenphongban=$row['Tên phòng'];
						$check = "";
						if ($maphong == $idphong) $check = " selected";
                        echo "<option style='color:black;' value=".$idphong.$check.">".$tenphongban."</option>";						
						}
						echo "</select>";
						} else {
							echo $phong;
						}
						?>
                    
				</td>
            </tr>
						<?php
						if ($rulelogin != '0') echo '<tr><td>&nbsp;</td></tr>';
						?>
            <tr>
                <td>Chức vụ</td>
                <td>
                     <?php
						if ($rulelogin == '0'){
						echo "<select style='width: 180px;' name='chucvu' id='chucvu' onkeydown='HideError()'>";
						echo "<option value=''>Chọn chức vụ</option>";
						$sql = mysqli_query ($con, "select * from `Chức vụ`") or die(mysqli_error());
						while($row = mysqli_fetch_array($sql)){
						$idchucvu = $row['Mã Chức Vụ'];
						$tenchucvu = $row['Tên chức vụ'];
						$select	= "";
						if ($machucvu == $idchucvu){
							$select = " selected";                       											
						}
						echo "<option style='color:black;' value=".$idchucvu.$select.">".$tenchucvu."</option>";
						}
						echo "</select>";
						} else {
							echo $chucvu;
						}
					?>
				</td>
            </tr>
			<tr id ="admin" >
                <?php
			    if ($rulelogin == '0'){
			    include("quyenadmin.php");
			    }
			    ?>
            </tr>
			
            <tr>
                <td style="color:#F8F8FF;"></td>
                <td><input type="submit" name="submit" value="Cập nhật" /></td>
            </tr>
        
        </tbody>
    </table>
</form>

