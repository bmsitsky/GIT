 <td>Quyền hạn</td>
 <td>
<?php						
						echo "<select style='width: 180px;' name='rule' id='rule' onkeydown='HideError()'>";
						echo "<option value=''>Chọn quyền user</option>";
						$sql = mysqli_query ($con, "select * from `Quyền user` where rule >= 0") or die(mysqli_error());
						while($row = mysqli_fetch_array($sql)){
						$idrule = $row['rule'];
						$tenquyenuser = $row['Tên quyền user'];
						$select	= "";
						if ($rule == $idrule){
							$select = " selected";                       											
						}
						echo "<option style='color:black;' value=".$idrule.$select.">".$tenquyenuser."</option>";
						}
						echo "</select>"
					?>
</td>