<?php 
    include_once '../connection.php';
    if(isset($_POST['submit'])){
		$id = htmlentities(stripslashes($con -> real_escape_string($_REQUEST['id'])));
		$userid = htmlentities(stripslashes($con -> real_escape_string($_POST['userid'])));
        $name = htmlentities(stripslashes($con -> real_escape_string($_POST['name'])));
        $username = htmlentities(stripslashes($con -> real_escape_string($_POST['username'])));
        $phong = htmlentities(stripslashes($con -> real_escape_string($_POST['phong'])));
        $birthday = htmlentities(stripslashes($con -> real_escape_string($_POST['birthday'])));
        $chucvu = htmlentities(stripslashes($con -> real_escape_string($_POST['chucvu'])));
		$rule = htmlentities(stripslashes($con -> real_escape_string($_POST['rule'])));
		
		if ($phong == '' || $chucvu == '' || $rule == ''){
		header("location:../?msg=Hãy chọn và điền đúng thông tin tất cả các trường!&page=edituser");			
		exit;
		}
		
		$format = "Y-m-d";

		if(date($format, strtotime($birthday)) != date($birthday)) {
			header("location:../?msg=Ngày sinh sai định dạng!&page=edituser");	
			ob_end_flush();
			exit;
		}
		
		$sql="select * from user where username = '$username' AND NOT `Mã nhân viên` = '$id'";
		$res=mysqli_query ($con, $sql);
		$checkEmail = "True";
		while($row=mysqli_fetch_assoc($res)){			
			if (!empty($row['username'])){
				$checkEmail = "False";
			}
		}
		if ($checkEmail == "True")
		$insert = "Update user set `Mã nhân viên` = '$userid', `Họ tên` = '$name', username = '$username',`Mã phòng` = '$phong', 
		birthday='$birthday', `Mã chức vụ`='$chucvu', rule='$rule' where `Mã nhân viên` = '$id'";
        $insertqry = mysqli_query ($con, $insert);
        if ($insertqry){
		header("location:../?msg=Sửa thông tin user thành công!&page=listusers");
		exit;
		}
        elseif ($checkEmail == "False") {
			header("location:../?msg=Email bị trùng!&page=edituser");
		} else {
			//echo $insert;
			header("location:../?msg=Mã nhân viên bị trùng hoặc thông tin không hợp lệ!&page=edituser");
		}
    }    
?>
