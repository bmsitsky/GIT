<?php
	session_start();
	$id = $_SESSION['idlogin'];
	$rulelogin = $_SESSION['rule'];
    $qry = mysqli_query ($con, "select * from user LEFT JOIN `Phòng ban` pb
	  ON user.`Mã phòng` = pb.`Mã phòng` LEFT JOIN `Chức vụ` cv
	  ON user.`Mã chức vụ` = cv.`Mã chức vụ` where `Mã nhân viên`='$id'") or die(mysqli_error());
    while($row = mysqli_fetch_array($qry)){
        $id = $row['Mã nhân viên'];
        $name=$row['Họ tên'];
        $username =$row['username'];
        $phong = $row['Tên phòng'];
		$maphong = $row['Mã phòng'];
        $birthday = $row['birthday'];
		$chucvu = $row['Tên chức vụ'];
		$machucvu = $row['Mã chức vụ'];
		$rule = $row['rule'];
    }
?>
<script type="text/javascript" src="assets/js/Registration.js"></script>

<h2 style="text-align: center;">Thông tin tài khoản </h2><br>
<form name="Myform" id="Myform" action="configUserId.php" method="post" style="text-align: center;">
   <div width ="20%" id="error" style="color:red; font-weight:bold;"></div>
    <table align = "center" id="viewdata">
        <thead></thead>
        <tbody>
            <tr>
                <td align = "right" class="control-label col-sm-4"><h4>Username/Email</h4></td>
                <td align = "left" class="control-label col-sm-4"><h4><?php echo $username; ?></h4></td>
            </tr>
            <tr>
                <td align = "right" class="control-label col-sm-4"><h4>Mã nhân viên</h4></td>
                <td align = "left" class="control-label col-sm-4"><h4><?php echo $id; ?></h4></td>
            </tr>
            <tr>
                <td align = "right" class="control-label col-sm-4"><h4>Họ tên</h4></td>
                <td align = "left" class="control-label col-sm-4"><h4><?php echo $name; ?></h4></td>
            </tr>
            <tr>
                <td align = "right" class="control-label col-sm-4"><h4>Ngày sinh</h4></td>
                <td align = "left" class="control-label col-sm-4"><h4><?php echo $birthday; ?></h4></td>
            </tr>
			<tr>
                <td align = "right" class="control-label col-sm-4"><h4>Phòng ban</h4></td>
                <td align = "left" class="control-label col-sm-4"><h4>
						<?php						
						echo $phong;
						?>
                </h4></td>
            </tr>
            <tr>
                <td align = "right" class="control-label col-sm-4"><h4>Chức vụ</h4></td>
                <td align = "left" class="control-label col-sm-4"><h4>
                   <?php echo $chucvu;?>
                </h4></td>
            </tr>
			<tr>
                <td align = "right" class="control-label col-sm-4"><h4>Quyền hạn</h4></td>
                <td align = "left" class="control-label col-sm-4"><h4>
                    <?php if ($rule == 0) echo "Admin"; ?>
					<?php if ($rule == 1) echo "User"; ?>
					<?php if ($rule == 2) echo "Văn thư"; ?>
                </td></h4>
            </tr>
			
            <tr>
                <td align = "right" style = "text-align: center; padding-right:15px;" colspan="2">
				
				<button name="update" type="submit"  class="btn btn-primary">Cập nhật</button>
				</td>
            </tr>
        
        </tbody>
    </table>
</form>

