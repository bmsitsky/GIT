<?php
	session_start();
	$id = $_SESSION['idlogin'];
	$rulelogin = $_SESSION['rule'];
    $qry = mysqli_query ($con, "select * from user LEFT JOIN `Phòng ban` pb
	  ON user.`Mã phòng` = pb.`Mã phòng` LEFT JOIN `Chức vụ` cv
	  ON user.`Mã chức vụ` = cv.`Mã chức vụ` where `Mã nhân viên`='$id'") or die(mysqli_error());
    while($row = mysqli_fetch_array($qry)){
        $id = $row['Mã nhân viên'];
        $name=$row['Họ tên'];
        $username =$row['username'];
        $phong = $row['Tên phòng'];
		$maphong = $row['Mã phòng'];
        $birthday = $row['birthday'];
		$chucvu = $row['Tên chức vụ'];
		$machucvu = $row['Mã chức vụ'];
		$rule = $row['rule'];
    }
?>
<script type="text/javascript" src="assets/js/Registration.js"></script>

<h2 style="text-align: center;">Thông tin tài khoản </h2><br>
<form name="Myform" id="Myform" action="configUserId.php" method="post">
   <div id="error" align = "center" style="color:red; font-size:18px; font-weight:bold;"></div>
    <table align = "center" id="viewdata">
        <thead></thead>
        <tbody>
            <tr>
                <td class ="info">Username/Email &ensp;</td>
                <td class ="info"><?php echo $username?></td>
            </tr>
            <tr>
                <td class ="info">Mã nhân viên</td>
                <td class ="info"><?php echo $id?></td>
            </tr>
            <tr>
                <td class ="info">Họ tên</td>
                <td class ="info"><?php echo $name?></td>
            </tr>
            <tr>
                <td class ="info">Ngày sinh</td>
                <td class ="info"><?php echo $birthday?></td>
            </tr>
			<tr>
                <td class ="info">Phòng ban</td>
                <td class ="info">
						<?php						
						echo $phong;
						?>
                </td>
            </tr>
            <tr>
                <td class ="info">Chức vụ</td>
                <td class ="info">
                   <?php echo $chucvu;?>
                </td>
            </tr>
			<tr>
                <td class ="info">Quyền hạn</td>
                <td class ="info">
                    <?php if ($rule == 0) echo "Admin"; ?>
					<?php if ($rule == 1) echo "User"; ?>
					<?php if ($rule == 2) echo "Văn thư"; ?>
                </td>
            </tr>
			
            <tr>
                <td style = "text-align: center;" colspan="2"><input id="update" type="submit" name="update" value="Cập nhật" /></td>
            </tr>
        
        </tbody>
    </table>
</form>

