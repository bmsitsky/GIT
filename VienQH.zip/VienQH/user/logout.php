        <div class="col-md-12 col-sm-12 col-xs-12">

            <div class="panel panel-default">
                <div align = "center">
                    <h2>LOG OUT!</h2><br>
                </div> 
               
            </div>

        </div>