<?php 
    include_once '../connection.php';
    if(isset($_POST['submit'])){
		echo "submit form";
		$id = htmlentities(stripslashes($con -> real_escape_string($_POST['userid'])));
		$pass = htmlentities(stripslashes($con -> real_escape_string($_POST['password'])));
        $name = htmlentities(stripslashes($con -> real_escape_string($_POST['name'])));
        $username = htmlentities(stripslashes($con -> real_escape_string($_POST['username'])));
        $phong = htmlentities(stripslashes($con -> real_escape_string($_POST['phong'])));
        $birthday = htmlentities(stripslashes($con -> real_escape_string($_POST['birthday'])));
        $chucvu = htmlentities(stripslashes($con -> real_escape_string($_POST['_chucvu'])));
		$rule = htmlentities(stripslashes($con -> real_escape_string($_POST['rule'])));
		session_start();
		ob_start();
		
		$_SESSION['_username'] = $username;
		$_SESSION['userid'] = $id;
		$_SESSION['name'] = $name;
		$_SESSION['birthday'] = $birthday;
		$_SESSION['phong'] = $phong;
		$_SESSION['_chucvu'] = $chucvu;
		$_SESSION['_rule'] = $rule;
		
		if ($rule == ''){
		header("location:../?msg=Hãy chọn và điền đúng thông tin tất cả các trường!&page=adduser");	
		ob_end_flush();
		exit;
		}
		
		$format = "Y-m-d";

		if(date($format, strtotime($birthday)) != date($birthday)) {
			header("location:../?msg=Ngày sinh sai định dạng!&page=adduser");	
			ob_end_flush();
			exit;
		}
		
		$sql="select * from user where username = '$username'";
		$res=mysqli_query ($con, $sql);
		$checkEmail = True;
		while($row=mysqli_fetch_assoc($res)){
			$checkEmail = false;
		}
		
		$sql="select * from user where `Mã nhân viên` = '$id'";
		$res=mysqli_query ($con, $sql);
		$checkId = True;
		while($row=mysqli_fetch_assoc($res)){
			$checkId = false;
		}
		echo $id." name:".$name." phong:".$phong;
		$query = "INSERT INTO user(`Mã nhân viên`,`Họ tên`, `Mã phòng`, `Mã chức vụ`, birthday, username, `password`,  rule ) 
		values ('".$id."', '".$name."', '".$phong."', '".$chucvu."', '".$birthday."', '".$username."', '".$pass."','".$rule."');";
		
		if ($checkId && $checkEmail)
		{
        $insertqry = mysqli_query ($con, $query);
		}
		
		else if (!$checkId){
			header("location:../?msg=Trùng mã nhân viên!&page=adduser");
			ob_end_flush();
			exit;
		}
		else if (!$checkEmail){
			header("location:../?msg=Trùng Email!&page=adduser");
			ob_end_flush();
			exit;
		}
        if ($insertqry){
			$_SESSION['_username'] = "";			
			$_SESSION['userid'] = "";
			$_SESSION['name'] = "";
			$_SESSION['birthday'] = "";
			$_SESSION['phong'] = "";
			$_SESSION['_chucvu'] = "";
			$_SESSION['_rule'] = "";
			header("location:../?msg=Thêm user thành công!&page=listusers");
			ob_end_flush();
			exit;
		}
		else {
			header("location:../?msg=Hãy chọn và điền đúng thông tin tất cả các trường!&page=adduser");
			ob_end_flush();
			exit;
		}
        
    }    
?>
