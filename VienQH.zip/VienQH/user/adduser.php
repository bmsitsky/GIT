<?php
	session_start();
	$username = $_SESSION['_username'];
	$userid = $_SESSION['userid'];
	$name = $_SESSION['name'];
	$birthday = $_SESSION['birthday'];
	$phong = $_SESSION['phong'];
	$chucvu = $_SESSION['_chucvu'];
	$rule = $_SESSION['_rule'];
?>

<script type="text/javascript" src="../assets/js/Registration.js"></script>
<script type="text/javascript" src="assets/js/Registration.js"></script>
<h2 style="text-align: center;">Thêm mới user </h2><br>
<form name="Myform" id="Myform" action="user/addProcess.php" method="post" onsubmit="return(Validate());">
   <div id="error" align = "center" style="color:red; font-size:18px; font-weight:bold;"></div>
    <table align = "center" id="viewdata">
        <thead></thead>
        <tbody>
            <tr>
                <td>Username/Email &ensp;</td>
                <td><input type="email" size="45" name="username" id="username" onkeydown="HideError()" value = "<?php echo $username; ?>" required = ""/></td>
            </tr>
			<tr>
                <td>Mật khẩu</td>
                <td><input type="text" size="45" name="password" id="password" onkeydown="HideError()" value = "" required = ""/></td>
            </tr>
			
            <tr>
                <td>Mã nhân viên</td>
                <td><input type="text" name="userid" id="userid" onkeydown="HideError()" value = "<?php echo $userid; ?>" required = ""/></td>
            </tr>
            <tr>
                <td>Họ tên</td>
                <td><input type="text" name="name" id="name" onkeydown="HideError()" value = "<?php echo $name; ?>" required = ""/></td>
            </tr>
            <tr>
                <td>Ngày sinh</td>
                <td><input type="text" placeholder="yyyy-mm-dd" name="birthday" id="birthday" onkeydown="HideError()" value = "<?php echo $birthday; ?>" required = ""/></td>
            </tr>
			<tr>
                <td>Phòng ban</td>
                <td>
						<?php
						include '../connection.php';
						echo "<select style='width: 180px;' name='phong' id='phong' onkeydown='HideError()'>";
						echo "<option value=''>Chọn phòng ban</option>";
						$sql = mysqli_query ($con, "select * from `Phòng ban`") or die(mysqli_error());
						while($row = mysqli_fetch_array($sql)){
						$idphong = $row['Mã phòng'];
						$tenphongban=$row['Tên phòng'];
						$select	= "";
						if ($phong == $idphong){
						$select = " selected";            											
						}
						echo "<option style='color:black;' value=\"".$idphong."\"".$select.">".$tenphongban."</option>";		
						}
						echo "</select>"
						?>
                    
                </td>
            </tr>
            <tr>
                <td>Chức vụ</td>
                <td>
                    <?php
						echo "<select style='width: 180px;' name='_chucvu' id='chucvu' onkeydown='HideError()'>";
						echo "<option value=''>Chọn chức vụ</option>";
						$sql = mysqli_query ($con, "select * from `Chức vụ`") or die(mysqli_error());
						while($row = mysqli_fetch_array($sql)){
						$idchucvu = $row['Mã Chức Vụ'];
						$tenchucvu = $row['Tên chức vụ'];
						$select	= "";
						if ($chucvu == $idchucvu){
							$select = " selected";                       											
						}
						echo "<option style='color:black;' value=\"".$idchucvu."\"".$select.">".$tenchucvu."</option>";
						}
						echo "</select>"
					?>
                </td>
            </tr>
			<tr>
                <td>Quyền hạn</td>
                <td>
                    <?php						
						echo "<select style='width: 180px;' name='rule' id='rule' onkeydown='HideError()'>";
						echo "<option value=''>Chọn quyền user</option>";
						$sql = mysqli_query ($con, "select * from `Quyền user` where rule >= 0") or die(mysqli_error());
						while($row = mysqli_fetch_array($sql)){
						$idrule = $row['rule'];
						$tenquyenuser = $row['Tên quyền user'];
						$select	= "";
						if ($rule == $idrule){
							$select = " selected";                       											
						}
						echo "<option style='color:black;' value=\"".$idrule."\"".$select.">".$tenquyenuser."</option>";
						}
						echo "</select>"
					?>
                </td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="submit" value="Thêm" /></td>
            </tr>
        
        </tbody>
    </table>
</form>

