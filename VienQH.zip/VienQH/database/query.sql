show databases;
use quanlyvanban;
select * from user;
select * from `Phòng ban`;
select * from `Chức vụ`;
select * from `Quyền user`;
select * from `Công việc`;
-----
use quanlyvanban;
select * from `Công việc`;
select * from `Văn bản`;
select * from `Quan hệ cấp độ`;

show databases;
show schemas;

describe `Công việc`;

ALTER TABLE `Công việc`
ADD COLUMN `Cấp độ` Int(10) NULL AFTER `Trạng thái`;

ALTER TABLE `Văn bản`
ADD COLUMN `Trạng thái` Varchar(45) NULL AFTER `Nơi lưu bản cứng`;

CREATE TABLE IF NOT EXISTS `quanlyvanban`.`Quan hệ cấp độ` (
  `Mã công việc cha` INT(11) NOT NULL,
  `Mã công việc con` INT(11) NOT NULL,
  PRIMARY KEY (`Mã công việc cha`),
   FOREIGN KEY (`Mã công việc con`)
    REFERENCES `quanlyvanban`.`Công việc` (`Mã công việc`)
    )
ENGINE = InnoDB;
-----
select fdk.`Mã File`, fdk.`Tên file`, fdk.`Loại file`, fdk.`Nơi lưu` as noiluu, 
								cv.*, qhcv.`MCV gốc`, u1.`Họ tên` as `Tên người nhận`, u2.`Họ tên` as `Tên người gửi`, 
								pb.`Tên phòng` as `Tên phòng nhận`, pb2.`Tên phòng` as `Tên phòng gửi`, gvn.* 
								from `Phòng ban` pb INNER JOIN user u1	
								ON pb.`Mã phòng` = u1.`Mã phòng` INNER JOIN `gửi và nhận cv` gvn								
								ON u1.`Mã nhân viên` = gvn.`Mã người duyệt` INNER JOIN user u2 
								ON gvn.`Mã người gửi` = u2.`Mã nhân viên` INNER JOIN `Phòng ban` pb2
								ON pb2.`Mã phòng` = u2.`Mã phòng` INNER JOIN `Công việc` cv
								ON gvn.`Mã công việc` = cv.`Mã công việc` INNER JOIN `Quan hệ công việc` qhcv
								ON cv.`Mã công việc` = qhcv.`MCV con` LEFT JOIN `Đính kèm cv` dkcv
								ON cv.`Mã công việc` = dkcv.`Mã công việc` LEFT JOIN `file đính kèm` fdk
								ON dkcv.`Mã File` = fdk.`Mã File` Where cv.`Mã công việc` = '3';

CREATE TABLE IF NOT EXISTS `quanlyvanban`.`Quan hệ công việc` (
  `MCV gốc` INT(11) NOT NULL,
  `MCV con` INT(11) NOT NULL,
  PRIMARY KEY (`MCV con`),
   FOREIGN KEY (`MCV gốc`)
    REFERENCES `quanlyvanban`.`Công việc` (`Mã công việc`),
     FOREIGN KEY (`MCV con`)
    REFERENCES `quanlyvanban`.`Công việc` (`Mã công việc`)
    )
ENGINE = InnoDB;



CREATE TABLE IF NOT EXISTS `quanlyvanban`.`Comment` (
  `Mã công việc` INT(11) NOT NULL,
  `Mã comment` INT(11) NOT NULL,
  `Nội dung` VARCHAR(150) NOT NULL,
  PRIMARY KEY (`Mã comment`),
   FOREIGN KEY (`Mã công việc`)
    REFERENCES `quanlyvanban`.`Công việc` (`Mã công việc`)
    )
ENGINE = InnoDB;
select * from `văn bản`;
ALTER TABLE `văn bản` DROP COLUMN `Trạng thái`;
ALTER TABLE `công việc` CHANGE `Mã công việc` `Mã công việc` INT(11) NOT NULL AUTO_INCREMENT ;
ALTER TABLE `Văn bản` CHANGE `Loại File` `Loại File` Varchar(45) NULL ;
ALTER TABLE `Văn bản` CHANGE `Nơi lưu` `Nơi lưu` Varchar(100) NULL ;
ALTER TABLE `Văn bản` CHANGE `Tên VB` `Tên VB` Varchar(90) NOT NULL ;
ALTER TABLE `Văn bản` CHANGE `Trích yếu` `Trích yếu` Varchar(200) NULL ;
describe `Văn bản`;
describe `Công việc`;
ALTER TABLE `Công việc` CHANGE `Tên công việc` `Tên công việc` Varchar(90) NOT NULL ;
ALTER TABLE `Công việc` CHANGE `Nơi lưu` `Nơi lưu` Varchar(100) NOT NULL;
ALTER TABLE `Công việc` CHANGE `Mô tả` `Mô tả` Varchar(200) NULL ;

ALTER TABLE `comment` CHANGE `Mã comment` `Mã comment` INT(11) NOT NULL AUTO_INCREMENT ;
ALTER TABLE `file đính kèm` CHANGE `Mã File` `Mã File` INT(11) NOT NULL AUTO_INCREMENT ;
ALTER TABLE `gửi và nhận vb` CHANGE `Thời gian gửi` `Thời gian gửi` DATETIME NOT NULL;
ALTER TABLE `gửi và nhận cv` CHANGE `Thời gian gửi` `Thời gian gửi` DATETIME NOT NULL;
ALTER TABLE `gửi và nhận vb` CHANGE `Thời gian nhận` `Thời gian nhận` DATETIME NULL;
ALTER TABLE `gửi và nhận cv` CHANGE `Thời gian nhận` `Thời gian nhận` DATETIME NULL;

Update `Công việc` set `Trạng thái` = 'Đã xong' where `Mã công việc` = 3;
Update `Công việc` set `Trạng thái` = 'Giao việc' where `Mã công việc` = '3';
Update `gửi và nhận cv` set `Trạng thái duyệt` = 'Giao việc' where `Mã công việc` = '3';

SET FOREIGN_KEY_CHECKS = 1;
ALTER TABLE `văn bản`
MODIFY `Mã văn bản` INT(11) UNSIGNED AUTO_INCREMENT;
ALTER TABLE `Comment`
ADD FOREIGN KEY (`Mã nhân viên`) REFERENCES `user`(`Mã nhân viên`);
describe `công việc`;
describe `user`;
show tables;
select * from user LEFT JOIN `Phòng ban` pb
ON user.`Mã phòng` = pb.`Mã phòng`;
select * from `comment`;
select * from `Comment` Where `Mã công việc` = '1';
select * from `đính kèm cv`;
select * from `quan hệ công việc`;
select * from `gửi và nhận vb`;
select * from `gửi và nhận cv`;
select * from `Quyền user`;
select * from `văn bản`;
select * from `công việc`;
select * from `file đính kèm`;
select * from `đính kèm vb`;
select * from user;
describe `gửi và nhận vb`;
describe `user`;
describe `Văn bản`;
select u.* from user u;

select cv.`Tên công việc`, cv.`Mã công việc`, gvn.`Thời gian gửi`, gvn.`Thời gian nhận`, u2.`Họ tên` as `Tên người nhận`, u2.`Mã nhân viên` as `Mã người nhận`,
	  u1.`Họ tên` as `Tên người gửi`, u1.`Mã nhân viên` as `Mã người gửi`, cv.`Mô tả`, cv.`Trạng thái`, cv.`Thời hạn` from `user` u1 INNER JOIN `gửi và nhận cv` gvn
	  ON u1.`Mã nhân viên` = gvn.`Mã người gửi` INNER JOIN `Công việc` cv
	  ON gvn.`Mã công việc` = cv.`Mã công việc` INNER JOIN `user` u2
	  ON gvn.`Mã người duyệt` = u2.`Mã nhân viên` where (u1.`Mã nhân viên` = '1' OR u2.`Mã nhân viên` = '1') 
	  AND cv.`Mã công việc` IN (Select `MCV gốc` from `Quan hệ công việc`) AND cv.`Trạng thái` != 'Phê duyệt' AND cv.`Trạng thái` != 'Hoàn thành' 
	  AND (DATEDIFF(cv.`Thời hạn`,'2020-05-23')<='2' OR cv.`Thời hạn` < '2020-05-23');

INSERT INTO `Văn bản` (`Nơi lưu`, `Tên VB`, `Loại VB`, `Loại File`, `Trích yếu`, `Ngày tạo`, `Số hiệu`, `Nơi lưu bản cứng` ) VALUES ('', 'Test lỗi3', 'Test lỗi', '', 'Test lỗi', '2020-05-20', 'Test lỗi', 'Test lỗi');

select fdk.`Mã File`, fdk.`Tên file`, fdk.`Loại file`, fdk.`Nơi lưu` as noiluu, 
								cv.*, u1.`Họ tên` as `Tên người nhận`, u2.`Họ tên` as `Tên người gửi`, 
								pb.`Tên phòng` as `Tên phòng nhận`, pb2.`Tên phòng` as `Tên phòng gửi`, gvn.* 
								from `Phòng ban` pb INNER JOIN user u1	
								ON pb.`Mã phòng` = u1.`Mã phòng` INNER JOIN `gửi và nhận cv` gvn								
								ON u1.`Mã nhân viên` = gvn.`Mã người duyệt` INNER JOIN user u2 
								ON gvn.`Mã người gửi` = u2.`Mã nhân viên` INNER JOIN `Phòng ban` pb2
								ON pb2.`Mã phòng` = u2.`Mã phòng` INNER JOIN `Công việc` cv
								ON gvn.`Mã công việc` = cv.`Mã công việc` LEFT JOIN `Đính kèm cv` dkcv
								ON cv.`Mã công việc` = dkcv.`Mã công việc` LEFT JOIN `file đính kèm` fdk
								ON dkcv.`Mã File` = fdk.`Mã File` Where cv.`Mã công việc` = '1';

select cv.`Tên công việc`, cv.`Mã công việc`, gvn.`Thời gian gửi`, gvn.`Thời gian nhận`, u2.`Họ tên` as `Họ tên nhận`, u2.`Mã nhân viên` as `Mã người nhận`,
	  u1.`Họ tên` as `Họ tên gửi`, u1.`Mã nhân viên` as `Mã người gửi`, cv.`Mô tả`, cv.`Trạng thái` from `user` u1 INNER JOIN `gửi và nhận cv` gvn
	  ON u1.`Mã nhân viên` = gvn.`Mã người gửi` INNER JOIN `Công việc` cv
	  ON gvn.`Mã công việc` = cv.`Mã công việc` INNER JOIN `user` u2
	  ON gvn.`Mã người duyệt` = u2.`Mã nhân viên` where (u1.`Mã nhân viên` = '1' OR u2.`Mã nhân viên` = '1') 
	  AND cv.`Mã công việc` IN (Select `MCV gốc` from `Quan hệ công việc`);

select fdk.`Mã File`, fdk.`Tên file`, fdk.`Loại file`, fdk.`Nơi lưu` as noiluu, vb.*, u1.`Họ tên`, 
pb.`Tên phòng`, gvn.* 			from `Phòng ban` pb RIGHT JOIN user u1	
								ON pb.`Mã phòng` = u1.`Mã phòng` RIGHT JOIN `gửi và nhận vb` gvn								
								ON u1.`Mã nhân viên` = gvn.`Mã người nhận` RIGHT JOIN user u2 
								ON gvn.`Mã người gửi` = u2.`Mã nhân viên` RIGHT JOIN `Văn bản` vb
								ON gvn.`Mã văn bản` = vb.`Mã văn bản` RIGHT JOIN `Đính kèm vb` dkvb
								ON vb.`Mã văn bản` = dkvb.`Mã VB` RIGHT JOIN `file đính kèm` fdk
								ON dkvb.`Mã File` = fdk.`Mã File` where vb.`Mã văn bản` = '12';

select vb.`Tên VB`, gvn.`Thời gian gửi`, u2.`Họ tên`, vb.`Trích yếu` from `user` u1 INNER JOIN `gửi và nhận vb` gvn
	  ON u1.`Mã nhân viên` = gvn.`Mã người gửi` INNER JOIN `văn bản` vb
	  ON gvn.`Mã văn bản` = vb.`Mã văn bản` INNER JOIN `user` u2
	  ON gvn.`Mã người nhận` = u2.`Mã nhân viên` where u1.`Mã nhân viên` = '1';

Update user set `Họ tên` = 'Tao Ten Dung', username = 'gh@gmail.com', birthday='1997-01-01' where `Mã nhân viên` = '10';
select * from user where user.`Mã nhân viên` = '3';

select * from user INNER JOIN `Phòng ban` pb 
								ON user.`Mã phòng` = pb.`Mã phòng` where user.`Mã chức vụ` = '01' or user.`Mã chức vụ` = 'PVT' or user.`Mã chức vụ` = 'VT' or user.`Mã phòng` = '5HD1';

ALTER TABLE `gửi và nhận cv`
ADD COLUMN `Mã phòng gửi` VARCHAR(45) NOT NULL,
ADD COLUMN `Mã phòng nhận` VARCHAR(45) NOT NULL
 AFTER `Thời gian nhận`;
 
 ALTER TABLE `comment`
ADD COLUMN `Mã nhân viên` VARCHAR(15) NOT NULL;

ALTER TABLE `Công việc`
ADD COLUMN `Loại File` Varchar(45) NOT NULL AFTER `Tên công việc`;


UPDATE user SET rule = '-1' WHERE `Mã nhân viên` = '2';
select * from user LEFT JOIN `Phòng ban` pb
	  ON user.`Mã phòng` = pb.`Mã phòng` LEFT JOIN `Chức vụ` cv
	  ON user.`Mã chức vụ` = cv.`Mã chức vụ`;
      
select * from user where username = 'dung@gmail.com' AND NOT `Mã nhân viên` = '1';
Update user set `Mã nhân viên` = '1', `Họ tên` = 'Mạnh Dũng', username = 'dung@gmail.com',`Mã phòng` = '6LD', birthday='1998-01-08', rule='0' where `Mã nhân viên` = '1';
      
	CREATE TABLE IF NOT EXISTS `quanlyvanban`.`Quyền user` (
  `rule` INT(11) NOT NULL,
  `Tên quyền user` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`rule`))
ENGINE = InnoDB;

insert into `Quyền user` values (0,"Admin"), (1,"User"), (2,"Văn Thư");
select * from `Quyền user`;

INSERT INTO user(`Mã nhân viên`,`Họ tên`, username, `Mã phòng`, birthday, `Mã chức vụ`, rule, password ) 
		values (4, 'ghfhf', 'test66@g.d', '1KT', '1998-09-21', '01','1', '12345');
        
        INSERT INTO user(`Mã nhân viên`,`Họ tên`, `Mã phòng`, `Mã chức vụ`, birthday, username, `password`, rule ) values ('gh56', 'Dung Bui', '1KH', '', '1998-09-09', 'dd@gh.com', '4343','0');