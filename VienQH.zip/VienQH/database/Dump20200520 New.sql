CREATE DATABASE  IF NOT EXISTS `quanlyvanban` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `quanlyvanban`;
-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: quanlyvanban
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `đính kèm cv`
--

DROP TABLE IF EXISTS `đính kèm cv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `đính kèm cv` (
  `Mã công việc` int(11) NOT NULL,
  `Mã File` int(11) DEFAULT NULL,
  PRIMARY KEY (`Mã công việc`),
  KEY `Mã File` (`Mã File`),
  CONSTRAINT `đính kèm cv_ibfk_1` FOREIGN KEY (`Mã công việc`) REFERENCES `công việc` (`Mã công việc`),
  CONSTRAINT `đính kèm cv_ibfk_2` FOREIGN KEY (`Mã File`) REFERENCES `file đính kèm` (`Mã File`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `đính kèm cv`
--

LOCK TABLES `đính kèm cv` WRITE;
/*!40000 ALTER TABLE `đính kèm cv` DISABLE KEYS */;
INSERT INTO `đính kèm cv` VALUES (2,24),(3,25);
/*!40000 ALTER TABLE `đính kèm cv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `đính kèm vb`
--

DROP TABLE IF EXISTS `đính kèm vb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `đính kèm vb` (
  `Mã VB` int(11) NOT NULL,
  `Mã File` int(11) NOT NULL,
  PRIMARY KEY (`Mã VB`,`Mã File`),
  KEY `Mã File` (`Mã File`),
  CONSTRAINT `đính kèm vb_ibfk_1` FOREIGN KEY (`Mã File`) REFERENCES `file đính kèm` (`Mã File`),
  CONSTRAINT `đính kèm vb_ibfk_2` FOREIGN KEY (`Mã VB`) REFERENCES `văn bản` (`Mã văn bản`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `đính kèm vb`
--

LOCK TABLES `đính kèm vb` WRITE;
/*!40000 ALTER TABLE `đính kèm vb` DISABLE KEYS */;
INSERT INTO `đính kèm vb` VALUES (11,5),(12,6),(13,7),(14,8),(19,9),(21,10),(22,11),(24,12),(25,13),(26,14),(28,15),(29,16),(46,23),(50,26),(52,27),(58,28),(59,29),(61,30);
/*!40000 ALTER TABLE `đính kèm vb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `công việc`
--

DROP TABLE IF EXISTS `công việc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `công việc` (
  `Mã công việc` int(11) NOT NULL AUTO_INCREMENT,
  `Tên công việc` varchar(45) DEFAULT NULL,
  `Loại File` varchar(45) NOT NULL,
  `Ngày tạo` date DEFAULT NULL,
  `Nơi sản xuất` varchar(45) DEFAULT NULL,
  `Thời hạn` date DEFAULT NULL,
  `Mô tả` varchar(100) DEFAULT NULL,
  `Nơi lưu` varchar(45) DEFAULT NULL,
  `Trạng thái` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Mã công việc`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `công việc`
--

LOCK TABLES `công việc` WRITE;
/*!40000 ALTER TABLE `công việc` DISABLE KEYS */;
INSERT INTO `công việc` VALUES (1,'Tét công việc 1','doc','0000-00-00','Tét công việc 1','2020-05-21','Tét công việc 1','./upload files/Tét công việc 1.doc','Giao việc'),(2,'Tét 2','doc','0000-00-00','Tét 2','2020-05-19','Tét 2','./upload files/Tét 2.doc','Giao việc'),(3,'Test CV 3','doc','2020-05-20','Test CV 3','2020-05-22','Test CV 3','./upload files/Test CV 3.doc','Đang tiến hành'),(4,'Tét công việc n','doc','2020-05-20','Tét công việc n','2020-05-22','Tét công việc n','./upload files/Tét công việc n.doc','Giao việc'),(5,'Tét công việc 1hhhh','doc','2020-05-20','Tét công việc 1','2020-05-22','f','./upload files/Tét công việc 1hhhh.doc','Giao việc');
/*!40000 ALTER TABLE `công việc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chức vụ`
--

DROP TABLE IF EXISTS `chức vụ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chức vụ` (
  `Mã Chức Vụ` varchar(45) NOT NULL,
  `Tên chức vụ` varchar(45) NOT NULL,
  PRIMARY KEY (`Mã Chức Vụ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chức vụ`
--

LOCK TABLES `chức vụ` WRITE;
/*!40000 ALTER TABLE `chức vụ` DISABLE KEYS */;
INSERT INTO `chức vụ` VALUES ('01','Trưởng phòng'),('02','Phó phòng'),('03','Nhân viên'),('04','Thư ký'),('PVT','Phó viện trưởng'),('VT','Viện trưởng');
/*!40000 ALTER TABLE `chức vụ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `Mã công việc` int(11) NOT NULL,
  `Mã comment` int(11) NOT NULL AUTO_INCREMENT,
  `Nội dung` varchar(150) NOT NULL,
  `Mã nhân viên` varchar(15) NOT NULL,
  PRIMARY KEY (`Mã comment`),
  KEY `Mã công việc` (`Mã công việc`),
  KEY `Mã nhân viên` (`Mã nhân viên`),
  CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`Mã công việc`) REFERENCES `công việc` (`Mã công việc`),
  CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`Mã nhân viên`) REFERENCES `user` (`Mã nhân viên`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,1,'		Comment đầu tiên!','1'),(1,2,'		bhgfhfhyhj','1'),(1,3,'		cm 24253','1');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file đính kèm`
--

DROP TABLE IF EXISTS `file đính kèm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file đính kèm` (
  `Mã File` int(11) NOT NULL AUTO_INCREMENT,
  `Tên file` varchar(45) NOT NULL,
  `Trích yếu` varchar(100) DEFAULT NULL,
  `Loại file` varchar(45) NOT NULL,
  `Nơi lưu` varchar(50) NOT NULL,
  PRIMARY KEY (`Mã File`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file đính kèm`
--

LOCK TABLES `file đính kèm` WRITE;
/*!40000 ALTER TABLE `file đính kèm` DISABLE KEYS */;
INSERT INTO `file đính kèm` VALUES (1,'2.odt',NULL,'application/odt','./attach files/2.odt'),(2,'download.txt',NULL,'application/txt','./attach files/download.txt'),(3,'download2.txt',NULL,'application/txt','./attach files/download2.txt'),(4,'download3.txt',NULL,'application/txt','./attach files/download3.txt'),(5,'download4.txt',NULL,'application/txt','./attach files/download4.txt'),(6,'downloa54.txt',NULL,'application/txt','./attach files/downloa54.txt'),(7,'test test.txt',NULL,'application/txt','./attach files/test test.txt'),(8,'test lat.txt',NULL,'application/txt','./attach files/test lat.txt'),(9,'test 656lat.txt',NULL,'application/txt','./attach files/test 656lat.txt'),(10,'fsfd.txt',NULL,'application/txt','./attach files/fsfd.txt'),(11,'sai nữa đi.txt',NULL,'application/txt','./attach files/sai nữa đi.txt'),(12,'ta thoi.txt',NULL,'application/txt','./attach files/ta thoi.txt'),(13,'Tên  tiếng Việt.txt',NULL,'application/txt','./attach files/Tên  tiếng Việt.txt'),(14,'Nửa tây nửa ta tê.txt',NULL,'application/txt','./attach files/Nửa tây nửa ta tê.txt'),(15,'lsslsls.txt',NULL,'application/txt','./attach files/lsslsls.txt'),(16,'Ký tự đặc biệt đâu đây!.txt',NULL,'application/txt','./attach files/Ký tự đặc biệt đâu đây!.txt'),(17,'Ký tự đặc biệt đâu đâyyy!.txt',NULL,'application/txt','./attach files/Ký tự đặc biệt đâu đâyyy!.txt'),(18,'Ký tự đặc biệt đâu đeâyyy!.txt',NULL,'application/txt','./attach files/Ký tự đặc biệt đâu đeâyyy!.txt'),(19,'Ký tự đặc biệt đâu đeâyfffyy!.txt',NULL,'txt','./attach files/Ký tự đặc biệt đâu đeâyfffyy!.txt'),(20,'Đi ngủ ngủ Nào.txt',NULL,'txt','./attach files/Đi ngủ ngủ Nào.txt'),(21,'đi là đi ngủ thôi.txt',NULL,'txt','./attach files/đi là đi ngủ thôi.txt'),(22,'đêm hôm.pdf',NULL,'pdf','./attach files/đêm hôm.pdf'),(23,'Đi ngủ được cưa.txt',NULL,'txt','./attach files/Đi ngủ được cưa.txt'),(24,'Nửa tây nửa ta tê.txt',NULL,'txt','./attach files/Nửa tây nửa ta tê.txt'),(25,'Nửa tây nửa ta tê33.txt',NULL,'txt','./attach files/Nửa tây nửa ta tê33.txt'),(26,'test css.txt',NULL,'txt','./attach files/test css.txt'),(27,'Tét tét 1.txt',NULL,'txt','./attach files/Tét tét 1.txt'),(28,'cccccv.txt',NULL,'txt','./attach files/cccccv.txt'),(29,'cccccv3.txt',NULL,'txt','./attach files/cccccv3.txt'),(30,'cccccv34.txt',NULL,'txt','./attach files/cccccv34.txt');
/*!40000 ALTER TABLE `file đính kèm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gửi và nhận cv`
--

DROP TABLE IF EXISTS `gửi và nhận cv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gửi và nhận cv` (
  `Mã công việc` int(11) NOT NULL,
  `Mã người gửi` varchar(15) NOT NULL,
  `Mã người duyệt` varchar(15) NOT NULL,
  `Trạng thái duyệt` varchar(45) DEFAULT NULL,
  `Thời gian gửi` datetime NOT NULL,
  `Thời gian nhận` datetime DEFAULT NULL,
  `Mã phòng nhận` varchar(45) NOT NULL,
  `Mã phòng gửi` varchar(45) NOT NULL,
  PRIMARY KEY (`Mã công việc`,`Mã người gửi`,`Mã người duyệt`),
  KEY `Mã người gửi` (`Mã người gửi`),
  KEY `Mã người duyệt` (`Mã người duyệt`),
  CONSTRAINT `gửi và nhận cv_ibfk_1` FOREIGN KEY (`Mã người gửi`) REFERENCES `user` (`Mã nhân viên`),
  CONSTRAINT `gửi và nhận cv_ibfk_2` FOREIGN KEY (`Mã người duyệt`) REFERENCES `user` (`Mã nhân viên`),
  CONSTRAINT `gửi và nhận cv_ibfk_3` FOREIGN KEY (`Mã công việc`) REFERENCES `công việc` (`Mã công việc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gửi và nhận cv`
--

LOCK TABLES `gửi và nhận cv` WRITE;
/*!40000 ALTER TABLE `gửi và nhận cv` DISABLE KEYS */;
INSERT INTO `gửi và nhận cv` VALUES (1,'1','2','Giao việc','2020-05-19 21:51:52',NULL,'6LD','5HD1'),(2,'1','1','','2020-05-19 22:08:54','2020-05-20 07:34:04','5HD1','5HD1'),(3,'1','nv12','Đang tiến hành','2020-05-20 00:03:43','2020-05-20 06:40:42','1KH','5HD1'),(4,'1','th56','Giao việc','2020-05-20 01:49:00',NULL,'1KT','5HD1'),(5,'1','nv12','Giao việc','2020-05-20 03:19:15','2020-05-20 06:41:39','1KH','5HD1');
/*!40000 ALTER TABLE `gửi và nhận cv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gửi và nhận vb`
--

DROP TABLE IF EXISTS `gửi và nhận vb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gửi và nhận vb` (
  `Mã văn bản` int(11) NOT NULL,
  `Mã người gửi` varchar(15) NOT NULL,
  `Mã người nhận` varchar(15) NOT NULL,
  `Thời gian gửi` datetime NOT NULL,
  `Thời gian nhận` datetime DEFAULT NULL,
  `Mã phòng gửi` varchar(45) NOT NULL,
  `Mã phòng nhận` varchar(45) NOT NULL,
  PRIMARY KEY (`Mã văn bản`,`Mã người gửi`,`Mã người nhận`),
  KEY `Mã người gửi` (`Mã người gửi`),
  KEY `Mã người nhận` (`Mã người nhận`),
  CONSTRAINT `gửi và nhận vb_ibfk_1` FOREIGN KEY (`Mã văn bản`) REFERENCES `văn bản` (`Mã văn bản`),
  CONSTRAINT `gửi và nhận vb_ibfk_2` FOREIGN KEY (`Mã người gửi`) REFERENCES `user` (`Mã nhân viên`),
  CONSTRAINT `gửi và nhận vb_ibfk_3` FOREIGN KEY (`Mã người nhận`) REFERENCES `user` (`Mã nhân viên`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gửi và nhận vb`
--

LOCK TABLES `gửi và nhận vb` WRITE;
/*!40000 ALTER TABLE `gửi và nhận vb` DISABLE KEYS */;
INSERT INTO `gửi và nhận vb` VALUES (12,'1','10','2020-05-17 05:05:35','2020-05-20 00:52:08','5HD1','1KT'),(14,'1','65','2020-05-17 05:05:33',NULL,'5HD1','1KH'),(16,'1','10','2020-05-17 06:05:42',NULL,'5HD1','1KH'),(17,'1','fgffd','2020-05-17 06:05:54',NULL,'5HD1','1KH'),(18,'1','nv1','2020-05-17 06:05:52',NULL,'5HD1','6LD'),(19,'1','10','2020-05-17 06:05:24',NULL,'5HD1','6LD'),(20,'1','3','2020-05-17 19:08:47',NULL,'5HD1',''),(21,'1','nv12','2020-05-17 19:10:45',NULL,'5HD1',''),(22,'1','nv12','2020-05-17 19:15:42',NULL,'5HD1',''),(23,'1','3','2020-05-17 19:19:22',NULL,'5HD1',''),(24,'1','44k','2020-05-17 19:35:25',NULL,'5HD1','1KH'),(25,'1','nv1','2020-05-17 19:38:51',NULL,'5HD1','6LD'),(26,'1','10','2020-05-17 19:40:53',NULL,'5HD1','1KT'),(27,'1','65','2020-05-17 19:43:01',NULL,'5HD1','1KH'),(28,'1','1','2020-05-17 19:43:53','2020-05-20 19:20:40','5HD1','5HD1'),(29,'1','10','2020-05-17 19:52:33',NULL,'5HD1','1KT'),(30,'1','8we','2020-05-17 19:54:16',NULL,'5HD1','1KH'),(31,'1','fgffd','2020-05-17 20:00:21',NULL,'5HD1','1KH'),(32,'1','nv1','2020-05-17 20:05:03',NULL,'5HD1','6LD'),(46,'1','3','2020-05-18 01:14:04',NULL,'5HD1','1KT'),(47,'1','3','2020-05-18 13:49:08',NULL,'5HD1','1KT'),(48,'vanthu','vanthu','2020-05-20 06:07:58','2020-05-20 19:20:26','1VP','1VP'),(49,'vanthu','vanthu','2020-05-20 07:19:58','2020-05-20 19:20:32','1VP','1VP'),(50,'1','123','2020-05-20 17:39:44',NULL,'5HD1','1KH'),(51,'1','65','2020-05-20 17:55:22',NULL,'5HD1','1KH'),(52,'1','2','2020-05-20 18:52:32',NULL,'5HD1','6LD'),(53,'1','65','2020-05-20 18:52:53',NULL,'5HD1','1KH'),(56,'vanthu','vanthu','2020-05-20 19:16:43','2020-05-20 19:20:30','1VP','1VP'),(57,'vanthu','vanthu','2020-05-20 19:21:14','2020-05-20 19:22:23','1VP','1VP'),(58,'vanthu','vanthu','2020-05-20 19:22:13','2020-05-20 19:22:21','1VP','1VP'),(59,'vanthu','vanthu','2020-05-20 19:22:43','2020-05-20 19:25:49','1VP','1VP'),(60,'1','3','2020-05-20 19:23:30',NULL,'5HD1','1KT'),(61,'1','44k','2020-05-20 19:24:12',NULL,'5HD1','1KH');
/*!40000 ALTER TABLE `gửi và nhận vb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nhóm phòng`
--

DROP TABLE IF EXISTS `nhóm phòng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nhóm phòng` (
  `Mã nhóm phòng` varchar(45) NOT NULL,
  `Tên nhóm phòng` varchar(45) NOT NULL,
  PRIMARY KEY (`Mã nhóm phòng`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nhóm phòng`
--

LOCK TABLES `nhóm phòng` WRITE;
/*!40000 ALTER TABLE `nhóm phòng` DISABLE KEYS */;
INSERT INTO `nhóm phòng` VALUES ('01','Các phòng chức năng'),('02','Khối đơn vị sự nghiệp'),('03','Ban quản lý dự án'),('04','Ban thanh tra'),('05','Các hội đồng'),('06','Ban lãnh đạo');
/*!40000 ALTER TABLE `nhóm phòng` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phòng ban`
--

DROP TABLE IF EXISTS `phòng ban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phòng ban` (
  `Mã phòng` varchar(45) NOT NULL,
  `Mã nhóm phòng` varchar(45) NOT NULL,
  `Tên phòng` varchar(45) NOT NULL,
  PRIMARY KEY (`Mã phòng`),
  KEY `Mã nhóm phòng` (`Mã nhóm phòng`),
  CONSTRAINT `phòng ban_ibfk_1` FOREIGN KEY (`Mã nhóm phòng`) REFERENCES `nhóm phòng` (`Mã nhóm phòng`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phòng ban`
--

LOCK TABLES `phòng ban` WRITE;
/*!40000 ALTER TABLE `phòng ban` DISABLE KEYS */;
INSERT INTO `phòng ban` VALUES ('1KH','01','Kế hoạch tài chính'),('1KT','01','Quản lý Kĩ thuật, hạ tầng'),('1QT','01','NCPT & Hợp tác quốc tế'),('1VP','01','Văn phòng'),('2CN','02','Trung tâm nghiên cứu Khoa học & ứng dụng chuy'),('2NC','02','Trung tâm nghiên cứ QHKT đô thị, nông thôn'),('2QH1','02','Trung tâm QHKT 1'),('2QH2','02','Trung tâm QHKT 2'),('2QH3','02','Trung tâm QHKT 3'),('3DA','03','Quản lý dự án'),('4TT','04','Phòng thanh tra'),('5HD1','05','Hội đồng 1'),('5HD2','05','Hội đồng 2'),('6LD','06','Phòng lãnh đạo');
/*!40000 ALTER TABLE `phòng ban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quan hệ công việc`
--

DROP TABLE IF EXISTS `quan hệ công việc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quan hệ công việc` (
  `MCV gốc` int(11) NOT NULL,
  `MCV con` int(11) NOT NULL,
  PRIMARY KEY (`MCV con`),
  KEY `MCV gốc` (`MCV gốc`),
  CONSTRAINT `quan hệ công việc_ibfk_1` FOREIGN KEY (`MCV gốc`) REFERENCES `công việc` (`Mã công việc`),
  CONSTRAINT `quan hệ công việc_ibfk_2` FOREIGN KEY (`MCV con`) REFERENCES `công việc` (`Mã công việc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quan hệ công việc`
--

LOCK TABLES `quan hệ công việc` WRITE;
/*!40000 ALTER TABLE `quan hệ công việc` DISABLE KEYS */;
INSERT INTO `quan hệ công việc` VALUES (1,1),(2,2),(3,3),(3,4),(3,5);
/*!40000 ALTER TABLE `quan hệ công việc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quyền user`
--

DROP TABLE IF EXISTS `quyền user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quyền user` (
  `rule` int(11) NOT NULL,
  `Tên quyền user` varchar(45) NOT NULL,
  PRIMARY KEY (`rule`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quyền user`
--

LOCK TABLES `quyền user` WRITE;
/*!40000 ALTER TABLE `quyền user` DISABLE KEYS */;
INSERT INTO `quyền user` VALUES (-1,'Banned'),(0,'Admin'),(1,'User'),(2,'Văn Thư');
/*!40000 ALTER TABLE `quyền user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `Mã nhân viên` varchar(15) NOT NULL,
  `Họ tên` varchar(45) NOT NULL,
  `Mã phòng` varchar(45) NOT NULL,
  `Mã chức vụ` varchar(45) NOT NULL,
  `birthday` date NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `rule` int(11) DEFAULT NULL,
  PRIMARY KEY (`Mã nhân viên`),
  KEY `Mã chức vụ` (`Mã chức vụ`),
  KEY `Mã phòng` (`Mã phòng`),
  KEY `rule` (`rule`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`Mã chức vụ`) REFERENCES `chức vụ` (`Mã Chức Vụ`),
  CONSTRAINT `user_ibfk_2` FOREIGN KEY (`Mã phòng`) REFERENCES `phòng ban` (`Mã phòng`),
  CONSTRAINT `user_ibfk_3` FOREIGN KEY (`rule`) REFERENCES `quyền user` (`rule`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('1','Mạnh Dũng','5HD1','02','1998-01-08','dung@gmail.com','12345',0),('10','Tao Ten Dung','1KT','01','1997-01-01','gh@gmail.com','1234',1),('123','ssgdf','1KH','02','0000-00-00','dgfgd@g.k','fgdgf',1),('2','Nguyễn Tiến Đạt G','6LD','PVT','1997-03-03','dat22@gmail.com','12345678',1),('3','Nguyễn Đạt G','1KT','02','1998-08-09','dat33@gmail.com','12345678',1),('4','ghfhf','1KT','03','1998-09-21','test66@g.d','12345',1),('44k','fgdg','1KH','02','1999-07-07','ffff@g.k','f',0),('65','Dung Bui','1KH','01','1998-09-09','dd@gh.com','ttret',0),('8we','hfhjygjgj','1KH','02','0000-00-00','t@g.f','132132',0),('er2','Test name','1KH','03','1998-08-01','a@gg.c','53533',1),('ffu','gdfhf','1KT','04','0000-00-00','hjh@g.k','rtetre',1),('fgffd','fgtthtgf','1KH','02','0000-00-00','hfhfh@g.k','4534534',0),('nv1','Dũng BM','6LD','VT','1997-12-12','test@gmail.com','12345678',1),('nv12','test admin','1KH','02','1997-01-01','adminff@g.g','12345',2),('th56','Đi Ngủ Kh&ocirc;ng','1KT','02','1999-05-05','fgdf@gmail.com','4353',1),('thuky','Thư k&yacute;','1VP','03','2000-01-01','thuky@gmail.com','12345',2),('vanthu','Văn Thư','1VP','04','1997-06-06','vanthu@gmail.com','12345',2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `văn bản`
--

DROP TABLE IF EXISTS `văn bản`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `văn bản` (
  `Mã văn bản` int(11) NOT NULL AUTO_INCREMENT,
  `Nơi lưu` varchar(45) DEFAULT NULL,
  `Tên VB` varchar(45) NOT NULL,
  `Loại VB` varchar(45) NOT NULL,
  `Loại File` varchar(45) DEFAULT NULL,
  `Trích yếu` varchar(100) DEFAULT NULL,
  `Ngày tạo` date NOT NULL,
  `Số hiệu` varchar(45) NOT NULL,
  `Nơi lưu bản cứng` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Mã văn bản`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `văn bản`
--

LOCK TABLES `văn bản` WRITE;
/*!40000 ALTER TABLE `văn bản` DISABLE KEYS */;
INSERT INTO `văn bản` VALUES (2,'./upload files/Test CDE.doc','Test CDE.doc','Test','application/doc','CDE','2020-05-17','cde1',NULL),(4,'./upload files/Test ko DK.docx','Test ko DK.docx','khong DK','application/docx','ko DK','2020-05-16','test2',NULL),(5,'./upload files/jgj.pdf','jgj.pdf','jgj','application/pdf','jghj','2020-05-13','jgjh',NULL),(6,'./upload files/Test txt.doc','Test txt.doc','ok','application/doc','Test txt','2020-05-17','txt 2',NULL),(8,'./upload files/Test CDE4.doc','Test CDE4.doc','Test CDE','application/doc','Test CDE','2020-05-27','Test CDE',NULL),(9,'./upload files/TEST CDE 5.doc','TEST CDE 5.doc','CDE','application/doc','CDE 5','2020-05-21','CDE 5',NULL),(10,'./upload files/Test ABC.doc','Test ABC.doc','Test ABC','application/doc','Test ABC','2020-05-17','Test ABC',NULL),(11,'./upload files/Test ABC 6.doc','Test ABC 6.doc','Test ABC 6','application/doc','Test ABC 6','2020-05-17','Test ABC 6',NULL),(12,'./upload files/Test cuoi ngay.doc','Test cuoi ngay.doc','Test cuoi ngay','application/doc','Test cuoi ngay','2020-05-17','Test cuoi ngay','Nhà tôi'),(13,'./upload files/Test Cuoi ngay 2.doc','Test Cuoi ngay 2.doc','Test Cuoi ngay 2','application/doc','Test Cuoi ngay 2','2020-05-16','Test Cuoi ngay 2',NULL),(14,'./upload files/Test LAST.doc','Test LAST.doc','Test LAST','application/doc','Test LAST','2020-05-16','Test LAST',NULL),(15,'./upload files/Test Last not DK.doc','Test Last not DK.doc','Test Last not DK','application/doc','Test Last not DK','2020-05-14','Test Last not DK',NULL),(16,'./upload files/Test cuoi cuoi ngay!!.doc','Test cuoi cuoi ngay!!.doc','ryhrtryr','application/doc','hhythtyh','2020-05-17','ryhrtr',NULL),(17,'./upload files/Test cuoi cua cuoi.doc','Test cuoi cua cuoi.doc','Test cuoi cua cuoi','application/doc','Test cuoi cua cuoi','2020-05-17','Test cuoi cua cuoi',NULL),(18,'./upload files/Test Cai CC.doc','Test Cai CC.doc','Test Cai CC','application/doc','Test Cai CC','2020-05-17','Test Cai CC',NULL),(19,'./upload files/Thử coi sao.doc','Thử coi sao.doc','Thử coi sao','application/doc','Thử coi sao','2020-05-17','Thử coi sao',NULL),(20,'./upload files/Để xem sao!!!.doc','Để xem sao!!!.doc','Để xem sao!!!','application/doc','Để xem sao!!!','2020-05-17','Để xem sao!!!',NULL),(21,'./upload files/test cuoi cung ng&agrave;y.doc','test cuoi cung ng&agrave;y.doc','test cuoi cung ng&agrave;y','application/doc','test cuoi cung ng&agrave;y','2020-05-16','test cuoi cung ng&agrave;y',NULL),(22,'./upload files/Thử sai nữa coi!!.doc','Thử sai nữa coi!!.doc','Thử sai nữa coi!!','application/doc','Thử sai nữa coi!!','2020-05-17','Thử sai nữa coi!!',NULL),(23,'./upload files/ytrt6u6yruty.doc','ytrt6u6yruty.doc','Test ABt','application/doc','tyutyuytutfu','2020-05-17','uututu',NULL),(24,'./upload files/Ten tieng anh.doc','Ten tieng anh.doc','Ten tieng anh','application/doc','Ten tieng anh','2020-05-17','Ten tieng anh',NULL),(25,'./upload files/T&ecirc;n  tiếng Việt.doc','T&ecirc;n  tiếng Việt.doc','T&ecirc;n  tiếng Việt','application/doc','T&ecirc;n  tiếng Việt','2020-05-17','T&ecirc;n  tiếng Việt',NULL),(26,'./upload files/Nửa t&acirc;y nửa ta t&ecirc;.','Nửa t&acirc;y nửa ta t&ecirc;.doc','Nửa t&acirc;y nửa ta t&ecirc;','application/doc','Nửa t&acirc;y nửa ta t&ecirc;','2020-05-17','Nửa t&acirc;y nửa ta t&ecirc;',NULL),(27,'./upload files/lalla.doc','lalla.doc','lalla','application/doc','lalla','2020-05-17','lalla',NULL),(28,'./upload files/lsslsls.doc','lsslsls.doc','lsslsls','application/doc','lsslsls','2020-05-17','lsslsls',NULL),(29,'./upload files/K&yacute; tự đặc biệt đ&acirc;','The ok r','K&yacute; tự đặc biệt đ&acirc;u đ&acirc;y!','application/doc','K&yacute; tự đặc biệt đ&acirc;u đ&acirc;y!','2020-05-17','K&yacute; tự đặc biệt đ&acirc;u đ&acirc;y!',NULL),(30,'./upload files/K&yacute; tự t&ecirc; t&aacute','Tốt','K&yacute; tự t&ecirc; t&aacute;i','application/doc','K&yacute; tự t&ecirc; t&aacute;i','2020-05-17','K&yacute; tự t&ecirc; t&aacute;i',NULL),(31,'./upload files/T&ecirc;n n&agrave;y kh&oacute','T&ecirc;n n&agrave;y kh&oacute; viáº¿t.doc','T&ecirc;n n&agrave;y kh&oacute; viết lắm','application/doc','T&ecirc;n n&agrave;y kh&oacute; viết lắm','2020-05-17','T&ecirc;n n&agrave;y kh&oacute; viết lắm',NULL),(32,'./upload files/T&ecirc;n n&agrave;y rất kh&oa','T&ecirc;n n&agrave;y rất kh&oacute; viết!.doc','T&ecirc;n n&agrave;y rất kh&oacute; viết!','application/doc','T&ecirc;n n&agrave;y rất kh&oacute; viết!','2020-05-17','T&ecirc;n n&agrave;y rất kh&oacute; viết!',NULL),(33,'./upload files/Test.doc','Học h&agrave;nh g&igrave; tầm n&agrave;y','Học h&agrave;nh g&igrave; tầm n&agrave;y','application/doc','Học h&agrave;nh g&igrave; tầm n&agrave;y','2020-05-17','Học h&agrave;nh g&igrave; tầm n&agrave;y',NULL),(34,'./upload files/Testcc.doc','Thử charset UTF8 xem sao','Thử charset UTF8 xem sao','application/doc','Thử charset UTF8 xem sao','2020-05-17','Thử charset UTF8 xem sao','Thử charset UTF8 xem sao'),(35,'./upload files/một cộng một lớn hơn hai.doc','một cộng một lớn hơn hai','một cộng một lớn hơn hai','application/doc','một cộng một lớn hơn hai','2020-05-21','một cộng một lớn hơn hai','một cộng một lớn hơn hai'),(36,'./upload files/một.doc','một','một','application/doc','một','2020-05-17','một','một'),(37,'./upload files/lám sao.doc','Hai cộng hai','Hai cộng hai','application/doc','Hai cộng hai','2020-05-17','Hai cộng hai','Hai cộng hai'),(38,'./upload files/Đi ngủ n&agrave;o.doc','Đi ngủ n&agrave;o','Đi ngủ n&agrave;o','doc','Đi ngủ n&agrave;o','2020-05-18','Đi ngủ n&agrave;o','Đi ngủ n&agrave;o'),(39,'./upload files/một cộng một lớn hơn haii.doc','một cộng một lớn hơn haii','một cộng một lớn hơn hai','doc','một cộng một lớn hơn hai','2020-05-18','một cộng một lớn hơn hai','một cộng một lớn hơn hai'),(40,'./upload files/một cộng một hơn hai đi ngủ n&','một cộng một hơn hai đi ngủ n&agrave;o Đi Ngủ','gdrgr','doc','một cộng một hơn hai đi ngủ n&agrave;o Đi Ngủ N&agrave;o','2020-05-18','fgds','gddf'),(41,'./upload files/Đi ngủ ngủ N&agrave;o.doc','Đi ngủ ngủ N&agrave;o','Đi ngủ ngủ N&agrave;o','doc','Đi ngủ ngủ N&agrave;o','2020-05-18','Đi ngủ ngủ N&agrave;o','Đi ngủ ngủ N&agrave;o'),(42,'./upload files/Đi ngủ không nào.odt','Đi ngủ không nào','Đi ngủ kh&ocirc;ng n&agrave;o','odt','Đi ngủ kh&ocirc;ng n&agrave;o','2020-05-18','Đi ngủ kh&ocirc;ng n&agrave;o','Đi ngủ kh&ocirc;ng n&agrave;o'),(43,'./upload files/Đi ngủ đi người đẹp.doc','Đi ngủ đi người đẹp','34t3t','doc','một cộng một lớn hơn hai','2020-05-18','fg4','fret'),(44,'./upload files/Bây giờ là thế này.doc','Bây giờ là thế này','VBHC','doc','Bây giờ là thế này','2020-05-18','fsf323','HN'),(45,'./upload files/Tạo văn bản đêm.jpg','Tạo văn bản đêm','Tạo văn bản đêm','jpg','Tạo văn bản đêm','2020-05-18','Tạo văn bản đêm','Tạo văn bản đêm'),(46,'./upload files/Đi ngủ được chưa.doc','Đi ngủ được chưa','Đi ngủ được chưa?','doc','Đi ngủ được chưa?','2020-05-18','Đi ngủ được chưa?','Đi ngủ được chưa?'),(47,'./upload files/Test buổi trưa.doc','Test buổi trưa','Test buổi trưa','doc','Test buổi trưa','2020-05-18','Test buổi trưa','Test buổi trưa'),(48,'./upload files/Van thu Tét.doc','Van thu Tét','Van thu Tét','doc','Van thu Tét','2020-05-20','Van thu Tét','Van thu Tét'),(49,'./upload files/Vawn thuw lai lang.doc','Vawn thuw lai lang','Vawn thuw lai lang','doc','Vawn thuw lai lang','2020-05-20','Vawn thuw lai lang','Vawn thuw lai lang'),(50,'./upload files/fdsgdg.doc','fdsgdg','gdgfd','doc','gdgdg','2020-05-20','gdg','gdgdgfgd'),(51,'./upload files/Test CDEbf.txt','Test CDEbf','Test CDEbf','txt','Test CDEbf','2020-05-20','Test CDEbf','Test CDEbf'),(52,'./upload files/Tét tét 1.doc','Tét tét 1','Tét tét 1','doc','Tét tét 1','2020-05-20','Tét tét 1','Tét tét 1'),(53,'./upload files/Tét tét 2.txt','Tét tét 2','Tét tét 1','txt','Tét tét 1','2020-05-20','Tét tét 1','Tét tét 1'),(54,'','Test lỗi3','Test lỗi','','Test lỗi','2020-05-20','Test lỗi','Test lỗi'),(55,'','Test lỗi3','Test lỗi','','Test lỗi','2020-05-20','Test lỗi','Test lỗi'),(56,'','Test lỗi5','Test lỗi','','Test lỗi','2020-05-20','Test lỗi','Test lỗi'),(57,'./upload files/ccccc.txt','ccccc','ccccc','txt','ccccc','2020-05-20','ccccc','ccccc'),(58,'./upload files/cccccv.txt','cccccv','cccccv','txt','cccccv','2020-05-20','cccccv','cccccv'),(59,'','cccccv3','cccccv','','cccccv','2020-05-20','cccccv','cccccv'),(60,'./upload files/Tét tét 1dd.txt','Tét tét 1dd','Tét tét 1','txt','Tét tét 1','2020-05-20','Tét tét 1','Tét tét 1'),(61,'./upload files/Tét tét 1ddf.txt','Tét tét 1ddf','Tét tét 1ddf','txt','Tét tét 1ddf','2020-05-20','Tét tét 1ddf','Tét tét 1ddf');
/*!40000 ALTER TABLE `văn bản` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-20 19:53:19
