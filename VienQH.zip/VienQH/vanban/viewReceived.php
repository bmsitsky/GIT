       
		
		<div class="col-md-12 col-sm-12 col-xs-12">

            <div class="panel panel-default">
                <div class="panel-heading">
                    Danh sách văn bản đã nhận
                </div> 
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Tên văn bản</th>
                                    <th>Thời gian gửi</th>
                                    <th>Nơi gửi</th>
                                    <th>Trích yếu</th>
                                    <th>Loại văn bản</th>
                                </tr>
                            </thead>
                            <tbody>  
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>