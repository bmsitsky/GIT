<?php
	session_start();
	$id = $_SESSION['idlogin'];
	$rulelogin = $_SESSION['rule'];
	$idvb = $_REQUEST['data'];
    $qry = mysqli_query ($con, "select fdk.`Mã File`, fdk.`Tên file`, fdk.`Loại file`, fdk.`Nơi lưu` as noiluu, vb.*, u1.`Họ tên`, pb.`Tên phòng`, gvn.* from `Phòng ban` pb INNER JOIN user u1	
								ON pb.`Mã phòng` = u1.`Mã phòng` INNER JOIN `gửi và nhận vb` gvn								
								ON u1.`Mã nhân viên` = gvn.`Mã người nhận` INNER JOIN user u2 
								ON gvn.`Mã người gửi` = u2.`Mã nhân viên` INNER JOIN `Văn bản` vb
								ON gvn.`Mã văn bản` = vb.`Mã văn bản` LEFT JOIN `Đính kèm vb` dkvb
								ON vb.`Mã văn bản` = dkvb.`Mã VB` LEFT JOIN `file đính kèm` fdk
								ON dkvb.`Mã File` = fdk.`Mã File` Where u2.`Mã nhân viên` = '$id' AND vb.`Mã văn bản` = '$idvb'");
								
    while($row = mysqli_fetch_array($qry)){
        $tenvb = $row['Tên VB'];
		$sohieu = $row['Số hiệu'];
		$sohieu = $row['Số hiệu'];
		$trichyeu = $row['Trích yếu'];
		$ngaytao = $row['Ngày tạo'];
		$loaivanban = $row['Loại VB'];
		$loaifile = $row['Loại File'];		
		$bancung = $row['Nơi lưu bản cứng'];
		$noinhan = $row['Tên phòng'];
		$thoigiangui = $row['Thời gian gửi'];
		$thoigiannhan = $row['Thời gian nhận'];
		$tendinhkem = $row['Tên file'];
		$loaidk = $row['Loại file'];
		$saveVB = $row['Nơi lưu'];
		$saveDK = $row['noilưu'];
    }
?>
<script type="text/javascript" src="assets/js/Registration.js"></script>

<h2 style="text-align: center; padding-right:70px;">Thông tin văn bản</h2><br>
<form name="Myform" id="Myform" action="configUserId.php" method="post">
    <table align = "center" id="viewdata">
			<tr>
			<td colspan='2' style="text-align: left; font-size: 30px;">
				
			</td>
			</tr>
            <tr>
                <td class ="info">Tên văn bản</td>
				<td class ="info"><?php echo $tenvb; ?></td>
            </tr>   
                <td class ="info">Số hiệu</td>   
				<td class ="info"><?php echo $sohieu; ?></td>
            </tr> 
                <td class ="info">Trích yếu</td>
				<td class ="info"><?php echo $trichyeu; ?></td>
            </tr> 
                <td class ="info">Ngày tạo</td> 
				<td class ="info"><?php echo $ngaytao; ?></td>
            </tr> 
                <td class ="info">Loại văn bản</td>  
				<td class ="info"><?php echo $loaivanban; ?></td>
            </tr> 
                <td class ="info">Loại File VB</td> 
				<td class ="info"><?php echo $loaifile; ?></td>
            </tr> 
                <td class ="info">Nơi lưu bản cứng</td>
				<td class ="info"><?php echo $bancung; ?></td>
            </tr> 				
				<td class ="info">Đã gửi đến</td>
				<td class ="info"><?php echo $noinhan; ?></td>
            </tr> 				
				<td class ="info">Thời gian gửi</td>
				<td class ="info"><?php echo $thoigiangui; ?></td>
            </tr> 				
				<td class ="info">Thời gian nhận</td>
				<td class ="info">
				<?php 
				if (!empty($thoigiannhan))
				echo $thoigiannhan; 
				else 
				echo "Chưa được đọc";
				?></td>
            </tr> 				
				<td class ="info">Tải văn bản</td>
				<td class ="info"><a align = "center" href="">Download</a></td>
            </tr> 				
				<td class ="info">Tải tệp đính kèm</td>
				<td class ="info"><a align = "center" href="">Download</a></td>
            </tr>       
    </table>
</form>

