<?php
	session_start();
	$id = $_SESSION['idlogin'];
	$rulelogin = $_SESSION['rule'];
	$idvb = $_REQUEST['data'];
	$type = $_REQUEST['type'];
	$currentPhong = $_SESSION['tenphongUser'];
	$magui = $_REQUEST['nguoigui'];
	$manhan = $_REQUEST['nguoinhan'];
	if ($type == 'sent'){
		$title = 'Đã gửi đến';
	} else {
		$title = 'Được gửi bởi';
	}
    $qry = mysqli_query ($con, "select vb.`Tên VB`, vb.`Số hiệu`, vb.`Trích yếu`, vb.`Loại VB`, vb.`Loại File`, vb.`Nơi lưu bản cứng`, vb.`Nơi gửi`, vb.`Nơi lưu`,
								u1.`Họ tên` as `Tên người nhận`, u2.`Họ tên` as `Tên người gửi`, 
								pb.`Tên phòng` as `Tên phòng nhận`, pb2.`Tên phòng` as `Tên phòng gửi`, gvn.* 
								from `Phòng ban` pb INNER JOIN user u1	
								ON pb.`Mã phòng` = u1.`Mã phòng` INNER JOIN `gửi và nhận vb` gvn								
								ON u1.`Mã nhân viên` = gvn.`Mã người nhận` INNER JOIN user u2 
								ON gvn.`Mã người gửi` = u2.`Mã nhân viên` INNER JOIN `Phòng ban` pb2
								ON pb2.`Mã phòng` = u2.`Mã phòng` INNER JOIN `Văn bản` vb
								ON gvn.`Mã văn bản` = vb.`Mã văn bản` LEFT JOIN `Đính kèm vb` dkvb
								ON vb.`Mã văn bản` = dkvb.`Mã VB` Where vb.`Mã văn bản` = '$idvb' AND gvn.`Mã người gửi` = '$magui' AND gvn.`Mã người nhận` = '$manhan'");
								
    $qrydk = mysqli_query ($con, "select fdk.`Mã File`, fdk.`Tên file`, fdk.`Loại file`, fdk.`Nơi lưu` as noiluu								 
								from `Văn bản` vb LEFT JOIN `Đính kèm vb` dkvb								
								ON vb.`Mã văn bản` = dkvb.`Mã VB` LEFT JOIN `file đính kèm` fdk
								ON dkvb.`Mã File` = fdk.`Mã File` Where vb.`Mã văn bản` = '$idvb'");								
								
    while($row = mysqli_fetch_array($qry)){
		$mavb = $row['Mã văn bản'];
        $tenvb = $row['Tên VB'];
		$nguoigui = $row['Tên người gửi'];
		$nguoinhan = $row['Tên người nhận'];
		$sohieu = $row['Số hiệu'];
		$trichyeu = $row['Trích yếu'];
		$ngaytao = $row['Ngày tạo'];
		$loaivanban = $row['Loại VB'];
		$loaifile = $row['Loại File'];		
		$bancung = $row['Nơi lưu bản cứng'];
		$trangthai = $row['Trạng thái'];
		$manguoigui = $row['Mã người gửi'];
		$manguoinhan = $row['Mã người nhận'];
		$noigui_ = $row['Nơi gửi'];
		if (empty($bancung))
			$bancung = "Không có thông tin";
		$noinhan = $row['Tên phòng nhận'];
		$noigui = $row['Tên phòng gửi'];
		$thoigiangui = $row['Thời gian gửi'];
		$thoigiannhan = $row['Thời gian nhận'];
		$idvb = $row['Mã văn bản'];
		$saveVB = $row['Nơi lưu'];
		
		if (empty($thoigiannhan) && (($noinhan == $currentPhong && $noigui != $currentPhong) || ($manguoigui == $id && $manguoinhan == $id))){
		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiannhan = date("Y-m-d H:i:s", time());
		$queryTime = "UPDATE `gửi và nhận vb` SET `Thời gian nhận` = '$thoigiannhan' WHERE `Mã người gửi` = '$manguoigui' AND `Mã người nhận` = '$manguoinhan' AND `Mã văn bản` = '$mavb'";
		$qryTime = mysqli_query ($con, $queryTime);
	}
		
		if ($noinhan != $currentPhong){
			$noinhan = 'Phòng '.$noinhan;
		} else $noinhan = $nguoinhan;
		if ($noigui != $currentPhong){
			$noigui = 'Phòng '.$noigui;
		} else $noigui = $nguoigui;
    }
?>
<script type="text/javascript" src="assets/js/Registration.js"></script>

<h2 style="text-align: center; padding-right:60px;">Thông tin chi tiết văn bản</h2><br>
<form name="Myform" id="Myform" action="vanban/update.php" method="post">
    <table align = "center" id="viewdata">
			<tr>
			<td colspan='2' style="text-align: left; font-size: 30px;">
				
			</td>
			</tr>
            <tr>
                <td class ="info">Tên văn bản</td>
				<td class ="info"><?php echo $tenvb; ?></td>
            </tr>
			<tr>			
                <td class ="info">Trạng thái</td>   
				<!--td class ="info"></td-->
				<?php
								$s = " selected";
								$s1 = $s2 = $s3 = $s4 = $s5 = '';
								if ($trangthai == 'Đã đọc') $s1 = $s;
								if ($trangthai == 'Đang tiến hành') $s2 = $s;
								if ($trangthai == 'Hoàn thành') $s3 = $s;
								if ($trangthai == 'Chưa hoàn thành') $s4 = $s;
								if ($trangthai == 'Không có') $s5 = $s;
								
								if ($type != 'sent' && $manguoinhan!= 'vanthu') 
								{
									echo "<td>
										<select class='form-control' style='width: 150px; height: 32px;' name='trangthai' id='trangthai' onkeydown='HideError()'>
										<option value='Không có' $s5>Không có</option>
										<option value='Đã đọc' $s1>Đã đọc</option>
										<option value='Đang tiến hành' $s2>Đang tiến hành</option>
										<option value='Hoàn thành' $s3>Hoàn thành</option>";
									echo "</select></td>";

								}
								else
								{
									echo"<td class ='info'>".$trangthai."</td>";
									echo"<input type ='hidden' name='trangthai' value='".$trangthai."'>";
								}
									
				?>
				
			</tr>			
			<tr>			
                <td class ="info">Số hiệu</td>   
				<td class ="info"><?php echo $sohieu; ?></td>
			</tr>
            <tr> 
                <td class ="info">Trích yếu</td>
				<td class ="info"><?php echo $trichyeu; ?></td>
            </tr>
			<?php
				if (!empty($noigui_)){
					           
	  echo '<tr> 
                <td class ="info">Nơi gửi</td>
				<td class ="info">'.$noigui_.'</td>
            </tr>';
				}
			?>
			<tr>
                <td class ="info">Ngày tạo</td> 
				<td class ="info"><?php echo $ngaytao; ?></td>
            </tr> 
			<tr>
                <td class ="info">Loại văn bản</td>  
				<td class ="info"><?php echo $loaivanban; ?></td>
			</tr> 
			<tr>
                <td class ="info">Nơi lưu bản cứng</td>
				<td class ="info"><?php echo $bancung; ?></td>
            </tr> 	
			<tr>			
				<td class ="info"><?php echo $title; ?></td>
				<td class ="info"><?php if ($type == 'sent') echo $noinhan; else echo $noigui; ?></td>
            </tr> 
			<tr>			
				<td class ="info">Thời gian gửi</td>
				<td class ="info"><?php echo $thoigiangui; ?></td>
            </tr> 
			<tr>			
				<td class ="info">Thời gian nhận</td>
				<td class ="info">				
				<?php 
				if (!empty($thoigiannhan))
				echo $thoigiannhan; 
				else 
				echo "Chưa được đọc";
				?></td>
            </tr> 
			
			<?php $downvb='';
				if (!empty($saveVB)){
				$downvb = 
				'<tr> 				
				<td class ="info">Tải văn bản</td>
				<td class ="info"><a align = "center" href="vanban/download.php?type=vanban&data='.$idvb.'">Download </a>(.'.$loaifile.')</td>
				</tr>';
				} 
				echo $downvb;
				while($row = mysqli_fetch_array($qrydk)){
				$tendinhkem = $row['Tên file'];
				$loaidk = $row['Loại file'];
				$saveDK = $row['noilưu'];		
				$idfile = $row['Mã File'];
				$downfile='';
				if (!empty($idfile)){
				$downfile = 
				'<tr> 				
				<td class ="info">Tải tệp đính kèm</td>
				<td class ="info"><a align = "center" href="vanban/download.php?type=file&data='.$idfile.'">Download </a>(.'.$loaidk.')</td>
				</tr>';
				} 
				echo $downfile;
				}
				if ($type != "sent" && $manguoinhan!= 'vanthu'){
					$style = 'style = "text-align: center; padding-right: 70px;"';
				} else $style = 'style = "text-align: center; padding-right: 70px;"';
				?>
			<tr>
                <td <?php echo $style; ?> colspan ='2' style = "padding-left: 10px; padding-right: 10px;">	
				<input type = "hidden" name = "idvb" value = "<?php echo $idvb; ?>">	
				<input type = "hidden" name = "manguoinhan" value = "<?php echo $manguoinhan; ?>">
				<input type = "hidden" name = "manguoigui" value = "<?php echo $manguoigui; ?>">
				
				<?php
				$forward = '<a align = "right" href = "?page=uploadVanban&&idvb='.$idvb.'&type=chuyentiep">
				
					 <button align = "right" name="chuyentiep" type="button"  class="btn btn-primary">Chuyển tiếp</button>
				
					</a>';
				?>			

				<?php
				if ($type != "sent" && $manguoinhan!= 'vanthu'){
					echo '<button align = "center" name="submit" type="submit"  class="btn btn-primary">Cập nhật</button>';
					echo $forward;
					echo '<a href = "?page=createWork&idvb='.$idvb.'&type=phanhoi">
				
						<button align = "left" name="phanhoi" type="button"  class="btn btn-primary">Phản hồi</button>
				
						</a> ';
				} else echo $forward;
				?>
				</td>				
	
            </tr>
				              
    </table>
</form>

