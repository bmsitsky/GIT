<?php
	session_start();
	ob_start();
	$dem = 0;
	function duyet($manguoigui, $manguoinhan, $trangthai, $id) {
	include '../connection.php';		
	$q2 = "Update `gửi và nhận vb` set `Trạng thái` = '$trangthai' 
		   where `Mã văn bản` = '$id' AND `Mã người gửi` = '$manguoigui' AND `Mã người nhận` = '$manguoinhan'";		   
	$res = mysqli_query($con, $q2);
	if ($res){
	$con -> close();
	header("location:../?msg=Cập nhật trạng thái văn bản thành công!&page=viewDetails&type=received&data=".$id."&nguoigui=".$manguoigui."&nguoinhan=".$manguoinhan);
	exit;	
	}else{
	$con -> close();
	header("location:../?msg=Cập nhật trạng thái văn bản không thành công!&page=viewDetails&type=received&data=".$id."&nguoigui=".$manguoigui."&nguoinhan=".$manguoinhan);
	exit;	
	}
	}
	
	if(isset($_POST['submit'])){
		//echo "submit form";
		$manguoinhan = $_POST['manguoinhan'];
		$manguoigui = $_POST['manguoigui'];
		$id = $_POST['idvb'];
		$trangthai = $_POST['trangthai'];
		
		duyet($manguoigui, $manguoinhan, $trangthai, $id);			
	}
?>
