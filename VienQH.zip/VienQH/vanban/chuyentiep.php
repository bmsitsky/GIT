<?php
	session_start();
	include_once 'connection.php'; 

	if(isset($_POST['submit'])){
		//echo "submit form";

		$idvb = $_POST['idvb'];
		$countSend = $_POST['send'];
		$manguoigui = $_SESSION['idlogin'];
		$maphonggui = $_SESSION['MaphongUser'];
		for ($i=0; $i<=$countSend; $i++){
			$j = ($i==0) ? '' : $i;
			$noi = 'noinhan'.$j.'';
			$noinhan[$i] = $_POST[$noi];
			$noi_ = $noinhan[$i];
			$sqls = mysqli_query ($con, "select * from user where user.`Mã nhân viên` = '$noi_'") or die(mysqli_error());
			while($rows=mysqli_fetch_assoc($sqls)){
			$maphongnhan[$i] = $rows['Mã phòng'];
			}
		}

		for ($i=0; $i<=$countSend; $i++){
			for ($j=$i+1; $j<=$countSend; $j++){
				$m = ($i==0) ? '' : $i;
				$n = ($j==0) ? '' : $j;
			$attm = 'noinhan'.$m.'';
			$attn = 'noinhan'.$n.'';
			if ($_POST[$attm] == $_POST[$attn]){
				header('location:../?msg=Người nhận trùng nhau!&page=uploadVanban&idvb='.$idvb.'&type=chuyentiep');
				exit;
				break;
			}
		}
		}
		$con -> close();
		
		$con = mysqli_connect('localhost', 'root', '12345678') or die(mysqli_error($con));
		$db = mysqli_select_db($con,'quanlyvanban');
		$con -> autocommit(FALSE);

		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiangui = date("Y-m-d H:i:s", time());
		
		$getGuiNhan = True;
		for ($k=0; $k<=$countSend && $getGuiNhan; $k++){
			$m = ($k==0) ? '' : $k;							
		$GuiNhan = "INSERT INTO `gửi và nhận vb` (`Mã văn bản`,`Mã người gửi`, `Mã người nhận`, `Thời gian gửi`, `Mã phòng gửi`, `Mã phòng nhận`, `Trạng thái`) ".
					"VALUES ('$idvb', '$manguoigui', '$noinhan[$k]', '$thoigiangui', '$maphonggui', '$maphongnhan[$k]', 'Không có' )";
		$getGuiNhan = mysqli_query ($con,$GuiNhan);
		}
		if ($getGuiNhan){
			$con -> commit();
			$con -> close();
			header("location:../?page=viewSent&msg=Chuyển tiếp văn bản thành công!");
			//echo $qry.'<br>'.$sql.'<br>'.$query;
			exit();	
		} else {
			$con -> rollback();
			$con -> close();
			header('location:../?msg=Chyển tiếp MVB = '.$idvb.' không thành công!&page=uploadVanban&idvb='.$idvb.'&type=chuyentiep');
			//echo $qry.'<br>'.$sql.'<br>'.$query;
			exit();
		}	
	
	}
	
?>
