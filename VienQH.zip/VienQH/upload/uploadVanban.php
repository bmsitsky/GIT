<?php
	session_start();
	$tenvanban = $_SESSION['tenvanban'];
	$sohieu = $_SESSION['sohieu'];
	$trichyeu = $_SESSION['trichyeu'];
	$loaivanban = $_SESSION['loaivanban'];
	$ngaytao = $_SESSION['ngaytao'];
	$bancung = $_SESSION['bancung'];
	$maphonguser = $_SESSION['MaphongUser'];
	$noinhan = $_SESSION['noinhan'];
	$currentID = $_SESSION['idlogin'];
	$type = $_REQUEST['type'];
	$tieude = "Thông tin văn bản";
	$idvb = $_REQUEST['idvb'];
		$link = "upload/uploadProcess.php";
	if ($type == "chuyentiep"){
		$link = "vanban/chuyentiep.php";
		$tieude = "Chuyển tiếp văn bản có Mã = ".$idvb;
	}
	if ($type == "phanhoi"){
		$tieude = "Phản hồi văn bản có Mã = ".$idvb;
	}

?>
		<div class="uplaoder-container__container___1JPbU" style = "width: 100%; padding-top: 50px;">		
		<div id="page-inner">
                <div class="row">
				  <div class="col-md-12 col-sm-12 col-xs-12 text-center" >
				  	<label class=" control-label col-sm-122" ><h3><b><?php echo $tieude; ?></b></h3></label>
				  </div><br><br>
            
			<div class="col-md-7 col-sm-12 col-xs-12" style = "padding-top: 60px;">

			<form class="form-horizontal" name="Myform" id="Myform" action= "<?php echo $link; ?>" method="post" enctype="multipart/form-data" accept-charset="utf-8">

		  <div class="form-group">
			<label class="control-label col-sm-2" for="product-name">Tên văn bản:</label>
			<div class="col-sm-10">
			<?php
			if ($type == "chuyentiep"){
				$findName = mysqli_query ($con, "select `Tên VB` from `Văn bản` where `Mã văn bản` = '$idvb'");
			list($targetName) = mysqli_fetch_array($findName);
			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">'.$targetName.'</p>';
			} else echo '<input name = "tenvanban" id="tenvanban" type="text" value ="'.$tenvanban.'" required="">';
			?>
			
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-sm-2" for="product-name">Trích yếu:</label>
			<div class="col-sm-10">
			<?php
			if ($type == "chuyentiep"){
				$findName = mysqli_query ($con, "select `Trích yếu` from `Văn bản` where `Mã văn bản` = '$idvb'");
			list($targetName) = mysqli_fetch_array($findName);
			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">'.$targetName.'</p>';
			} else echo '<input class="form-control" name = "trichyeu" id="trichyeu" type="text" value ="'.$trichyeu.'" required="">';
			?>						  
			</div>
		  </div>

	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-10">
		<table width ="100%">
		<tr id = "trdk">
		<?php
		if ($type != "chuyentiep"){
			echo '		
			<td width = "20%" align ="left">
			<div style="display: inline-block; position: relative;">
			<button class="btn btn-primary" tabindex="0" type="button" style ="bottom:0;">
				<span class="MuiButton-label">Thêm mới</span>
			</button>
			<input id="703c5a21-b86b-4842-95d4-7a06c4ac7fc0" onchange ="onClickHandler(\'add\')" name ="add" type="file" 
					style="bottom: 0px; height: 100%; left: 0px; margin: 0px; opacity: 0; padding: 0px; position: absolute; right: 0px; top: 0px; width: 100%;">
			</div>
			</td><td width = "20%" align ="left" id ="dk0">
			<div style="display: inline-block; position: relative;" id = "dinhkem0">
			<button class="btn btn-primary" tabindex="0" type="button" style ="bottom:0;">
				<span class="MuiButton-label">Đính kèm</span>

			</button>
			
			<input id="'.$count.'" onchange ="onClickHandler(\'attach\',\''.$count.'\')" onclick ="createAttach(\''.$count.'\')" class="react-fine-uploader-file-input" name = "attach" type="file" 
					style="bottom: 0px; height: 100%; left: 0px; margin: 0px; opacity: 0; padding: 0px; position: absolute; right: 0px; top: 0px; width: 100%;">
			</div>
			</td>';
		}
		?>
			<td align = "right" id = "send0">
			<?php
					echo "<select class='form-control' style='width: 130px;' name='noinhan' id='noinhan0' onchange=\"createSend('".$send."')\" onkeydown='HideError()'>";
					echo "<option value=''>Gửi đến</option>";
					$sql = mysqli_query ($con, "select * from user INNER JOIN `Phòng ban` pb 
								ON user.`Mã phòng` = pb.`Mã phòng` where user.`Mã chức vụ` = '01' or user.`Mã chức vụ` = 'PVT' or user.`Mã chức vụ` = 'VT' or (user.`Mã phòng` = '$maphonguser' AND user.`Mã nhân viên` != 'vanthu')") or die(mysqli_error());
					while($row = mysqli_fetch_array($sql)){
					$idUser = $row['Mã nhân viên'];
					$sendtoUser = $row['Họ tên'];
					$sendtoPhong = $row['Tên phòng'];
					if ($idUser == $currentID){
						$sendtoUser = "Tôi";
					} else {
					if ($row['Mã chức vụ'] == '01'){
						$sendtoUser = $sendtoPhong;
					}
					//if ($row['Mã chức vụ'] == '02'){
					//	$sendtoUser = 'Phó phòng '.$sendtoPhong;
					//}
					if ($row['Mã chức vụ']=='PVT'){
						$sendtoUser = 'Phó Viện Trưởng';
					}
					if ($row['Mã chức vụ']=='VT'){
						$sendtoUser = 'Viện Trưởng';
					}
					}
					$select	= "";
					if ($noinhan == $idUser){
						$select = " selected";  
						//$maphongnhan = $row['Mã phòng'];
					}
					echo '<option style="color:black;" value="'.$idUser.'"'.$select.'>'.$sendtoUser.'</option>';
					}
					echo "</select>";
					//echo '<input type ="hidden" name = "maphongnhan" value = "'.$maphongnhan.'"/>';
					?>
					</td></tr>
					</table>
		</div>
	</div>
	
	<div class="form-group">
	<div class="col-sm-offset-2 col-sm-10">
		<table width ="100%"><tr>
		<?php
		if ($type != "chuyentiep"){
			echo '
		<td width = "20%" style ="padding-right:60px;">
				<div class="progress">
				<div class="progress-bar progress-bar-striped active" id="add" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="color: #F5F5F5; width:0%;">
				</div>
				</div>
		</td>
		<td width = "20%" style ="padding-right:60px;">	
				<div class="progress">
				<div class="progress-bar progress-bar-striped active" id="attach" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="color: #F5F5F5; width:0%;">
				</div>
				</div>
		</td>';
		}
	?>
		<td align ="right"><button name="submit" type="submit"  class="btn btn-success" id="upload">Gửi đi</button></td>		
		</tr></table>
		</div>			
	</div>

	</div>

    <div class="col-md-5 col-sm-12 col-xs-12" style = "padding-top: 60px;">
		
		<div class="form-group">
			<label class="control-label col-sm-4" for="product-name">Số hiệu</label>
			<div class="col-sm-8">
			<?php
			if ($type == "chuyentiep"){
				$findName = mysqli_query ($con, "select `Số hiệu` from `Văn bản` where `Mã văn bản` = '$idvb'");
			list($targetName) = mysqli_fetch_array($findName);
			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">'.$targetName.'</p>';
			} else echo '<input class="form-control" name = "sohieu" id="sohieu" type="text" value ="'.$sohieu.'" required="">';
			?>
			  
			</div>
		 </div>
		 <div class="form-group">
			<label class="control-label col-sm-4" for="product-name">Loại văn bản</label>
			<div class="col-sm-8">
			<?php
			if ($type == "chuyentiep"){
				$findName = mysqli_query ($con, "select `Loại VB` from `Văn bản` where `Mã văn bản` = '$idvb'");
			list($targetName) = mysqli_fetch_array($findName);
			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">'.$targetName.'</p>';
			} else echo '<input class="form-control" name = "loaivanban" id="loaivanban" type="text" value ="'.$loaivanban.'" required="">';
			?>
			  
			</div>
		 </div>
		 <div class="form-group">
			<label class="control-label col-sm-4" for="product-name">Nơi lưu bản cứng</label>
			<div class="col-sm-8">
			<?php
			if ($type == "chuyentiep"){
				$findName = mysqli_query ($con, "select `Nơi lưu bản cứng` from `Văn bản` where `Mã văn bản` = '$idvb'");
			list($targetName) = mysqli_fetch_array($findName);
			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">'.$targetName.'</p>';
			} else echo '<input class="form-control" name = "bancung" type="text" value="'.$bancung.'">';
			?>
			  
			</div>
		 </div>
		   <div class="form-group">
			<label class="control-label col-sm-4" for="pwd">Ngày tạo</label>
			<div class="col-sm-8">
			<?php
			if ($type == "chuyentiep"){
				$findName = mysqli_query ($con, "select `Nơi lưu bản cứng` from `Văn bản` where `Mã văn bản` = '$idvb'");
			list($targetName) = mysqli_fetch_array($findName);
			echo '<p class="form-control" style = "border-style: none; -webkit-box-shadow: none; -moz-box-shadow: none; box-shadow: none;">'.$targetName.'</p>';
			} else { 
			echo '<input class="form-control" name = "ngaytao" type="date" value="';
			if (isset($_SESSION['ngaytao'])) echo $_SESSION['ngaytao'];
			else echo date('Y-m-d');
			echo '" required="">';
			$con -> close();
			}
			?>
			<input type = "hidden" name ="idvb" value = "<?php echo $idvb; ?>">	
			</div>
		 </div>

		 </div>
		<input id= "count" type ="hidden" name = "count" value = "0"/>
		<input id= "send" type ="hidden" name = "send" value = "0"/>
		<input id= "checkAttach" type ="hidden" name = "checkAttach" value = "false"/>
		</form>
		 </div>
		 
    </div>
            
</div>        
</div>
</div>

				
              