<?php
	session_start();
	$tenvanban = $_SESSION['tenvanban'];
	$sohieu = $_SESSION['sohieu'];
	$trichyeu = $_SESSION['trichyeu'];
	$loaivanban = $_SESSION['loaivanban'];
	$ngaytao = $_SESSION['ngaytao'];
	$bancung = $_SESSION['bancung'];
	$maphonguser = $_SESSION['MaphongUser'];
	$noinhan = $_SESSION['noinhan'];
	$noigui = $_SESSION['noigui'];
	$currentID = $_SESSION['idlogin'];
	//$maphongnhan = $_SESSION['maphongnhan'];
?>
		<div class="uplaoder-container__container___1JPbU" style = "width: 100%; padding-top: 50px;">		
		<div id="page-inner">
                <div class="row">
				  <div class="col-md-12 col-sm-12 col-xs-12 text-center" >
				  	<label class=" control-label col-sm-122" ><h3><b>[Văn thư] Nhập văn bản</b></h3></label>
				  </div><br><br>
            
			<div class="col-md-7 col-sm-12 col-xs-12" style = "padding-top: 60px;">

			<form class="form-horizontal" name="Myform" id="Myform" action= "upload/uploadProcess.php" method="post" enctype="multipart/form-data" accept-charset="utf-8">

		  <div class="form-group">
			<label class="control-label col-sm-2" for="product-name">Tên văn bản:</label>
			<div class="col-sm-10">
			  <input name = "tenvanban" id="tenvanban" type="text" value ="<?php echo $tenvanban; ?>" required="">
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-sm-2" for="product-name">Trích yếu:</label>
			<div class="col-sm-10">
			  <input class="form-control" name = "trichyeu" id="trichyeu" type="text" value ="<?php echo $trichyeu; ?>" required="">
			</div>
		  </div>

	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-10">
		<table width ="100%">
		<tr><td width = "20%" align ="left">
			<div style="display: inline-block; position: relative;">
			<button class="btn btn-primary" tabindex="0" type="button" style ="bottom:0;">
				<span class="MuiButton-label">Thêm mới</span>
			</button>
			<input id="703c5a21-b86b-4842-95d4-7a06c4ac7fc0" onchange ="onClickHandler('add')" name ="add" type="file" 
					style="bottom: 0px; height: 100%; left: 0px; margin: 0px; opacity: 0; padding: 0px; position: absolute; right: 0px; top: 0px; width: 100%;">
			</div>			
			</td>
			<?php
			echo '<td width = "20%" align ="left" id ="dk0">
			<div style="display: inline-block; position: relative;" id = "dinhkem0">
			<button class="btn btn-primary" tabindex="0" type="button" style ="bottom:0;">
				<span class="MuiButton-label">Đính kèm</span>

			</button>
			
			<input id="'.$count.'" onchange ="onClickHandler(\'attach\',\''.$count.'\')" onclick ="createAttach(\''.$count.'\')" class="react-fine-uploader-file-input" name = "attach" type="file" 
					style="bottom: 0px; height: 100%; left: 0px; margin: 0px; opacity: 0; padding: 0px; position: absolute; right: 0px; top: 0px; width: 100%;">
			</div>
			</td>';
			?>
			<td>
			Nơi gửi:
			</td>
			<td align = "left">
			<div class="col-sm-14">
			  <input class="form-control" name = "noigui" id="noigui" type="text" value ="<?php echo $noigui; ?>" required="">
			</div>
			</td>
			</tr>
		</table>
		</div>
	</div>
	
	<div class="form-group">
	<div class="col-sm-offset-2 col-sm-10">
		<table width ="100%"><tr>
		<td width = "20%" style ="padding-right:60px;">
				<div class="progress">
				<div class="progress-bar progress-bar-striped active" id="add" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="color: #F5F5F5; width:0%;">
				</div>
				</div>
		</td>
		<td width = "20%" style ="padding-right:60px;">	
				<div class="progress">
				<div class="progress-bar progress-bar-striped active" id="attach" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="color: #F5F5F5; width:0%;">
				</div>
				</div>
		</td>
		<td align ="right"><button name="submit" type="submit"  class="btn btn-success" id="upload">Lưu trữ</button></td>		
		</tr></table>
		</div>			
	</div>

	</div>

    <div class="col-md-5 col-sm-12 col-xs-12" style = "padding-top: 60px;">
		
		<div class="form-group">
			<label class="control-label col-sm-4" for="product-name">Số hiệu</label>
			<div class="col-sm-8">
			  <input class="form-control" name = "sohieu" id="sohieu" type="text" value ="<?php echo $sohieu; ?>" required="">
			</div>
		 </div>
		 <div class="form-group">
			<label class="control-label col-sm-4" for="product-name">Loại văn bản</label>
			<div class="col-sm-8">
			  <input class="form-control" name = "loaivanban" id="loaivanban" type="text" value ="<?php echo $loaivanban; ?>" required="">
			</div>
		 </div>
		 <div class="form-group">
			<label class="control-label col-sm-4" for="product-name">Nơi lưu bản cứng</label>
			<div class="col-sm-8">
			  <input class="form-control" name = "bancung" type="text" value="<?php echo $bancung; ?>">
			</div>
		 </div>
		   <div class="form-group">
			<label class="control-label col-sm-4" for="pwd">Ngày tạo</label>
			<div class="col-sm-8">
			  <input class="form-control" name = "ngaytao" type="date" value="<?php  if (isset($_SESSION['ngaytao'])) echo $_SESSION['ngaytao'];
																								else echo date('Y-m-d'); ?>" required="">
			  <input type ="hidden" name = "noinhan" value = "<?php echo "vanthu"; ?>">	
			  <input type ="hidden" name = "vanthu" value = "<?php echo "True"; ?>">
			  <input id= "count" type ="hidden" name = "count" value = "0"/>
			  <input id= "send" type ="hidden" name = "send" value = "0"/>
			  <input id= "checkAttach" type ="hidden" name = "checkAttach" value = "false"/>			  
			</div>
		 </div>

		 </div>
		
		</form>
		 </div>
		 
    </div>
            
</div>        
</div>
</div>

				
              