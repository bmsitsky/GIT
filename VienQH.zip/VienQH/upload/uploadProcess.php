<?php
	session_start();
	ob_start();
    include_once '../connection.php';
	if(isset($_POST['submit'])){
		//echo "submit form";
		$tenvanban = $_POST['tenvanban'];
		$trichyeu = $_POST['trichyeu'];
		$sohieu = $_POST['sohieu'];
		$loaivanban = $_POST['loaivanban'];
		$ngaytao = $_POST['ngaytao'];
		$bancung = $_POST['bancung'];
		$noinhan = $_POST['noinhan'];
		$vanthu = $_POST['vanthu'];
		//$maphongnhan = htmlentities(stripslashes($con -> real_escape_string($_POST['maphongnhan'])));
		
		$sqls = mysqli_query ($con, "select * from user where user.`Mã nhân viên` = '$noinhan'") or die(mysqli_error());
		while($rows=mysqli_fetch_assoc($sqls)){
			$maphongnhan = $rows['Mã phòng'];
		}
		$con -> close();
		if ($_FILES['add']['size'] > 0){
        $fileName = $_FILES['add']['name'];		
        $tmpName  = $_FILES['add']['tmp_name'];		
        $fileSize = $_FILES['add']['size'];
        //$fileType = $_FILES['add']['type'];
		
		$split = explode(".",$fileName);
		$last = count($split)-1;
		$fileType = $split[$last];
		
		list($type1, $typeVB) = explode("/",$fileType);
		
		$extension = pathinfo($tenvanban, PATHINFO_EXTENSION);
		$fullFileName = $tenvanban.'.'.$split[$last];
		//$fullFileName=utf8_encode($fullFileName);
		$destination = './upload files/' . $fullFileName;
		//$destination = utf8_encode($destination);
		}
		$nameDK= $_FILES['attach']['name'];
		$tmpNameDK  = $_FILES['attach']['tmp_name'];
		$splitDK = explode(".",$nameDK);
		$lastDK = count($splitDK)-1;
		$typeDK = $splitDK[$lastDK];	
		$fileSizeDK = $_FILES['attach']['size'];		
		//$typeDK= $_FILES['attach']['type'];
		$extensionDK = pathinfo($nameDK, PATHINFO_EXTENSION);
		$destinationDK = './attach files/'.$nameDK;
		if ($vanthu == "True") $manguoigui ='vanthu';
		else $manguoigui = $_SESSION['idlogin'];
		
		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiangui = date("Y-m-d H:i:s", time());
		$maphonggui = $_SESSION['MaphongUser'];
		
		$_SESSION['tenvanban'] = $tenvanban;
		$_SESSION['sohieu'] = $sohieu;
		$_SESSION['trichyeu'] = $trichyeu;
		$_SESSION['loaivanban'] = $loaivanban;
		$_SESSION['ngaytao'] = $ngaytao;
		$_SESSION['bancung'] = $bancung;
		$_SESSION['noinhan'] = $noinhan;
		//$_SESSION['maphongnhan'] = $maphongnhan;
		if($_FILES['add']['size'] <= '0' && $vanthu != "True"){
			header("location:../?msg=Bạn chưa chọn văn bản cần gửi đi!&page=uploadVanban");
			exit;
		}
		if($_FILES['add']['size'] <= '0'){
			$destination = '';
		}
		if ($noinhan == ''){
			header('location:../?msg=Bạn chưa chọn nơi nhận văn bản!&page=uploadVanban');
			exit;
		}
		
		$query1 = "INSERT INTO `Văn bản` (`Nơi lưu`, `Tên VB`, `Loại VB`, `Loại File`, `Trích yếu`, `Ngày tạo`, `Số hiệu`, `Nơi lưu bản cứng` ) ".
				  "VALUES ('$destination', '$tenvanban', '$loaivanban', '$fileType', '$trichyeu', '$ngaytao', '$sohieu', '$bancung')";
		//echo $query1; 
		if ($fileSize > 0){	
		$fp      = fopen($tmpName, 'r');
        $content = fread($fp, filesize($tmpName));
        $content = addslashes($content);
        fclose($fp);
		}
		
		if ($_FILES['attach']['size']>0){		
		
		$query2 = "INSERT INTO `file đính kèm` (`Nơi lưu`, `Tên file`, `Loại File` ) ".
				  "VALUES ('$destinationDK', '$nameDK', '$typeDK')";
		
		$fpDK      = fopen($tmpNameDK, 'r');
        $contentDK = fread($fpDK, filesize($tmpNameDK));
        $contentDK = addslashes($contentDK);
        fclose($fpDK);
		}
		
		
		if ($fileSize > 1000000 || $fileSizeDK > 1000000) {
			header('location:../?msg=Tệp hoặc văn bản quá lớn!&page=uploadVanban');
			exit;
		} else {
			// move the uploaded (temporary) file to the specified destination
			ob_start();
			if (file_exists($destination) ||($fileSizeDK >0 && file_exists($destinationDK))) {
				header('location:../?msg=Tên văn bản hoặc tên tệp đính kèm bị trùng!&page=uploadVanban');
				exit;
			}
			if ($_FILES['add']['size']>0){
			if (move_uploaded_file($tmpName, $destination)) {
				if (file_exists($destination)) {				
					$checkExist = "True";
				} else {
					header('location:../?msg=Upload tệp đính kèm không thành công');
					exit;
				}
			}
			}			
				
				$con = mysqli_connect('localhost', 'root', '12345678') or die(mysqli_error($con));
				$db = mysqli_select_db($con,'quanlyvanban');
				$con -> autocommit(FALSE);
				if($db){					
						$checkVB = mysqli_query ($con, $query1);
						if ($checkVB){							
							$getVB = mysqli_query ($con, "Select * from `Văn bản` where `Tên VB` = '$tenvanban' and `Trích yếu` = '$trichyeu'");
							while($row=mysqli_fetch_assoc($getVB)){
								$MaVB = $row['Mã văn bản'];
							}
							$GuiNhan = "INSERT INTO `gửi và nhận vb` (`Mã văn bản`,`Mã người gửi`, `Mã người nhận`, `Thời gian gửi`, `Mã phòng gửi`, `Mã phòng nhận`) ".
									   "VALUES ('$MaVB', '$manguoigui', '$noinhan', '$thoigiangui', '$maphonggui', '$maphongnhan' )";
							$getGuiNhan = mysqli_query ($con,$GuiNhan);
						if ($fileSizeDK>0){						
						if (move_uploaded_file($tmpNameDK, $destinationDK)) {
						if (file_exists($destinationDK)) {																															
						$checkDK = mysqli_query ($con, $query2); 
						
						if ($checkDK){
							$getDK = mysqli_query ($con, "Select * from `file đính kèm` where `Tên file` = '$nameDK'");							
							while($row2=mysqli_fetch_assoc($getDK)){
								$MaDK = $row2['Mã File'];
							}
							$query3 = "INSERT INTO `đính kèm vb` (`Mã VB`,`Mã File`) ".
									  "VALUES ('$MaVB', '$MaDK')";
							$checkVB_DK =  mysqli_query ($con, $query3);
							
							if ($checkVB_DK && $getGuiNhan && ($checkExist == "True" || $vanthu == "True")){
							$con -> commit();
							$con -> close();
							
							$_SESSION['tenvanban'] = '';
							$_SESSION['sohieu'] = '';
							$_SESSION['trichyeu'] = '';
							$_SESSION['loaivanban'] = '';
							$_SESSION['bancung'] = '';
							$_SESSION['noinhan'] = '';
							//$_SESSION['maphongnhan'] = '';
							$_SESSION['ngaytao'] = date("Y-m-d");
							//echo $query3;
							if ($vanthu =="True") header('location:../?msg=Lưu văn bản thành công&page=viewSaved');
							else header('location:../?msg=Gửi văn bản thành công&page=viewSent');
							exit;
							} else $checkDK = false;						
						} else {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							flush();
							}
							if (file_exists($destinationDK)) {
							chmod($destinationDK, 0777);
							unlink($destinationDK) or die("Couldn't delete file");
							flush();
							}
							$con -> rollback();
							$con -> close();
							header('location:../?msg=Có lỗi xảy ra khi ghi dữ liệu vào Database.');
							exit;
						}
						} else {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							flush();
							}
							$con -> rollback();
							$con -> close();
							header('location:../?msg=Upload tệp đính kèm không thành công');
							exit;
						}
						} else {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							flush();
							}
							$con -> rollback();
							$con -> close();
							header('location:../?msg=Upload tệp đính kèm không thành công');
							exit;
						}						
						}

							$con -> commit();
							$con -> close();
							$_SESSION['tenvanban'] = '';
							$_SESSION['sohieu'] = '';
							$_SESSION['trichyeu'] = '';
							$_SESSION['loaivanban'] = '';
							$_SESSION['bancung'] = '';
							$_SESSION['noinhan'] = '';
							//$_SESSION['maphongnhan'] = '';
							$_SESSION['ngaytao'] = date("Y-m-d");
							//echo $query3; 
							if ($vanthu =="True") header('location:../?msg=Lưu văn bản thành công&page=viewSaved');
							else header('location:../?msg=Gửi văn bản thành công&page=viewSent');
							exit;
						} else {
							header('location:../?msg=Có lỗi khi lưu thông tin văn bản vào Database!'); 
							exit;							
						}
										
				} else { 						
						header('location:../?msg=Tải văn bản lên không thành công!&page=uploadVanban');  
						exit;
						}

			}
			header('location:../?msg=Đã xảy ra lỗi!');
			chmod($destination, 777);
			ob_clean();
				 
    }
		ob_end_flush();
		exit;
?>
