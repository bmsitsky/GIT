<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Đăng nhập</title>
	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Trang dang nhap He thong quan ly Van ban" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
	function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Meta tag Keywords -->
	<!-- css files -->
	<link rel="stylesheet" href="assets/css/style.css" type="text/css" media="all" /> <!-- Style-CSS --> 
	<link rel="stylesheet" href="assets/css/font-awesome2.css"> <!-- Font-Awesome-Icons-CSS -->
	<!-- //css files -->
	<!-- online-fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Dosis:200,300,400,500,600,700,800&amp;subset=latin-ext" rel="stylesheet">
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="assets/js/Lightweight-Chart/cssCharts.css"> 
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style> 
	input, select{
	width: 100%;
	padding: 6px 10px;
	margin: 7px 0;
	box-sizing: border-box;
	}
	.info{
	width: 50%;
	padding: 6px 10px;
	margin: 7px 0;
	box-sizing: border-box;
	font-size:18px;
	}
	#update
	{
	height:40px;
	width:100px;
	
	}
	</style>
	 <script>
            function getPage(url){
                $('#content').hide(0,function(){
                $('#content').load(url);
                $('#content').show(0,function(){});
                });
            }
        </script>
    <script>

</script>

</head>

<body>
    <div>
        <nav class="navbar navbar-default top-navbar" style ="background-color: #003D7E;" role="navigation">
            <div class="navbar-header">           
                <a class="navbar-brand" style ="background-color: #003D7E;" href="index.php"><strong></strong></a>
            </div>

            
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
        <div id="sideNav" href=""><i class=""></i></div>
        

        </nav>
        <!-- /. NAV SIDE  -->
      
            <!-- /. PAGE INNER  -->
        </div>
        <div class="center-container">
	<!--header-->
	<div class="header-w3l">
		<h1><br></h1>
	</div>
	<!--//header-->
	<div class="main-content-agile">
		<div class="sub-main-w3">	
			<div class="wthree-pro">
				<h2>Đăng nhập</h2>
			</div>
			<form name="Myform" id="Myform" action="login/loginProcess.php" method="post">
			<div id="error" align = "center" style="color:red; font-size:15px; font-weight:bold;">
			<?php
			$msg = $_REQUEST['msg'];
			if ($msg != ''){
			echo '&ensp;&ensp; '.$msg.'<br><br>';
			}
			?>
			</div>
				<div class="pom-agile">
					<input placeholder="Email" name="uname" class="user" type="email" required="">
					<span class="icon1"><i class="fa fa-user" aria-hidden="true"></i></span>
				</div>
				<div class="pom-agile">
					<input  placeholder="Mật khẩu" name="password" class="pass" type="password" required="">
					<span class="icon2"><i class="fa fa-unlock" aria-hidden="true"></i></span>
				</div>
				<br>
				<div >
					<h6><a href="#" style = " font-size: .9em; color: #fff; letter-spacing: 1px; text-align: center;">Quên mật khẩu?</a></h6>
					<div class="right-w3l">
						<input type="submit" name="submit" value="Login">
					</div>
				</div>
			</form>
		</div>
	</div>
	<!--//main-->
	<!--footer-->
	<div class="footer">
		<p>&copy; 2020 DungBM</p>
	</div>
	<!--//footer-->
</div>
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
     
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- Morris Chart Js -->
    <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
    
    <script src="assets/js/easypiechart.js"></script>
    <script src="assets/js/easypiechart-data.js"></script>
    
     <script src="assets/js/Lightweight-Chart/jquery.chart.js"></script>
    
    <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
	<script src="assets/js/Registration.js"></script>

</body>
</html>