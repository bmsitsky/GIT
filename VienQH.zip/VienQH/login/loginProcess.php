<?php
    if(isset($_POST['submit'])){
        
        session_start();
        ob_start();
        include '../connection.php';        
        $uname = htmlentities(stripslashes($con -> real_escape_string($_POST['uname'])));
        $password = htmlentities(stripslashes($con -> real_escape_string($_POST['password'])));
		
        
        $userqry = mysqli_query ($con, "select * from user where username = '$uname' AND password = '$password'") or die($con -> error);
        $countUser = mysqli_num_rows($userqry);
        if($countUser == 1)
        {
           $row = mysqli_fetch_array($userqry);
           $_SESSION['username'] = $row['username'];
           $_SESSION['password'] = $row['password'];
		   $_SESSION['idlogin'] = $row['Mã nhân viên'];
           $_SESSION['rule'] = $row['rule'];
		   $_SESSION['MaphongUser'] = $row['Mã phòng'];
		   $_SESSION['status'] = "logged";
           
           if($_SESSION['rule'] == '0' || $_SESSION['rule'] == '1' || $_SESSION['rule'] == '2'){
              header('location:../'); 
			  //echo $_SESSION['idlogin'];
           }
           else{
              header('location:../login.php?msg=Xin lỗi, bạn không có quyền truy cập!');
			  //echo $_SESSION['idlogin'];
       }
        }
 else {
            header('location:../login.php?msg=Tên đăng nhập hoặc mật khẩu không đúng!');
			//echo "Không đúng";
 }
 
 ob_end_flush();       
    } else {
		header('location:../login.php?msg=Đăng nhập không thành công!');
	}
?>
