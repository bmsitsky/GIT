<?php
	session_start();
    $_SESSION['iduser'] = $_SESSION['idlogin'];
	header("location:../VienQH?page=edituser");
?>


