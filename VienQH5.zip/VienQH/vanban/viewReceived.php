<?php session_start();
	
include './connection.php';
$currentID = $_SESSION['idlogin'];
$rulelogin = $_SESSION['rule'];
$sql="select vb.`Tên VB`, vb.`Mã văn bản`, gvn.`Thời gian gửi`, gvn.`Thời gian nhận`, u1.`Họ tên`, vb.`Trích yếu` from `user` u1 INNER JOIN `gửi và nhận vb` gvn
	  ON u1.`Mã nhân viên` = gvn.`Mã người gửi` INNER JOIN `Văn bản` vb
	  ON gvn.`Mã văn bản` = vb.`Mã văn bản` INNER JOIN `user` u2
	  ON gvn.`Mã người nhận` = u2.`Mã nhân viên` where u2.`Mã nhân viên` = '$currentID'";
		$res=mysqli_query ($con, $sql) or die(mysqli_error());
		$res2=mysqli_query ($con, $sql) or die(mysqli_error());

?>         

<?php
								$dem=1;
								$begin = '
								<div class="panel panel-default">
								<div class="panel-heading">
								Bạn chưa nhận văn bản nào
								</div> 
								<div class="panel-body">
								<div class="table-responsive">
								<table class="table table-striped table-bordered table-hover">						
								';
								if (!$row2=mysqli_fetch_assoc($res2)) echo $begin;
								while($row=mysqli_fetch_assoc($res))
								{
								if ($begin != '')
								$begin ='
								<div class="panel panel-default">
								<div class="panel-heading">
								Danh sách văn bản đã nhận
								</div> 
								<div class="panel-body">
								<div class="table-responsive">
								<table class="table table-striped table-bordered table-hover">
                                <tr>                                    
                                    <th>STT</th>
									<th>Tên văn bản</th>
                                    <th>Thời gian gửi</th>
									<th>Người gửi</th>
                                    <th>Trích yếu</th>
									<th style = "text-align: center;">Tác vụ</th>
									<th>Trạng thái</th>
                                </tr>								
								';
									echo $begin;
									$begin = '';
								if (empty($row['Thời gian nhận'])){
									$view = "<td width = '10%' style = 'text-align: center; font-weight: bold;'><a style ='color: red;' href=\"?page=viewDetails&type=received&data=".$row['Mã văn bản']."\">Xem</a></td>
											<td width = '10%' style = 'text-align: center; font-weight: bold;'>Chưa đọc</td></tr>";
								} else {
									$view = "<td width = '10%' style = 'text-align: center;'><a href=\"?page=viewDetails&type=received&data=".$row['Mã văn bản']."\">Xem</a></td>
											<td width = '10%' style = 'text-align: center;'>Đã đọc</td></tr>";
								}									
								echo "</td><td>";
								echo $dem++;
								echo "</td><td>";
								echo $row['Tên VB'];
								echo "</td><td>";
								echo $row['Thời gian gửi'];
								echo "</td><td>";
								echo $row['Họ tên'];
								echo "</td><td>";
								echo $row['Trích yếu'];
								echo "</td>";
								echo $view;
								}
								$con -> close();
?>
                        </table>
                    </div>
                </div>
            </div>

        </div>		