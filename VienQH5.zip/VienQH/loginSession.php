<?php
    session_start();
    if($_SESSION['status'] != "logged")
    {
        header('location:/VienQH/login.php');
        exit();
    }
    include 'connection.php'
?>
