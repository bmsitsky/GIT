<?php
	session_start();
	if (!empty($_REQUEST['data']))
	$_SESSION['iduser'] = $_REQUEST['data'];
	if (!empty($_REQUEST['page']))
	$_SESSION['page'] = $_REQUEST['page'];
	header("Location:/VienQH?page=".$_SESSION['page']);
	exit();
?>
