<?php session_start();

include 'connection.php';
$uname = $_SESSION['username'];
$sql="select * from user LEFT JOIN `Phòng ban` pb
	  ON user.`Mã phòng` = pb.`Mã phòng` LEFT JOIN `Chức vụ` cv
	  ON user.`Mã chức vụ` = cv.`Mã chức vụ`";
$res=mysqli_query ($con, $sql) or die(mysqli_error());
?>        	
		<div class="col-md-12 col-sm-12 col-xs-12">

            <div class="panel panel-default">
                <div class="panel-heading">
                    Danh sách users
                </div> 
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>                                    
                                    <th>UserId</th>
									<th>Email/Username</th>
                                    <th>Họ tên</th>
									<th>Ngày sinh</th>
                                    <th>Phòng ban</th>
									<th>Chức vụ</th>
									<th style = "text-align: center;" colspan=2>Action</th>
                                </tr>
<?php
								$dem=1;
								while($row=mysqli_fetch_assoc($res))
								{
									if ($row['rule'] < 0){
										$right = "<td width = '10%' style = 'text-align: center;'><a style = 'color: red;' href=\"user/recover.php?data=".$row['Mã nhân viên']."\">Cấp quyền user</a></td>";
									} elseif ($uname != $row['username']) {
										$right = "<td width = '10%' style = 'text-align: center;'><a href=\"user/delete.php?data=".$row['Mã nhân viên']."\">Hủy quyền user</a></td>";
									} else {
										$right = "<td width = '10%' style = 'text-align: center;'><a style = 'color: red;' href=\"config.php?page=edituser&data=".$row['Mã nhân viên']."\">Quyền Admin</a></td>";
									}
								echo "</td><td>";
								echo $row['Mã nhân viên'];
								echo "</td><td>";
								echo $row['username'];
								echo "</td><td>";
								echo $row['Họ tên'];
								echo "</td><td>";
								echo $row['birthday'];
								echo "</td><td>";
								echo $row['Tên phòng'];
								echo "</td><td>";
								echo $row['Tên chức vụ'];
								echo $right."<td width = '10%' style = 'text-align: center;'><a href=\"config.php?page=edituser&data=".$row['Mã nhân viên']."\">Xem/Sửa thông tin</a></td></tr>";
								}
								$con -> close();
?>
                            </thead>
                            <tbody>  
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>