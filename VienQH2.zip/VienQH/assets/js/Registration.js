
    function error(message) {

                       $('#error').show(500, function() {
                       $('#error').html(message);

                   })
            }
    function HideError(){
            $('#error').hide(500, function() {});
    }

    function isValidDate($date, $format = 'Y-m-d') {
      $dateObj = DateTime::createFromFormat($format, $date);
      return $dateObj && $dateObj->format($format) == $date;
  }
    
    function Validate(){
                if(isValidDate(!document.Myform.birthday.value)){
                error("Ngày sinh không đúng định dạng yyyy-mm-dd");
                document.Myform.birthday.focus();
                return false;
                }
                if(document.Myform.username.value ==""){
                  error("Bạn chưa nhập username");
                  document.Myform.username.focus();
                  return false;
                }
                if(document.Myform.uname.value ==""){
                  error("Bạn chưa nhập Email");
                  document.Myform.username.focus();
                  return false;
                }
                if(document.Myform.password.value == ""){
                  error("Bạn chưa nhập mật khẩu");
                  document.Myform.password.focus();
                  return false;
                }
                if(document.Myform.id.value ==""){
                  error("Bạn chưa nhập mã nhân viên");
                  document.Myform.id.focus()
                  return false;
                }
                if(document.Myform.name.value ==""){
                  error("Bạn chưa nhập họ tên");
                  document.Myform.name.focus();
                  return false;
                }
                if(document.Myform.birthday.value == ""){
                  error("Bạn chưa nhập ngày sinh");
                  document.Myform.birthday.focus();
                  return false;
                }
                if(document.Myform.phong.value == "Chọn phòng ban"){
                  error("Bạn chưa chọn phòng ban");
                  document.Myform.chucvu.focus();
                  return false;
                }
                if(document.Myform.chucvu.value == "Chọn chức vụ"){
                  error("Bạn chưa chọn chức vụ");
                  
                  return false;
                }
                if(document.Myform.usertype.value == "Chọn quyền user"){
                  error("Bạn chưa chọn quyền cho user");
                  
                  return false;
                }
                return true;
}
    