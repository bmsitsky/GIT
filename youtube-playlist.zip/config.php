<?php
 // $API_key = "AIzaSyDdgerKB4kTDQPi3_m8Ebbxal7iFdHghAU"; // Key loi
 //$API_key    = 'AIzaSyA4c9m6e6eEVK_ZlX3RcRSFFSK81wLWVTw';
  $API_key    = 'AIzaSyAUaRA7kxAMiXEDEDpdDIWjzIJP4qrzFS4';
  $playlist = "PLH2yOAdYqPzwOwMiXwElrQbPHc3UThL75";
  $clientId = "791625518333-dcucjjbisifahnl7sasf5l6483pd8gbd.apps.googleusercontent.com";
?>