<?php
	session_start();
	ob_start();
    include_once '../connection.php';
	if(isset($_POST['submit'])){
		//echo "submit form";
		$tenvanban = $_POST['tenvanban'];
		$trichyeu = $_POST['trichyeu'];
		$sohieu = $_POST['sohieu'];
		$loaivanban = $_POST['loaivanban'];
		$ngaytao = $_POST['ngaytao'];
		$bancung = $_POST['bancung'];
		//$noinhan = $_POST['noinhan'];
		$vanthu = $_POST['vanthu'];
		$countAttach = $_POST['count'];
		$countSend = $_POST['send'];
		$checkAttach = $_POST['checkAttach'];
		

			for ($i=0; $i<=$countAttach && $checkAttach != "false"; $i++){
				$j = ($i==0) ? '' : $i;
				$att = 'attach'.$j.'';
				$name_DK[$i]= $_FILES[$att]['name'];
				$tmpName_DK[$i] = $_FILES[$att]['tmp_name'];
				$split_DK = explode(".",$name_DK[$i]);
				$last_DK = count($split_DK)-1;
				$type_DK[$i] = $split_DK[$last_DK];	
				$fileSize_DK[$i] = $_FILES[$att]['size'];		
				//$typeDK= $_FILES['attach']['type'];
				$extension_DK = pathinfo($name_DK[$i], PATHINFO_EXTENSION);
				$destination_DK[$i] = './attach files/'.$name_DK[$i];
			}

			for ($i=0; $i<=$countSend; $i++){
				$j = ($i==0) ? '' : $i;
				$noi = 'noinhan'.$j.'';
				$noinhan[$i] = $_POST[$noi];
				$noi_ = $noinhan[$i];
				$sqls = mysqli_query ($con, "select * from user where user.`Mã nhân viên` = '$noi_'") or die(mysqli_error());
				while($rows=mysqli_fetch_assoc($sqls)){
				$maphongnhan[$i] = $rows['Mã phòng'];
				}
			}		
				
		
		
		//$maphongnhan = htmlentities(stripslashes($con -> real_escape_string($_POST['maphongnhan'])));
		$con -> close();
		if ($_FILES['add']['size'] > 0){
        $fileName = $_FILES['add']['name'];		
        $tmpName  = $_FILES['add']['tmp_name'];		
        $fileSize = $_FILES['add']['size'];
        //$fileType = $_FILES['add']['type'];
		
		$split = explode(".",$fileName);
		$last = count($split)-1;
		$fileType = $split[$last];
		
		list($type1, $typeVB) = explode("/",$fileType);
		
		$extension = pathinfo($tenvanban, PATHINFO_EXTENSION);
		$fullFileName = $tenvanban.'.'.$split[$last];
		//$fullFileName=utf8_encode($fullFileName);
		$destination = './upload files/' . $fullFileName;
		//$destination = utf8_encode($destination);
		}		
		//$typeDK= $_FILES['attach']['type'];
		if ($vanthu == "True") $manguoigui ='vanthu';
		else $manguoigui = $_SESSION['idlogin'];
		
		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiangui = date("Y-m-d H:i:s", time());
		$maphonggui = $_SESSION['MaphongUser'];
		
		$_SESSION['tenvanban'] = $tenvanban;
		$_SESSION['sohieu'] = $sohieu;
		$_SESSION['trichyeu'] = $trichyeu;
		$_SESSION['loaivanban'] = $loaivanban;
		$_SESSION['ngaytao'] = $ngaytao;
		$_SESSION['bancung'] = $bancung;
		$_SESSION['noinhan'] = $noinhan[0];
		
			for ($i=0; $i<=$countAttach && $checkAttach != "false"; $i++){
				for ($j=$i+1; $j<=$countAttach; $j++){
					$m = ($i==0) ? '' : $i;
					$n = ($j==0) ? '' : $j;
				$attm = 'attach'.$m.'';
				$attn = 'attach'.$n.'';
				if ($_FILES[$attm]['name'] == $_FILES[$attn]['name']){
					header("location:../?msg=Tệp đính kèm trùng nhau!&page=uploadVanban");
					exit;
					break;
				}
			}
			}		
			
			for ($i=0; $i<=$countSend; $i++){
				for ($j=$i+1; $j<=$countSend; $j++){
					$m = ($i==0) ? '' : $i;
					$n = ($j==0) ? '' : $j;
				$attm = 'noinhan'.$m.'';
				$attn = 'noinhan'.$n.'';
				if ($_POST[$attm] == $_POST[$attn]){
					header("location:../?msg=Người nhận trùng nhau!&page=uploadVanban");
					exit;
					break;
				}
			}
			}
		
		
	for ($t=0; $t<=$countAttach && $checkAttach != "false"; $t++){
	if (file_exists($destination_DK[$t])){
		header("location:../?msg=Tên tệp đính kèm bị trùng!&page=uploadVanban");
		exit;
	}
	}
			if ($checkAttach == "false"){
			echo 'check = false<br>';
				$name_DK[0]= '';
				$tmpName_DK[0] = '';
				$split_DK = '';
				$last_DK = '';
				$type_DK[0] = '';	
				$fileSize_DK[0] = '';	
				$extension_DK = '';
				$destination_DK[0] = '';
			}
		
		//$_SESSION['maphongnhan'] = $maphongnhan;
		if($_FILES['add']['size'] <= '0' && $vanthu != "True"){
			header("location:../?msg=Bạn chưa chọn văn bản cần gửi đi!&page=uploadVanban");
			exit;
		}
		if($_FILES['add']['size'] <= '0'){
			$destination = '';
		}
		if ($noinhan[0] == ''){
			header('location:../?msg=Bạn chưa chọn nơi nhận văn bản!&page=uploadVanban');
			exit;
		}
		
		$query1 = "INSERT INTO `Văn bản` (`Nơi lưu`, `Tên VB`, `Loại VB`, `Loại File`, `Trích yếu`, `Ngày tạo`, `Số hiệu`, `Nơi lưu bản cứng` ) ".
				  "VALUES ('$destination', '$tenvanban', '$loaivanban', '$fileType', '$trichyeu', '$ngaytao', '$sohieu', '$bancung')";
		//echo $query1; 
		if ($fileSize > 0){	
		$fp      = fopen($tmpName, 'r');
        $content = fread($fp, filesize($tmpName));
        $content = addslashes($content);
        fclose($fp);
		}
		
		if ($fileSize > 1000000) {
			header('location:../?msg=Tệp hoặc văn bản quá lớn!&page=uploadVanban');
			exit;
		}		
				
		$con = mysqli_connect('localhost', 'root', '12345678') or die(mysqli_error($con));
		$db = mysqli_select_db($con,'quanlyvanban');
		$con -> autocommit(FALSE);
				
		for ($i=0; $i<=$countAttach; $i++){
				$j = ($i==0) ? '' : $i;
				$att = 'attach'.$j.'';
		if ($_FILES[$att]['size']>0){		
		
		$query2 = "INSERT INTO `file đính kèm` (`Nơi lưu`, `Tên file`, `Loại File` ) ".
				  "VALUES ('$destination_DK[$i]', '$name_DK[$i]', '$type_DK[$i]')";
		
		$fp_DK[$i]      = fopen($tmpName_DK[$i], 'r');
        $content_DK[$i] = fread($fp_DK[$i], filesize($tmpName_DK[$i]));
        $content_DK[$i] = addslashes($content_DK[$i]);
        fclose($fp_DK[$i]);
		}
			
		
		if ($fileSize_DK[$i] > 1000000) {
			header('location:../?msg=Tệp hoặc văn bản quá lớn!&page=uploadVanban');
			exit;
		} else {
			// move the uploaded (temporary) file to the specified destination
			ob_start();
			if ((file_exists($destination) && $i == 0) ||($fileSize_DK[$i] >0 && file_exists($destination_DK[$i]))) {
				header('location:../?msg=Tên văn bản hoặc tên tệp đính kèm bị trùng!&page=uploadVanban');
				exit;
			}
			if ($_FILES['add']['size']>0){
			if ($i == 0) {
				move_uploaded_file($tmpName, $destination);
				if (file_exists($destination)) {				
					$checkExist = "True";
				} else {
					header('location:../?msg=Upload tệp đính kèm không thành công');
					exit;
				}
			}
			}			
			
				if($db){
						if ($i == 0) {	
						$checkVB = mysqli_query ($con, $query1);
						}
						if ($checkVB){
						if ($i == 0){						
							$getVB = mysqli_query ($con, "Select * from `Văn bản` where `Tên VB` = '$tenvanban' and `Trích yếu` = '$trichyeu'");
							while($row=mysqli_fetch_assoc($getVB)){
								$MaVB = $row['Mã văn bản']; echo 'dòng 172 MVB '.$MaVB.'<br>';
							}
						}
						
							$getGuiNhan = True;
							for ($k=0; $k<=$countSend && $getGuiNhan && $i == 0; $k++){
								$m = ($k==0) ? '' : $k;
							$GuiNhan = "INSERT INTO `gửi và nhận vb` (`Mã văn bản`,`Mã người gửi`, `Mã người nhận`, `Thời gian gửi`, `Mã phòng gửi`, `Mã phòng nhận`) ".
									   "VALUES ('$MaVB', '$manguoigui', '$noinhan[$k]', '$thoigiangui', '$maphonggui', '$maphongnhan[$k]' )";
							$getGuiNhan = mysqli_query ($con,$GuiNhan);
							echo 'dòng 182 GVN '.$GuiNhan.'<br>';
							}
							
						if ($fileSize_DK[$i]>0 && $checkAttach != 'false'){
						echo '170 fize >0 <br>from '.$tmpName_DK[$i].' to '.$destination_DK[$i];						
						if (move_uploaded_file($tmpName_DK[$i], $destination_DK[$i])) {
							echo 'tải tệp tành công! <br>';	
						if (file_exists($destination_DK[$i])) {																															
						$checkDK = mysqli_query ($con, $query2); 
						
						if ($checkDK){
							echo 'Dòng 193 <br>';
							$getDK = mysqli_query ($con, "Select * from `file đính kèm` where `Tên file` = '$name_DK[$i]'");							
							while($row2=mysqli_fetch_assoc($getDK)){
								$MaDK = $row2['Mã File'];
								echo 'Dòng 197 <br>';
							}
							$query3 = "INSERT INTO `đính kèm vb` (`Mã VB`,`Mã File`) ".
									  "VALUES ('$MaVB', '$MaDK');";
							$checkVB_DK =  mysqli_query ($con, $query3);
							echo 'Dòng 202 <br> attach'.$countAttach.' $i= '.$i.'$checkVB_DK '.$checkVB_DK.'$getGuiNhan '.$getGuiNhan.'$checkExist '.$checkExist.'$vanthu '.$vanthu.'<br>'.$query3;
							if ($i == $countAttach && $checkVB_DK && $getGuiNhan && ($checkExist == "True" || $vanthu == "True")){
							echo 'Dòng 204 <br>';
							$con -> commit();
							$con -> close();
							
							$_SESSION['tenvanban'] = '';
							$_SESSION['sohieu'] = '';
							$_SESSION['trichyeu'] = '';
							$_SESSION['loaivanban'] = '';
							$_SESSION['bancung'] = '';
							$_SESSION['noinhan'] = '';
							//$_SESSION['maphongnhan'] = '';
							$_SESSION['ngaytao'] = date("Y-m-d");
							//echo $query3;
							if ($vanthu =="True") header('location:../?msg=Lưu văn bản thành công&page=viewSaved');
							else header('location:../?msg=Gửi văn bản thành công&page=viewSent');
							exit;
							echo 'dòng 217 '.$countAttach.' Attach $i = '.$i.'<br>';
							echo $countSend.' Send <br>';
							echo $query3.'<br>'.$GuiNhan.'<br>'.$query2.'<br>ABC '.$noi.' '.$att.' MPN '.$maphongnhan[0];
							exit;
							} elseif (!$checkVB_DK || $getGuiNhan != True || ($checkExist != "True" && $vanthu != "True")) $checkDK = false;						
						} if ($checkDK == false) {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							//flush();
							}
						if (file_exists($destination_DK[$i])) {
							chmod($destination_DK[$i], 0777);
							unlink($destination_DK[$i]) or die("Couldn't delete file");
							//flush();
							}
							$con -> rollback();
							$con -> close();
							header('location:../?msg=Có lỗi xảy ra khi ghi dữ liệu vào Database.');
							exit;
						}
						} else {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							//flush();
							}
							$con -> rollback();
							$con -> close();
							header('location:../?msg=Upload tệp đính kèm không thành công');
							exit;
						}
						} else {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							//flush();
							}
							$con -> rollback();
							$con -> close();
							header('location:../?msg=Upload tệp đính kèm không thành công');
							exit;
						}						
						}
							if ($i == $countAttach){
							$con -> commit();
							$con -> close();
							$_SESSION['tenvanban'] = '';
							$_SESSION['sohieu'] = '';
							$_SESSION['trichyeu'] = '';
							$_SESSION['loaivanban'] = '';
							$_SESSION['bancung'] = '';
							$_SESSION['noinhan'] = '';
							//$_SESSION['maphongnhan'] = '';
							$_SESSION['ngaytao'] = date("Y-m-d");
							//echo $query3; 
							if ($vanthu =="True") header('location:../?msg=Lưu văn bản thành công&page=viewSaved');
							else header('location:../?msg=Gửi văn bản thành công&page=viewSent');
							exit;
							echo 'dòng 276 '.$countAttach.' Attach $i = '.$i;
							echo $countSend.' Send <br>';
							echo $query3.'<br>'.$GuiNhan.'<br>'.$query2.'<br> ABC'.$noi.' '.$att.' MPN '.$maphongnhan[0];
							exit;
							}
							
						} else {
							header('location:../?msg=Có lỗi khi lưu thông tin văn bản vào Database!'); 
							exit;							
						}
										
				} else { 						
						header('location:../?msg=Tải văn bản lên không thành công!&page=uploadVanban');  
						exit;
						}

			}
	}
			//header('location:../?msg=Đã xảy ra lỗi!');
			//chmod($destination, 777);
			$con -> commit();
			$con -> close();
			$_SESSION['tenvanban'] = '';
			$_SESSION['sohieu'] = '';
			$_SESSION['trichyeu'] = '';
			$_SESSION['loaivanban'] = '';
			$_SESSION['bancung'] = '';
			$_SESSION['noinhan'] = '';
			//$_SESSION['maphongnhan'] = '';
			$_SESSION['ngaytao'] = date("Y-m-d");
			//echo $query3; 
			if ($vanthu =="True") header('location:../?msg=Lưu văn bản thành công&page=viewSaved');
			//else header('location:../?msg=Gửi văn bản thành công&page=viewSent');
			//exit;
			echo 'dòng 276 '.$countAttach.' Attach $i = '.$i;
			echo $countSend.' Send <br>';
			echo $query3.'<br>'.$GuiNhan.'<br>'.$query2.'<br> ABC'.$noi.' '.$att.' MPN '.$maphongnhan[0];
			ob_clean();
				 
    }
		ob_end_flush();
		exit;
?>
