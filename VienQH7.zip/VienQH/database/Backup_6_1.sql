CREATE DATABASE  IF NOT EXISTS `quanlyvanban` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `quanlyvanban`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: quanlyvanban
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chức vụ`
--

DROP TABLE IF EXISTS `chức vụ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chức vụ` (
  `Mã Chức Vụ` varchar(45) NOT NULL,
  `Tên chức vụ` varchar(45) NOT NULL,
  PRIMARY KEY (`Mã Chức Vụ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chức vụ`
--

LOCK TABLES `chức vụ` WRITE;
/*!40000 ALTER TABLE `chức vụ` DISABLE KEYS */;
INSERT INTO `chức vụ` VALUES ('01','Trưởng phòng'),('02','Phó phòng'),('03','Nhân viên'),('04','Thư ký'),('PVT','Phó viện trưởng'),('VT','Viện trưởng');
/*!40000 ALTER TABLE `chức vụ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `Mã công việc` int(11) NOT NULL,
  `Mã comment` int(11) NOT NULL AUTO_INCREMENT,
  `Nội dung` varchar(150) NOT NULL,
  `Mã nhân viên` varchar(15) NOT NULL,
  PRIMARY KEY (`Mã comment`),
  KEY `Mã công việc` (`Mã công việc`),
  KEY `Mã nhân viên` (`Mã nhân viên`),
  CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`Mã công việc`) REFERENCES `công việc` (`Mã công việc`),
  CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`Mã nhân viên`) REFERENCES `user` (`Mã nhân viên`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (16,6,'		Tôi đã làm xong công việc MCV = 16!','dat_vanthu'),(13,7,'	Đề nghị khẩn trương hoàn thành công việc!','admin');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `công việc`
--

DROP TABLE IF EXISTS `công việc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `công việc` (
  `Mã công việc` int(11) NOT NULL AUTO_INCREMENT,
  `Tên công việc` varchar(90) NOT NULL,
  `Loại File` varchar(45) NOT NULL,
  `Ngày tạo` date DEFAULT NULL,
  `Nơi sản xuất` varchar(45) DEFAULT NULL,
  `Thời hạn` date DEFAULT NULL,
  `Mô tả` varchar(200) DEFAULT NULL,
  `Nơi lưu` varchar(100) NOT NULL,
  `Trạng thái` varchar(45) DEFAULT NULL,
  `Cấp độ` int(10) DEFAULT NULL,
  PRIMARY KEY (`Mã công việc`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `công việc`
--

LOCK TABLES `công việc` WRITE;
/*!40000 ALTER TABLE `công việc` DISABLE KEYS */;
INSERT INTO `công việc` VALUES (12,'Công việc 1','doc','2020-05-24','Văn phòng','2020-05-26','Công việc 1 - Công việc đầu tiên cho bạn','./upload files/Công việc 1.doc','Hoàn thành',NULL),(13,'Công việc số 2','doc','2020-05-24','Văn phòng','2020-05-26','Công việc số 2 - Nội dung','./upload files/Công việc số 2.doc','Hoàn thành',NULL),(14,'Tét công việc 3','doc','2020-05-24','Văn phòng','2020-05-27','Tét công việc 3','./upload files/Tét công việc 3.doc','Hoàn thành',NULL),(15,'Test công việc 4','doc','2020-05-24','Văn phòng','2020-05-26','Test công việc 4','./upload files/Test công việc 4.doc','Phê duyệt',NULL),(16,'Tét công việc 5','doc','2020-05-24','Tét công việc 5','2020-05-27','Tét công việc 5','./upload files/Tét công việc 5.doc','Phê duyệt',NULL),(17,'Công việc MCV 13 sắp hết hạn!','doc','2020-05-24','Văn phòng','2020-05-26','Công việc MCV 13 sắp hết hạn!','./upload files/Công việc MCV 13 sắp hết hạn!.doc','Chưa đạt',NULL);
/*!40000 ALTER TABLE `công việc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file đính kèm`
--

DROP TABLE IF EXISTS `file đính kèm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file đính kèm` (
  `Mã File` int(11) NOT NULL AUTO_INCREMENT,
  `Tên file` varchar(45) NOT NULL,
  `Trích yếu` varchar(100) DEFAULT NULL,
  `Loại file` varchar(45) NOT NULL,
  `Nơi lưu` varchar(50) NOT NULL,
  PRIMARY KEY (`Mã File`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file đính kèm`
--

LOCK TABLES `file đính kèm` WRITE;
/*!40000 ALTER TABLE `file đính kèm` DISABLE KEYS */;
INSERT INTO `file đính kèm` VALUES (35,'baocaovp.txt',NULL,'txt','./attach files/baocaovp.txt'),(36,'tường trình.txt',NULL,'txt','./attach files/tường trình.txt'),(37,'tường trình.txt',NULL,'txt','./attach files/tường trình.txt'),(38,'văn thư.doc',NULL,'doc','./attach files/văn thư.doc'),(39,'test3.txt',NULL,'txt','./attach files/test3.txt'),(40,'test5.txt',NULL,'txt','./attach files/test5.txt'),(41,'test7.txt',NULL,'txt','./attach files/test7.txt'),(42,'test8.txt',NULL,'txt','./attach files/test8.txt'),(43,'test9.txt',NULL,'txt','./attach files/test9.txt'),(44,'test10.txt',NULL,'txt','./attach files/test10.txt'),(45,'test10 - Copy (2).txt',NULL,'txt','./attach files/test10 - Copy (2).txt'),(46,'test10 - Copy (3).txt',NULL,'txt','./attach files/test10 - Copy (3).txt'),(47,'test9 - Copy (2).txt',NULL,'txt','./attach files/test9 - Copy (2).txt'),(52,'thu - Copy (3).txt',NULL,'txt','./attach files/thu - Copy (3).txt'),(55,'den dau r.txt',NULL,'txt','./attach files/den dau r.txt'),(58,'Ơn giời ABC - Copy (2).txt',NULL,'txt','./attach files/Ơn giời ABC - Copy (2).txt'),(69,'Dòng 102.txt',NULL,'txt','./attach files/Dòng 102.txt'),(70,'Dòng 103.txt',NULL,'txt','./attach files/Dòng 103.txt'),(71,'Dòng 106.txt',NULL,'txt','./attach files/Dòng 106.txt'),(72,'Dòng 104.txt',NULL,'txt','./attach files/Dòng 104.txt'),(73,'Dòng 105.txt',NULL,'txt','./attach files/Dòng 105.txt');
/*!40000 ALTER TABLE `file đính kèm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gửi và nhận cv`
--

DROP TABLE IF EXISTS `gửi và nhận cv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gửi và nhận cv` (
  `Mã công việc` int(11) NOT NULL,
  `Mã người gửi` varchar(15) NOT NULL,
  `Mã người duyệt` varchar(15) NOT NULL,
  `Trạng thái duyệt` varchar(45) DEFAULT NULL,
  `Thời gian gửi` datetime NOT NULL,
  `Thời gian nhận` datetime DEFAULT NULL,
  `Mã phòng nhận` varchar(45) NOT NULL,
  `Mã phòng gửi` varchar(45) NOT NULL,
  PRIMARY KEY (`Mã công việc`,`Mã người gửi`,`Mã người duyệt`),
  KEY `Mã người gửi` (`Mã người gửi`),
  KEY `Mã người duyệt` (`Mã người duyệt`),
  CONSTRAINT `gửi và nhận cv_ibfk_1` FOREIGN KEY (`Mã người gửi`) REFERENCES `user` (`Mã nhân viên`),
  CONSTRAINT `gửi và nhận cv_ibfk_2` FOREIGN KEY (`Mã người duyệt`) REFERENCES `user` (`Mã nhân viên`),
  CONSTRAINT `gửi và nhận cv_ibfk_3` FOREIGN KEY (`Mã công việc`) REFERENCES `công việc` (`Mã công việc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gửi và nhận cv`
--

LOCK TABLES `gửi và nhận cv` WRITE;
/*!40000 ALTER TABLE `gửi và nhận cv` DISABLE KEYS */;
INSERT INTO `gửi và nhận cv` VALUES (12,'admin','dat_vanthu','Hoàn thành','2020-05-24 21:43:18','2020-05-24 21:48:40','1VP','1KT'),(13,'admin','dat_vanthu','Hoàn thành','2020-05-24 21:59:20','2020-05-24 22:09:17','1VP','1KT'),(14,'admin','dat_vanthu','Hoàn thành','2020-05-24 22:00:07','2020-05-24 22:15:50','1VP','1KT'),(15,'admin','dat_vanthu','Phê duyệt','2020-05-24 22:02:51','2020-05-24 22:15:42','1VP','1KT'),(16,'admin','dat_vanthu','Phê duyệt','2020-05-24 22:05:59','2020-05-24 22:06:38','1VP','1KT'),(17,'admin','dat_vanthu','Chưa đạt','2020-05-24 22:08:37','2020-05-24 22:09:20','1VP','1KT');
/*!40000 ALTER TABLE `gửi và nhận cv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gửi và nhận vb`
--

DROP TABLE IF EXISTS `gửi và nhận vb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gửi và nhận vb` (
  `Mã văn bản` int(11) NOT NULL,
  `Mã người gửi` varchar(15) NOT NULL,
  `Mã người nhận` varchar(15) NOT NULL,
  `Thời gian gửi` datetime NOT NULL,
  `Thời gian nhận` datetime DEFAULT NULL,
  `Mã phòng gửi` varchar(45) NOT NULL,
  `Mã phòng nhận` varchar(45) NOT NULL,
  PRIMARY KEY (`Mã văn bản`,`Mã người gửi`,`Mã người nhận`),
  KEY `Mã người gửi` (`Mã người gửi`),
  KEY `Mã người nhận` (`Mã người nhận`),
  CONSTRAINT `gửi và nhận vb_ibfk_1` FOREIGN KEY (`Mã văn bản`) REFERENCES `văn bản` (`Mã văn bản`),
  CONSTRAINT `gửi và nhận vb_ibfk_2` FOREIGN KEY (`Mã người gửi`) REFERENCES `user` (`Mã nhân viên`),
  CONSTRAINT `gửi và nhận vb_ibfk_3` FOREIGN KEY (`Mã người nhận`) REFERENCES `user` (`Mã nhân viên`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gửi và nhận vb`
--

LOCK TABLES `gửi và nhận vb` WRITE;
/*!40000 ALTER TABLE `gửi và nhận vb` DISABLE KEYS */;
INSERT INTO `gửi và nhận vb` VALUES (63,'admin','dat_vanthu','2020-05-24 21:22:30','2020-05-24 21:23:26','1KT','1VP'),(64,'admin','admin','2020-05-24 21:36:04','2020-06-01 14:38:06','1KT','1KT'),(65,'admin','dat_vanthu','2020-05-24 21:41:49','2020-05-24 21:42:06','1KT','1VP'),(66,'vanthu','vanthu','2020-05-24 22:11:59','2020-05-24 22:12:12','1VP','1VP'),(67,'vanthu','vanthu','2020-05-24 22:13:24','2020-05-24 22:13:42','1VP','1VP'),(68,'vanthu','vanthu','2020-05-24 22:15:02','2020-05-24 22:15:04','1VP','1VP'),(73,'admin','admin','2020-06-01 14:14:15','2020-06-01 14:38:01','1KT',''),(74,'admin','dat_vanthu','2020-06-01 14:18:53',NULL,'1KT',''),(75,'admin','admin','2020-06-01 14:24:03','2020-06-01 14:38:13','1KT',''),(76,'admin','admin','2020-06-01 14:26:29',NULL,'1KT',''),(77,'admin','tp_khtc','2020-06-01 14:27:52',NULL,'1KT',''),(78,'admin','admin','2020-06-01 14:29:26',NULL,'1KT',''),(79,'admin','admin','2020-06-01 14:32:20',NULL,'1KT',''),(80,'admin','admin','2020-06-01 14:37:26',NULL,'1KT',''),(81,'admin','admin','2020-06-01 14:46:45',NULL,'1KT',''),(82,'admin','tp_hd1','2020-06-01 14:47:43',NULL,'1KT',''),(83,'admin','admin','2020-06-01 14:51:46',NULL,'1KT',''),(84,'admin','phovt','2020-06-01 14:53:18',NULL,'1KT','6LD'),(85,'admin','admin','2020-06-01 14:54:26',NULL,'1KT','1KT'),(86,'admin','pp_thanhtra','2020-06-01 14:55:24',NULL,'1KT','4TT'),(87,'admin','tp_qlkt','2020-06-01 14:56:42',NULL,'1KT','1KT'),(88,'admin','tp_thanhtra','2020-06-01 14:57:44',NULL,'1KT','4TT'),(89,'admin','tp_2cn','2020-06-01 14:58:33',NULL,'1KT','2CN'),(90,'admin','tp_qlda','2020-06-01 15:03:44',NULL,'1KT','3DA'),(91,'admin','tp_vp','2020-06-01 15:07:16',NULL,'1KT','1VP'),(95,'admin','admin','2020-06-01 15:12:29',NULL,'1KT','1KT'),(96,'admin','admin','2020-06-01 15:27:28',NULL,'1KT','1KT'),(96,'admin','dat_vanthu','2020-06-01 15:27:28',NULL,'1KT','1VP'),(97,'admin','admin','2020-06-01 15:30:54',NULL,'1KT','1KT'),(97,'admin','tp_khtc','2020-06-01 15:30:54',NULL,'1KT','1KH'),(98,'admin','dat_vanthu','2020-06-01 15:33:13',NULL,'1KT','1VP'),(99,'admin','admin','2020-06-01 15:33:55',NULL,'1KT','1KT'),(99,'admin','pp_qlda','2020-06-01 15:33:55',NULL,'1KT','3DA'),(100,'admin','admin','2020-06-01 15:38:00',NULL,'1KT','1KT'),(101,'admin','nv_qlkt_2','2020-06-01 15:52:51',NULL,'1KT','1KT'),(102,'admin','admin','2020-06-01 15:55:30','2020-06-01 15:55:44','1KT','1KT'),(103,'admin','phovt','2020-06-01 16:12:20',NULL,'1KT','6LD'),(104,'admin','admin','2020-06-01 16:16:20',NULL,'1KT','1KT'),(110,'admin','admin','2020-06-01 16:47:03',NULL,'1KT','1KT'),(116,'admin','pp_thanhtra','2020-06-01 17:23:27',NULL,'1KT','4TT'),(117,'admin','admin','2020-06-01 17:25:04','2020-06-01 17:25:23','1KT','1KT'),(117,'admin','nv_qlkt_1','2020-06-01 17:25:04','2020-06-01 17:25:23','1KT','1KT'),(117,'admin','tp_khtc','2020-06-01 17:25:04','2020-06-01 17:25:23','1KT','1KH');
/*!40000 ALTER TABLE `gửi và nhận vb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nhóm phòng`
--

DROP TABLE IF EXISTS `nhóm phòng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nhóm phòng` (
  `Mã nhóm phòng` varchar(45) NOT NULL,
  `Tên nhóm phòng` varchar(45) NOT NULL,
  PRIMARY KEY (`Mã nhóm phòng`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nhóm phòng`
--

LOCK TABLES `nhóm phòng` WRITE;
/*!40000 ALTER TABLE `nhóm phòng` DISABLE KEYS */;
INSERT INTO `nhóm phòng` VALUES ('01','Các phòng chức năng'),('02','Khối đơn vị sự nghiệp'),('03','Ban quản lý dự án'),('04','Ban thanh tra'),('05','Các hội đồng'),('06','Ban lãnh đạo');
/*!40000 ALTER TABLE `nhóm phòng` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phòng ban`
--

DROP TABLE IF EXISTS `phòng ban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phòng ban` (
  `Mã phòng` varchar(45) NOT NULL,
  `Mã nhóm phòng` varchar(45) NOT NULL,
  `Tên phòng` varchar(45) NOT NULL,
  PRIMARY KEY (`Mã phòng`),
  KEY `Mã nhóm phòng` (`Mã nhóm phòng`),
  CONSTRAINT `phòng ban_ibfk_1` FOREIGN KEY (`Mã nhóm phòng`) REFERENCES `nhóm phòng` (`Mã nhóm phòng`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phòng ban`
--

LOCK TABLES `phòng ban` WRITE;
/*!40000 ALTER TABLE `phòng ban` DISABLE KEYS */;
INSERT INTO `phòng ban` VALUES ('1KH','01','Kế hoạch tài chính'),('1KT','01','Quản lý Kĩ thuật, hạ tầng'),('1QT','01','NCPT & Hợp tác quốc tế'),('1VP','01','Văn phòng'),('2CN','02','Trung tâm nghiên cứu Khoa học & ứng dụng chuy'),('2NC','02','Trung tâm nghiên cứ QHKT đô thị, nông thôn'),('2QH1','02','Trung tâm QHKT 1'),('2QH2','02','Trung tâm QHKT 2'),('2QH3','02','Trung tâm QHKT 3'),('3DA','03','Quản lý dự án'),('4TT','04','Phòng thanh tra'),('5HD1','05','Hội đồng 1'),('5HD2','05','Hội đồng 2'),('6LD','06','Phòng lãnh đạo');
/*!40000 ALTER TABLE `phòng ban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quan hệ công việc`
--

DROP TABLE IF EXISTS `quan hệ công việc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quan hệ công việc` (
  `MCV gốc` int(11) NOT NULL,
  `MCV con` int(11) NOT NULL,
  PRIMARY KEY (`MCV con`),
  KEY `MCV gốc` (`MCV gốc`),
  CONSTRAINT `quan hệ công việc_ibfk_1` FOREIGN KEY (`MCV gốc`) REFERENCES `công việc` (`Mã công việc`),
  CONSTRAINT `quan hệ công việc_ibfk_2` FOREIGN KEY (`MCV con`) REFERENCES `công việc` (`Mã công việc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quan hệ công việc`
--

LOCK TABLES `quan hệ công việc` WRITE;
/*!40000 ALTER TABLE `quan hệ công việc` DISABLE KEYS */;
INSERT INTO `quan hệ công việc` VALUES (12,12),(13,13),(13,17),(14,14),(15,15),(16,16);
/*!40000 ALTER TABLE `quan hệ công việc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quan hệ cấp độ`
--

DROP TABLE IF EXISTS `quan hệ cấp độ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quan hệ cấp độ` (
  `Mã công việc cha` int(11) NOT NULL,
  `Mã công việc con` int(11) NOT NULL,
  PRIMARY KEY (`Mã công việc cha`),
  KEY `Mã công việc con` (`Mã công việc con`),
  CONSTRAINT `quan hệ cấp độ_ibfk_1` FOREIGN KEY (`Mã công việc con`) REFERENCES `công việc` (`Mã công việc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quan hệ cấp độ`
--

LOCK TABLES `quan hệ cấp độ` WRITE;
/*!40000 ALTER TABLE `quan hệ cấp độ` DISABLE KEYS */;
/*!40000 ALTER TABLE `quan hệ cấp độ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quyền user`
--

DROP TABLE IF EXISTS `quyền user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quyền user` (
  `rule` int(11) NOT NULL,
  `Tên quyền user` varchar(45) NOT NULL,
  PRIMARY KEY (`rule`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quyền user`
--

LOCK TABLES `quyền user` WRITE;
/*!40000 ALTER TABLE `quyền user` DISABLE KEYS */;
INSERT INTO `quyền user` VALUES (-1,'Banned'),(0,'Admin'),(1,'User'),(2,'Văn Thư');
/*!40000 ALTER TABLE `quyền user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `Mã nhân viên` varchar(15) NOT NULL,
  `Họ tên` varchar(45) NOT NULL,
  `Mã phòng` varchar(45) NOT NULL,
  `Mã chức vụ` varchar(45) NOT NULL,
  `birthday` date NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `rule` int(11) DEFAULT NULL,
  PRIMARY KEY (`Mã nhân viên`),
  KEY `Mã chức vụ` (`Mã chức vụ`),
  KEY `Mã phòng` (`Mã phòng`),
  KEY `rule` (`rule`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`Mã chức vụ`) REFERENCES `chức vụ` (`Mã Chức Vụ`),
  CONSTRAINT `user_ibfk_2` FOREIGN KEY (`Mã phòng`) REFERENCES `phòng ban` (`Mã phòng`),
  CONSTRAINT `user_ibfk_3` FOREIGN KEY (`rule`) REFERENCES `quyền user` (`rule`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('admin','Bùi Mạnh Dũng','1KT','01','1998-08-01','dung@gmail.com','12345',0),('dat_vanthu','Nguyễn Tiến Đạt','1VP','01','1998-02-02','dat@gmail.com','12345',2),('nv_khtc','Nguyễn Đạt Duy','1KH','03','1995-12-12','nv_khtc@gmail.com','12345',1),('nv_ncpt','L&ecirc; Thuận Đức','1QT','04','1997-03-10','nv_ncpt@gmail.com','12341',1),('nv_qlkt','B&ugrave;i Hồng Nhung','1KT','03','1995-06-09','nv_qlkt@gmail.com','12345',1),('nv_qlkt_1','Nguyễn B&aacute; Tiến','1KT','03','1996-05-06','nv_qlkt_1@gmail.com','12345',1),('nv_qlkt_2','Phạm H&ugrave;ng Th&aacute;i','1KT','04','1995-12-11','nv_qlkt_2@gmail.com','12345',1),('phovt','Nguyễn Anh Tuấn','6LD','PVT','1997-08-07','phovt@gmail.com','12345',1),('pp_hd1','Nguyễn Đức C&ocirc;ng','5HD1','02','1998-10-12','pp_hd1@gmail.com','12312',1),('pp_khtc','L&ecirc; Văn Tươi','1KH','02','1992-02-07','ph_khtc@gmail.com','12345',1),('pp_qlda','Phạm Văn Duy','3DA','02','1998-01-01','pv_qlda@gmail.com','12345',1),('pp_thanhtra','Vũ Văn Thanh','4TT','02','1990-01-02','pv_thanhtra@gmail.com','12345',1),('thukyvt','Đặng Thị Vui','6LD','04','1999-08-12','thukyvt@gmail.com','12345',1),('tp_2cn','Vũ Đức Duy','2CN','01','1998-12-08','tp_2cn@gmail.com','12345',1),('tp_hd1','B&ugrave;i Tiến Dũng','5HD1','01','1998-10-10','tp_hd1@gmail.com','12312',1),('tp_khtc','Trần Văn Phương','1KH','01','1998-09-09','tp_khtc@gmail.com','12345',1),('tp_ncpt','Nguyễn Ngọc Tiến','1QT','01','1998-03-09','tp_ncpt@gmail.com','12345',1),('tp_qhkt','Ti&ecirc;u C&ocirc;ng H&ograve;a','2NC','01','1997-01-01','tp_qhkt@gmail.com','12341',1),('tp_qlda','Phạm Minh Cường','3DA','01','1997-06-03','tp_qlda@gmail.com','12345',1),('tp_qlkt','Ph&ugrave;ng Thế H&ugrave;ng','1KT','01','1998-06-06','tp_qlkt@gmail.com','12345',1),('tp_thanhtra','Nguyễn Tiến Anh','4TT','01','1998-08-12','tp_thanhtra@gmail.com','12345',1),('tp_vp','Nguyễn Đức Minh','1VP','01','1998-04-04','tp_vp@gmail.com','12345',1),('vanthu','Văn Thư','1VP','03','1997-03-03','vanthu@gmail.com','12345',2),('vientruong','L&ecirc; Đắc Minh','6LD','VT','1995-05-05','vientruong@gmail.com','12345',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `văn bản`
--

DROP TABLE IF EXISTS `văn bản`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `văn bản` (
  `Mã văn bản` int(11) NOT NULL AUTO_INCREMENT,
  `Nơi lưu` varchar(100) DEFAULT NULL,
  `Tên VB` varchar(90) NOT NULL,
  `Loại VB` varchar(45) NOT NULL,
  `Loại File` varchar(45) DEFAULT NULL,
  `Trích yếu` varchar(200) DEFAULT NULL,
  `Ngày tạo` date NOT NULL,
  `Số hiệu` varchar(45) NOT NULL,
  `Nơi lưu bản cứng` varchar(45) DEFAULT NULL,
  `Trạng thái` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Mã văn bản`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `văn bản`
--

LOCK TABLES `văn bản` WRITE;
/*!40000 ALTER TABLE `văn bản` DISABLE KEYS */;
INSERT INTO `văn bản` VALUES (63,'./upload files/Báo cáo tình hình văn phòng tháng 5.doc','Báo cáo tình hình văn phòng tháng 5','Báo cáo','doc','Tinh hình công tác, những việc đã làm được cũng như còn tồn tại của văn phòng trong tháng 5','2020-05-24','BC-VP05-2020','Không có',NULL),(64,'./upload files/Nhận xét cá nhân gửi đến trưởng phòng kỹ thuật (BMD).doc','Nhận xét cá nhân gửi đến trưởng phòng kỹ thuật (BMD)','Báo cáo cá nhân','doc','Nhận xét cá nhân gửi đến trưởng phòng kỹ thuật (BMD) trong tháng 5-2020','2020-05-24','NXCN-05-2020','Văn phòng tầng 1',NULL),(65,'./upload files/Nhận xét cá nhân gửi đến trưởng phòng kỹ thuật .doc','Nhận xét cá nhân gửi đến trưởng phòng kỹ thuật ','Tường trình','doc','Nhận xét cá nhân gửi đến trưởng phòng kỹ thuật ','2020-05-24','BC-TN-2020','',NULL),(66,'','Test văn thư 1','Văn thư','','Test văn thư 1 - Nội dung','2020-05-24','VT-01-2020','Phòng văn thư tầng 2',NULL),(67,'','Test Văn thư 2','Văn thư','','Test Văn thư 2 - Đính kèm','2020-05-24','VT-02-2020','KC',NULL),(68,'./upload files/Test văn thư 3.doc','Test văn thư 3','Văn thư','doc','Test văn thư 3 - Đính kèm','2020-05-24','VT-03-2020','',NULL),(69,'./upload files/Test mutil VB.txt','Test mutil VB','Test mutil VB','txt','Test mutil VB','2020-06-01','Test mutil VB','Test mutil VB',NULL),(70,'./upload files/Test MUTIL2 VB.txt','Test MUTIL2 VB','Test MUTIL2 VB','txt','Test MUTIL2 VB','2020-06-01','Test MUTIL2 VB','Test MUTIL2 VB',NULL),(71,'./upload files/Test lần 3.txt','Test lần 3','Test lần 3','txt','Test lần 3','2020-06-01','Test lần 3','Test lần 3',NULL),(72,'./upload files/Test ABCD.txt','Test ABCD','Test ABCD','txt','Test ABCD','2020-06-01','Test ABCD','Test ABCD',NULL),(73,'./upload files/Test ABCDE.txt','Test ABCDE','Test ABCDE','txt','Test ABCDE','2020-06-01','Test ABCDE','Test ABCDE',NULL),(74,'./upload files/Test VBNH.txt','Test VBNH','Test VBNH','txt','Test VBNH','2020-06-01','Test VBNH','Test VBNH',NULL),(75,'./upload files/Ten VBQQ.txt','Ten VBQQ','Ten VBQQ','txt','Ten VBQQ','2020-06-01','Ten VBQQ','Ten VBQQ',NULL),(76,'./upload files/Ten VBMN.txt','Ten VBMN','Ten VBMN','txt','Ten VBMN','2020-06-01','Ten VBMN','Ten VBMN',NULL),(77,'./upload files/Test GOGOGO.txt','Test GOGOGO','Test GOGOGO','txt','Test GOGOGO','2020-06-01','Test GOGOGO','Test GOGOGO',NULL),(78,'./upload files/Test VBVBVBV.txt','Test VBVBVBV','Test VBVBVBV','txt','Test VBVBVBV','2020-06-01','Test VBVBVBV','Test VBVBVBV',NULL),(79,'./upload files/Minh beo.txt','Minh beo','Minh beo','txt','Minh beo','2020-06-01','Minh beo','Minh beo',NULL),(80,'./upload files/Opa GoGo.txt','Opa GoGo','Opa GoGo','txt','Opa GoGo','2020-06-01','Opa GoGo','Opa GoGo',NULL),(81,'./upload files/Test QQQQQ.txt','Test QQQQQ','Test QQQQQ','txt','Test QQQQQ','2020-06-01','Test QQQQQ','Test QQQQQ',NULL),(82,'./upload files/HHH GOGO.txt','HHH GOGO','HHH GOGO','txt','HHH GOGO','2020-06-01','HHH GOGO','HHH GOGO',NULL),(83,'./upload files/GOGOGG.txt','GOGOGG','GOGOGG','txt','GOGOGG','2020-06-01','GOGOGG','GOGOGG',NULL),(84,'./upload files/Không hiểu kiểu gì.txt','Không hiểu kiểu gì','Không hiểu kiểu gì','txt','Không hiểu kiểu gì','2020-06-01','Không hiểu kiểu gì','Không hiểu kiểu gì',NULL),(85,'./upload files/Thật buồn tẻ.txt','Thật buồn tẻ','Thật buồn tẻ','txt','Thật buồn tẻ','2020-06-01','Thật buồn tẻ','Thật buồn tẻ',NULL),(86,'./upload files/Bắt đầu được.txt','Bắt đầu được','Bắt đầu được','txt','Bắt đầu được','2020-06-01','Bắt đầu được','Bắt đầu được',NULL),(87,'./upload files/Chắc sắp ok.txt','Chắc sắp ok','Chắc sắp ok','txt','Chắc sắp ok','2020-06-01','Chắc sắp ok','Chắc sắp ok',NULL),(88,'./upload files/Ok ok ok .txt','Ok ok ok ','Ok ok ok ','txt','Ok ok ok ','2020-06-01','Ok ok ok ','Ok ok ok ',NULL),(89,'./upload files/okokokok.txt','okokokok','okokokok','txt','okokokok','2020-06-01','okokokok','okokokok',NULL),(90,'./upload files/let go go.txt','let go go','let go go','txt','let go go','2020-06-01','let go go','let go go',NULL),(91,'./upload files/test từng dòng.txt','test từng dòng','test từng dòng','txt','test từng dòng','2020-06-01','test từng dòng','test từng dòng',NULL),(95,'./upload files/ngu ơi là ngu.txt','ngu ơi là ngu','ngu ơi là ngu','txt','ngu ơi là ngu','2020-06-01','ngu ơi là ngu','ngu ơi là ngu',NULL),(96,'./upload files/test tạm tạm.txt','test tạm tạm','test tạm tạm','txt','test tạm tạm','2020-06-01','test tạm tạm','test tạm tạm',NULL),(97,'./upload files/Bây giờ đang thử.txt','Bây giờ đang thử','Bây giờ đang thử','txt','Bây giờ đang thử','2020-06-01','Bây giờ đang thử','Bây giờ đang thử',NULL),(98,'./upload files/Test 1 văn bản 1 người nhận.txt','Test 1 văn bản 1 người nhận','Test 1 văn bản 1 người nhận','txt','Test 1 văn bản 1 người nhận','2020-06-01','Test 1 văn bản 1 người nhận','Test 1 văn bản 1 người nhận',NULL),(99,'./upload files/Test 1 đính kèm 2 người nhận.txt','Test 1 đính kèm 2 người nhận','Test 1 đính kèm 2 người nhận','txt','Test 1 đính kèm 2 người nhận','2020-06-01','Test 1 đính kèm 2 người nhận','Test 1 đính kèm 2 người nhận',NULL),(100,'./upload files/Test 2 file 1 người nhận.txt','Test 2 file 1 người nhận','Test 2 file 1 người nhận','txt','Test 2 file 1 người nhận','2020-06-01','Test 2 file 1 người nhận','Test 2 file 1 người nhận',NULL),(101,'./upload files/php đấy.txt','php đấy','php đấy','txt','php đấy','2020-06-01','php đấy','php đấy',NULL),(102,'./upload files/thêm 3 tệp.txt','thêm 3 tệp','thêm 3 tệp','txt','thêm 3 tệp','2020-06-01','thêm 3 tệp','thêm 3 tệp',NULL),(103,'./upload files/Xem nó thế nào.txt','Xem nó thế nào','Xem nó thế nào','txt','Xem nó thế nào','2020-06-01','Xem nó thế nào','Xem nó thế nào',NULL),(104,'./upload files/Thật ra là như nào.txt','Thật ra là như nào','Thật ra là như nào','txt','Thật ra là như nào','2020-06-01','Thật ra là như nào','Thật ra là như nào',NULL),(110,'./upload files/Ơn giời ABC.txt','Ơn giời ABC','Ơn giời ABC','txt','Ơn giời ABC','2020-06-01','Ơn giời ABC','Ơn giời ABC',NULL),(116,'./upload files/Dòng 102.txt','Dòng 102','Dòng 193','txt','Dòng 195','2020-06-01','Dòng 193','Dòng 193',NULL),(117,'./upload files/Mutil of mutil.txt','Mutil of mutil','Mutil of mutil','txt','Mutil of mutil','2020-06-01','Mutil of mutil','Mutil of mutil',NULL);
/*!40000 ALTER TABLE `văn bản` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `đính kèm cv`
--

DROP TABLE IF EXISTS `đính kèm cv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `đính kèm cv` (
  `Mã công việc` int(11) NOT NULL,
  `Mã File` int(11) DEFAULT NULL,
  PRIMARY KEY (`Mã công việc`),
  KEY `Mã File` (`Mã File`),
  CONSTRAINT `đính kèm cv_ibfk_1` FOREIGN KEY (`Mã công việc`) REFERENCES `công việc` (`Mã công việc`),
  CONSTRAINT `đính kèm cv_ibfk_2` FOREIGN KEY (`Mã File`) REFERENCES `file đính kèm` (`Mã File`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `đính kèm cv`
--

LOCK TABLES `đính kèm cv` WRITE;
/*!40000 ALTER TABLE `đính kèm cv` DISABLE KEYS */;
INSERT INTO `đính kèm cv` VALUES (12,37);
/*!40000 ALTER TABLE `đính kèm cv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `đính kèm vb`
--

DROP TABLE IF EXISTS `đính kèm vb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `đính kèm vb` (
  `Mã VB` int(11) NOT NULL,
  `Mã File` int(11) NOT NULL,
  PRIMARY KEY (`Mã VB`,`Mã File`),
  KEY `Mã File` (`Mã File`),
  CONSTRAINT `đính kèm vb_ibfk_1` FOREIGN KEY (`Mã File`) REFERENCES `file đính kèm` (`Mã File`),
  CONSTRAINT `đính kèm vb_ibfk_2` FOREIGN KEY (`Mã VB`) REFERENCES `văn bản` (`Mã văn bản`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `đính kèm vb`
--

LOCK TABLES `đính kèm vb` WRITE;
/*!40000 ALTER TABLE `đính kèm vb` DISABLE KEYS */;
INSERT INTO `đính kèm vb` VALUES (63,35),(65,36),(68,38),(95,39),(96,40),(98,41),(99,42),(100,43),(101,44),(102,44),(102,45),(103,46),(104,47),(110,58),(116,69),(116,70),(117,71),(117,72),(117,73);
/*!40000 ALTER TABLE `đính kèm vb` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-01 17:27:49
