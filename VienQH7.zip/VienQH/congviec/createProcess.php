<?php
	session_start();
	ob_start();
    include_once '../connection.php';
	echo 'start<br>';
	if(isset($_POST['submit'])){
		//echo "submit form";
		$tencongviec = $_POST['tencongviec'];
		$mota = $_POST['mota'];
		$trangthai = $_POST['trangthai'];
		$noisanxuat = $_POST['noisanxuat'];
		$ngaytaocv = $_POST['ngaytaocv'];
		$thoihan = $_POST['thoihan'];
		//$noinhan = $_POST['noinhan'];
		$MaGoc = $_POST['idGoc'];
		$countAttach = $_POST['count'];
		$countSend = $_POST['send'];
		$capdo = 0;
		$manguoigui = $_SESSION['idlogin'];
		$manguoiduyet = $manguoigui;
		$checkAttach = $_POST['checkAttach'];
		if (!empty($_POST['manguoiduyet']))
		$manguoiduyet = $_POST['manguoiduyet'];	
	
		
		//$maphongnhan = htmlentities(stripslashes($con -> real_escape_string($_POST['maphongnhan'])));
		
			for ($i=0; $i<=$countAttach && $checkAttach != "false"; $i++){
				$j = ($i==0) ? '' : $i;
				$att = 'attach'.$j.'';
				$name_DK[$i]= $_FILES[$att]['name'];
				$tmpName_DK[$i] = $_FILES[$att]['tmp_name'];
				$split_DK = explode(".",$name_DK[$i]);
				$last_DK = count($split_DK)-1;
				$type_DK[$i] = $split_DK[$last_DK];	
				$fileSize_DK[$i] = $_FILES[$att]['size'];		
				//$typeDK= $_FILES['attach']['type'];
				$extension_DK = pathinfo($name_DK[$i], PATHINFO_EXTENSION);
				$destination_DK[$i] = './attach files/'.$name_DK[$i];
			}
			echo '41';
			if ($checkAttach == "false"){
			echo 'check = false<br>';
				$name_DK[0]= '';
				$tmpName_DK[0] = '';
				$split_DK = '';
				$last_DK = '';
				$type_DK[0] = '';	
				$fileSize_DK[0] = '';	
				$extension_DK = '';
				$destination_DK[0] = '';
			}

			for ($i=0; $i<=$countSend; $i++){
				echo 'dong 55 count send = '.$countSend.'<br>';
				$j = ($i==0) ? '' : $i;
				$noi = 'noinhan'.$j.'';
				$noinhan[$i] = $_POST[$noi];
				$noiduyet[$i] = $manguoiduyet;
				
				if ($trangthai == "Đã xong")
				$noiduyet[$i] = $noinhan[$i];

				$noi_ = $noinhan[$i];
				$sqls = mysqli_query ($con, "select * from user where user.`Mã nhân viên` = '$noi_'") or die(mysqli_error());
				while($rows=mysqli_fetch_assoc($sqls)){
				$maphongnhan[$i] = $rows['Mã phòng'];
				}
			}
			
		if (!empty($_POST['idGoc'])){
			$target = $noinhan[0];
			$capdo = -1;
		} else $target = '';
			
		$con -> close();
		echo 'dong 73';
        $fileName = $_FILES['add']['name'];		
        $tmpName  = $_FILES['add']['tmp_name'];		
        $fileSize = $_FILES['add']['size'];
        //$fileType = $_FILES['add']['type'];
		
		$split = explode(".",$fileName);
		$last = count($split)-1;
		$fileType = $split[$last];
		
		list($type1, $typeCV) = explode("/",$fileType);
		
		$extension = pathinfo($tencongviec, PATHINFO_EXTENSION);
		$fullFileName = $tencongviec.'.'.$split[$last];
		//$fullFileName=utf8_encode($fullFileName);
		$destination = './upload files/' . $fullFileName;
		if (!empty($_POST['idGoc'])){
			$destination = './upload files/' . $fileName;
		}
		//$destination = utf8_encode($destination);
		
		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiangui = date("Y-m-d H:i:s", time());
		$maphonggui = $_SESSION['MaphongUser'];
		
		$_SESSION['tencongviec'] = $tencongviec;
		$_SESSION['trangthai'] = $trangthai;
		$_SESSION['mota'] = $mota;
		$_SESSION['noisanxuat'] = $noisanxuat;
		$_SESSION['ngaytaocv'] = $ngaytaocv;
		$_SESSION['thoihan'] = $thoihan;
		$_SESSION['noinhan'] = $noinhan[0];
		//$_SESSION['maphongnhan'] = $maphongnhan;
		echo 'dong 106';
			for ($i=0; $i<=$countAttach && $checkAttach != "false"; $i++){
				echo 'vao attach roi! <br>';
				for ($j=$i+1; $j<=$countAttach; $j++){
					$m = ($i==0) ? '' : $i;
					$n = ($j==0) ? '' : $j;
				$attm = 'attach'.$m.'';
				$attn = 'attach'.$n.'';
				if ($_FILES[$attm]['name'] == $_FILES[$attn]['name']){
					header("location:../?msg=Tệp đính kèm trùng nhau!&page=createWork");
					exit;
					break;
				}
			}
			}		
			
			for ($i=0; $i<=$countSend; $i++){
				for ($j=$i+1; $j<=$countSend; $j++){
					$m = ($i==0) ? '' : $i;
					$n = ($j==0) ? '' : $j;
				$attm = 'noinhan'.$m.'';
				$attn = 'noinhan'.$n.'';
				if ($_POST[$attm] == $_POST[$attn]){
					header("location:../?msg=Người nhận trùng nhau!&page=createWork");
					exit;
					break;
				}
			}
			}		
		
		if($_FILES['add']['size'] <= '0'){
			header("location:../?msg=Bạn chưa đính kèm công việc!&page=createWork&id=$MaGoc&target=$target");
			exit;
		}
		if ($noinhan[0] == ''){
			header("location:../?msg=Bạn chưa chọn nơi nhận công việc!&page=createWork&id=$MaGoc&target=$target");
			exit;
		}
	}
	for ($t=0; $t<=$countAttach && $checkAttach != "false"; $t++){
	if (file_exists($destination_DK[$t]) && $fileSize_DK[$t] > 0){
		header("location:../?msg=Tên tệp đính kèm bị trùng!&page=createWork&id=$MaGoc&target=$target");
		exit;
	}
	}
	
    if(isset($_POST['submit']) && $_FILES['add']['size']>0)
    {
		echo 'dong 154<br>';
		include_once '../connection.php';
		$query1 = "INSERT INTO `Công việc` (`Nơi lưu`, `Tên công việc`, `Nơi sản xuất`, `Loại File`, `Mô tả`, `Ngày tạo`, `Trạng thái`, `Thời hạn`, `Cấp độ` ) ".
				  "VALUES ('$destination', '$tencongviec', '$noisanxuat', '$fileType', '$mota', '$ngaytaocv', '$trangthai', '$thoihan', '$capdo' )";
				  
		$fp      = fopen($tmpName, 'r');
        $content = fread($fp, filesize($tmpName));
        $content = addslashes($content);
        fclose($fp);		
		
		$con = mysqli_connect('localhost', 'root', '12345678') or die(mysqli_error($con));
		$db = mysqli_select_db($con,'quanlyvanban');
		$con -> autocommit(FALSE);
		
		if ($fileSize > 1000000) {
			header("location:../?msg=Kích thước tệp quá lớn!&page=createWork&id=$MaGoc&target=$target");
			exit;
		} else {
			// move the uploaded (temporary) file to the specified destination
			echo 'dong 173<br>';
			
			if (file_exists($destination)) { 
				if (!empty($_POST['idGoc'])){
				header("location:../?msg=Tên tệp công việc bị trùng!&page=createWork&id=$MaGoc&target=$target");
				} else {
				header("location:../?msg=Tên công việc bị trùng!&page=createWork&id=$MaGoc&target=$target");
				}
				exit;
			} echo 'dong 182';
			if (move_uploaded_file($tmpName, $destination)) {
				if (file_exists($destination)) {				
					echo 'dong 185 upload thanh cong $countAttach = '.$countAttach.'<br>';
				} else {
					header("location:../?msg=Upload tệp đính kèm không thành công");
					exit;
				} echo 'dong 189<br>';
				for ($i=0; $i<=$countAttach; $i++){				
				$j = ($i==0) ? '' : $i;
				$att = 'attach'.$j.'';
				if ($_FILES[$att]['size']>0){		
				echo 'dong 194';
				
				$query2 = "INSERT INTO `file đính kèm` (`Nơi lưu`, `Tên file`, `Loại File` ) ".
				  "VALUES ('$destination_DK[$i]', '$name_DK[$i]', '$type_DK[$i]')";
		
				$fp_DK[$i] = fopen($tmpName_DK[$i], 'r');
				$content_DK[$i] = fread($fp_DK[$i], filesize($tmpName_DK[$i]));
				$content_DK[$i] = addslashes($content_DK[$i]);
				fclose($fp_DK[$i]);
				}		
				
				if($db){
						if ($i == 0){
						$checkCV = mysqli_query ($con, $query1);
						}
						if ($checkCV){	
							if ($i == 0){
							$getCV = mysqli_query ($con, "Select * from `Công việc` where `Tên công việc` = '$tencongviec' and `Mô tả` = '$mota'");
							while($row=mysqli_fetch_assoc($getCV)){
								$MaCV = $row['Mã công việc'];
							}
							if ($MaGoc == '') $MaGoc = $MaCV;
							}
							$getGuiNhan = True;
							for ($k=0; $k<=$countSend && $getGuiNhan && $i == 0; $k++){
								$m = ($k==0) ? '' : $k;							
							$GuiNhan = "INSERT INTO `gửi và nhận cv` (`Mã công việc`,`Mã người gửi`, `Mã người nhận`, `Mã người duyệt`, `Thời gian gửi`, `Thời hạn`, `Mã phòng gửi`, `Mã phòng nhận`, `Trạng thái duyệt`) ".
									   "VALUES ('$MaCV', '$manguoigui', '$noinhan[$k]', '$noiduyet[$k]', '$thoigiangui', '$thoihan', '$maphonggui', '$maphongnhan[$k]', '$trangthai' )";
							$getGuiNhan = mysqli_query ($con,$GuiNhan);
							}
							if ($i == 0){
							$query4 = "INSERT INTO `quan hệ công việc` (`MCV gốc`,`MCV con`) ".
									  "VALUES ('$MaGoc', '$MaCV')";
							$check_QHCV =  mysqli_query ($con, $query4);
							}
						if ($fileSize_DK[$i]>0 && $checkAttach != 'false'){						
						if (move_uploaded_file($tmpName_DK[$i], $destination_DK[$i])) {
						if (file_exists($destination_DK[$i])) {																															
						$checkDK = mysqli_query ($con, $query2); 
						
						if ($checkDK){
							$getDK = mysqli_query ($con, "Select * from `file đính kèm` where `Tên file` = '$name_DK[$i]'");							
							while($row2=mysqli_fetch_assoc($getDK)){
								$MaDK = $row2['Mã File'];
							}
							$query3 = "INSERT INTO `đính kèm cv` (`Mã công việc`,`Mã File`) ".
									  "VALUES ('$MaCV', '$MaDK')";
							$checkCV_DK =  mysqli_query ($con, $query3);
							echo '$query3 '.$query3.'<br>'.'$checkCV_DK '.$checkCV_DK.'<br>';						
																			
							if ($i == $countAttach && $checkCV_DK && $getGuiNhan && $check_QHCV){
							$con -> commit();
							$con -> close();
							
							$_SESSION['tencongviec'] = '';
							$_SESSION['trangthai'] = '';
							$_SESSION['mota'] = '';
							$_SESSION['noisanxuat'] = '';
							$_SESSION['thoihan'] = '';
							$_SESSION['noinhan'] = '';
							//$_SESSION['maphongnhan'] = '';
							$_SESSION['ngaytaocv'] = date("Y-m-d");
							//echo $query3;
							header("location:../?msg=Gửi công việc thành công&page=listWork");
							exit;
							echo 'dòng 225 '.$countAttach.' Attach $i = '.$i.'<br>';
							echo $countSend.' Send <br>';
							echo $query3.'<br>'.$GuiNhan.'<br>'.$query2.'<br>ABC '.$noi.' '.$att.' MPN '.$maphongnhan[0];
							exit;
							} else $checkDK = false;						
						} elseif ($checkDK == false) {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							//flush();
							}

							$con -> rollback();
							$con -> close();
							header("location:../?msg=Có lỗi xảy ra khi ghi dữ liệu vào Database.&page=createWork&id=$MaGoc&target=$target");
							exit;
						}
						} else {
							$con -> rollback();
							$con -> close();
							header("location:../?msg=Upload tệp đính kèm không thành công&page=createWork&id=$MaGoc&target=$target");
							exit;
						}
						} else {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							//flush();
							}
							$con -> rollback();
							$con -> close();
							
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							//flush();
							}
							header("location:../?msg=Upload tệp đính kèm không thành công&page=createWork&id=$MaGoc&target=$target");
							exit;
						}						
						}
						}
						if ($i == $countAttach){
							echo 'dong 297';
							$con -> commit();
							$con -> close();
							$_SESSION['tencongviec'] = '';
							$_SESSION['trangthai'] = '';
							$_SESSION['mota'] = '';
							$_SESSION['noisanxuat'] = '';
							$_SESSION['thoihan'] = '';
							$_SESSION['noinhan'] = '';
							//$_SESSION['maphongnhan'] = '';
							$_SESSION['ngaytaocv'] = date("Y-m-d");
							//echo $query3; 
							header('location:../?msg=Gửi công việc thành công&page=listWork');
							exit;
							echo 'dòng 284 '.$countAttach.' Attach $i = '.$i.'<br>';
							echo $countSend.' Send <br>';
							echo $query3.'<br>'.$GuiNhan.'<br>'.$query2.'<br>ABC '.$noi.' '.$att.' MPN '.$maphongnhan[0];
							exit;	
						}
						echo 'dong 329<br>';
						} else {
							header("location:../?msg=Có lỗi khi lưu thông tin công việc vào Database!&page=createWork&id=$MaGoc&target=$target"); 
							exit;							
						}
						echo 'dong 325<br>';
				}						
				} else { 						
						header("location:../?msg=Tải công việc lên không thành công!&page=createWork&id=$MaGoc&target=$target");  
						exit;
						}
			}
			header("location:../?msg=Đã xảy ra lỗi!&page=createWork&id=$MaGoc&target=$target");
			exit;
			echo 'dong 334';
			//ob_clean();
				 
    } else {
		header("location:../?msg=Bạn chưa đính kèm công việc!&page=createWork&id=$MaGoc&target=$target");
		exit;
	}								
	ob_end_flush();
	exit;
?>
