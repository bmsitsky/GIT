<?php
	session_start();
	ob_start();
	$dem = 0;
	function duyet($manguoigui, $manguoinhan, $manguoiduyet, $trangthai, $thoihan, $id, $dem) {
	include '../connection.php';
	if ($dem < 5){
	$q1 = "Update `Công việc` set `Trạng thái` = '$trangthai' where `Mã công việc` = '$id'";
	
	$q5= "select * from `Quan hệ công việc` Where `MCV gốc` = '$id'";
	
	$q2 = "Update `gửi và nhận cv` set `Trạng thái duyệt` = '$trangthai' 
		   where `Mã công việc` = '$id'";
	
	$res2 = mysqli_query ($con, $q5);
	
	if ($row=mysqli_fetch_assoc($res2)){
		if ($manguoiduyet == $manguoigui)
		$q2 = "Update `gửi và nhận cv` set `Trạng thái duyệt` = '$trangthai' 
		   where (`Mã công việc` = '$id' AND ((`Mã người duyệt` = '$manguoinhan' AND `Mã người gửi` = '$manguoigui') OR (`Mã người duyệt` = '$manguoigui' AND `Mã người nhận` = '$manguoinhan')))
		   OR (`Mã công việc` IN (Select `MCV con` from `Quan hệ công việc` where (`MCV gốc` = '$id' AND `MCV con` != '$id') AND `Mã người gửi` = '$manguoinhan'))";
		if ($manguoiduyet == $manguoinhan)
		$q2 = "Update `gửi và nhận cv` set `Trạng thái duyệt` = '$trangthai' 
		   where (`Mã công việc` = '$id' AND ((`Mã người duyệt` = '$manguoinhan' AND `Mã người gửi` = '$manguoigui') OR (`Mã người duyệt` = '$manguoigui' AND `Mã người nhận` = '$manguoinhan')))
		   OR (`Mã công việc` IN (Select `MCV con` from `Quan hệ công việc` where (`MCV gốc` = '$id' AND `MCV con` != '$id') AND `Mã người nhận` = '$manguoigui'))";
	}
		   
		mysqli_query($con, $q1);
		mysqli_query($con, $q2);
	if ($manguoiduyet == $manguoigui){
		$check = 1;
	$q4 = "select `Mã người nhận`, `Mã người duyệt` from `gửi và nhận cv` where `Mã người gửi` = '$manguoinhan'";
	$manguoigui = $manguoinhan;
	}
	elseif ($manguoiduyet == $manguoinhan){
		$check = 2;
	$q4 = "select `Mã người gửi`, `Mã người duyệt` from `gửi và nhận cv` where `Mã người nhận` = '$manguoigui'";
	$manguoinhan = $manguoigui;
	}
	$res=mysqli_query ($con, $q4);
	
	//echo $q1.'<br>'.$q2.'<br>'.$q4;
	while($row=mysqli_fetch_assoc($res)){
		$dem++;
		if ($check == 1){
		$manguoinhan= $row['Mã người nhận'];
		$manguoiduyet= $row['Mã người duyệt'];
		}
		if ($check == 2){
		$manguoigui= $row['Mã người gửi'];
		$manguoiduyet= $row['Mã người duyệt'];
		}
		duyet($manguoigui, $manguoinhan, $manguoiduyet, $trangthai, $thoihan, $id, $dem);	
	}
	}	
	}
	
	if(isset($_POST['submit'])){
		//echo "submit form";
		$manguoinhan = $_POST['manguoinhan'];
		$manguoigui = $_POST['manguoigui'];
		$manguoiduyet = $_POST['manguoiduyet'];
		$id = $_POST['idcv'];
		$trangthai = $_POST['trangthai'];
		$thoihan = $_POST['thoihan'];
		
		duyet($manguoigui, $manguoinhan,$manguoiduyet, $trangthai, $thoihan, $id, $dem);
		
		include'../connection.php';
		$q3 = "Update `Gửi và nhận CV` set `Thời hạn` = '$thoihan' where `Mã công việc` = '$id'";
		mysqli_query($con, $q3);
		//echo $q1.'<br>'.$q2.' tt '.$trangthai;
		$con -> close();
		header("location:../?msg=Cập nhật trạng thái công việc thành công!&page=viewWorkDetails&manhan=$manguoinhan&data=$id");
		exit;			
	}
		ob_end_flush();
		exit;
?>
