<?php session_start();
	
include './connection.php';
$currentID = $_SESSION['idlogin'];
$idcv = $_REQUEST['data'];
$manhan = $_REQUEST['manhan'];
$currentPhong = $_SESSION['tenphongUser'];

$sql="select cv.`Tên công việc`, cv.`Mã công việc`, gvn.*, u2.`Họ tên` as `Tên người nhận`,
	  u1.`Họ tên` as `Tên người gửi`, cv.`Mô tả`, gvn.`Trạng thái duyệt`, gvn.`Mã người duyệt` from `user` u1 INNER JOIN `gửi và nhận cv` gvn
	  ON u1.`Mã nhân viên` = gvn.`Mã người gửi` INNER JOIN `Công việc` cv
	  ON gvn.`Mã công việc` = cv.`Mã công việc` INNER JOIN `user` u2
	  ON gvn.`Mã người nhận` = u2.`Mã nhân viên` where (u1.`Mã nhân viên` = '$currentID' OR u2.`Mã nhân viên` = '$currentID') 
	  AND cv.`Mã công việc` IN (Select `MCV con` from `Quan hệ công việc` where `MCV gốc` = '$idcv') AND gvn.`Mã người nhận` = '$manhan' Order by gvn.`Thời gian gửi` ASC";
	  
		$res=mysqli_query ($con, $sql) or die(mysqli_error());

?>         

            <div class="panel panel-default">
                <div class="panel-heading">
                    Danh sách liên quan đến Công việc gốc có MCV = <?php echo $idcv; ?>
                </div> 
                <div class="panel-body" align = "center">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                                <tr>                                    
                                    <th>STT</th>
									<th>Tên công việc</th>
                                    <th>Thời gian gửi</th>
									<th>Thời gian nhận</th>
									<th>Thời hạn</th>
									<th>Người gửi</th>
									<th>Người nhận</th>									
                                    <th>Mô tả</th>
									<th style = 'text-align: center;'>Tác vụ</th>
									<th style = 'text-align: center;'>Trạng thái</th>
                                </tr>
<?php
								$dem=1;
								$checkTarget=false;
								while($row=mysqli_fetch_assoc($res))
								{
								if ($checkTarget == false){
									$target = ($row['Mã người gửi'] == $currentID) ? $row['Mã người nhận'] : $row['Mã người gửi'];									
								}
								$checkTarget = true;
								$tennguoigui = $row['Tên người gửi'];
								$tennguoinhan = $row['Tên người nhận'];
								$manguoiduyet = $row['Mã người duyệt'];
								if ($row['Mã người gửi'] == $currentID){
									$tennguoigui = 'Bạn';
								}
								if ($row['Mã người nhận'] == $currentID){
									$tennguoinhan = 'Bạn';
								}
								if (empty($row['Thời gian nhận'])){
									$view = "<td width = '10%' style = 'text-align: center;'><a style ='color: red;' href=\"?page=viewWorkDetails&manhan=".$row['Mã người nhận']."&data=".$row['Mã công việc']."\">Xem</a></td>";
								} else {
									$view = "<td width = '10%' style = 'text-align: center; font-weight: bold;'><a href=\"?page=viewWorkDetails&manhan=".$row['Mã người nhận']."&data=".$row['Mã công việc']."\">Xem</a></td>";
								}									
								echo "</td><td>";
								echo $dem++;
								echo "</td><td>";
								echo $row['Tên công việc'];
								echo "</td><td>";
								echo $row['Thời gian gửi'];
								echo "</td><td>";
								if (empty($row['Thời gian nhận'])) echo "Chưa có"; else echo $row['Thời gian nhận'];
								echo "</td><td>";
								echo $row['Thời hạn'];
								echo "</td><td>";
								echo $tennguoigui;
								echo "</td><td>";
								echo $tennguoinhan;
								echo "</td><td>";
								echo $row['Mô tả'];
								echo "</td>";
								echo $view;								
								echo "<td width = '10%' style = 'text-align: center;'>".$row['Trạng thái duyệt']."</td></tr>";
								$checknhan = $row['Mã người nhận'];
								}

$sqls="select cv.`Tên công việc`, cv.`Mã công việc`, gvn.*, u2.`Họ tên` as `Tên người nhận`,
	  u1.`Họ tên` as `Tên người gửi`, cv.`Mô tả`, gvn.`Trạng thái duyệt`, gvn.`Mã người duyệt`, cv.`Thời hạn` from `user` u1 INNER JOIN `gửi và nhận cv` gvn
	  ON u1.`Mã nhân viên` = gvn.`Mã người gửi` INNER JOIN `Công việc` cv
	  ON gvn.`Mã công việc` = cv.`Mã công việc` INNER JOIN `user` u2
	  ON gvn.`Mã người nhận` = u2.`Mã nhân viên` where (u1.`Mã nhân viên` = '$currentID' OR u2.`Mã nhân viên` = '$currentID') 
	  AND cv.`Mã công việc` IN (Select `MCV con` from `Quan hệ công việc` where (`MCV gốc` = '$idcv' AND `MCV con` != '$idcv')) AND (gvn.`Mã người gửi` = '$checknhan' OR gvn.`Mã người nhận` = '$checknhan') Order by gvn.`Thời gian gửi` ASC";

	$res2=mysqli_query ($con, $sqls) or die(mysqli_error());
	
								$checkTarget=true;
								while($row=mysqli_fetch_assoc($res2))
								{
								if ($checkTarget == false){
									$target = ($row['Mã người gửi'] == $currentID) ? $row['Mã người nhận'] : $row['Mã người gửi'];									
								}
								$checkTarget = true;
								$tennguoigui = $row['Tên người gửi'];
								$tennguoinhan = $row['Tên người nhận'];
								$manguoiduyet = $row['Mã người duyệt'];
								if ($row['Mã người gửi'] == $currentID){
									$tennguoigui = 'Bạn';
								}
								if ($row['Mã người nhận'] == $currentID){
									$tennguoinhan = 'Bạn';
								}
								if (empty($row['Thời gian nhận'])){
									$view = "<td width = '10%' style = 'text-align: center;'><a style ='color: red;' href=\"?page=viewWorkDetails&manhan=".$row['Mã người nhận']."&data=".$row['Mã công việc']."\">Xem</a></td>";
								} else {
									$view = "<td width = '10%' style = 'text-align: center; font-weight: bold;'><a href=\"?page=viewWorkDetails&manhan=".$row['Mã người nhận']."&data=".$row['Mã công việc']."\">Xem</a></td>";
								}									
								echo "</td><td>";
								echo $dem++;
								echo "</td><td>";
								echo $row['Tên công việc'];
								echo "</td><td>";
								echo $row['Thời gian gửi'];
								echo "</td><td>";
								if (empty($row['Thời gian nhận'])) echo "Chưa có"; else echo $row['Thời gian nhận'];
								echo "</td><td>";
								echo $row['Thời hạn'];
								echo "</td><td>";
								echo $tennguoigui;
								echo "</td><td>";
								echo $tennguoinhan;
								echo "</td><td>";
								echo $row['Mô tả'];
								echo "</td>";
								echo $view;								
								echo "<td width = '10%' style = 'text-align: center;'>".$row['Trạng thái duyệt']."</td></tr>";
								}
								
								
?>
						
                        </table>
                    </div>
				<a href = "?page=createWork&id=<?php echo $idcv; ?>&target=<?php echo $target; ?>&maduyet=<?php echo $manguoiduyet; ?>">
				
				<button style ="" name="phanhoi" type="button"  class="btn btn-primary">Phản hồi</button>
				</a>
                </div>
            </div>
			
		<div align = "center">
		<form name="Myform" id="Myform" action= "congviec/comment.php" method="post" enctype="multipart/form-data" accept-charset="utf-8" width = "100%">
		<table>
		<tr>
		<td>
		<label Style = "padding-bottom: 12px;">Thêm comment:</label>
		</td>
		</tr>
	
		<tr>
		<td>
		<textarea id="comment" name = "comment" rows="3" cols="100">
		</textarea>
		<td>
		</tr>
		</table>
		<input type = "hidden" name = "id" value = "<?php echo $idcv; ?>">
		<input type = "hidden" name = "idnv" value = "<?php echo $currentID; ?>">
		<input type = "hidden" name = "manguoiduyet" value = "<?php echo $manguoiduyet; ?>">			
		<br>
		<button name="submit" type="submit"  class="btn btn-primary">Nhận xét</button>
		</form>
		<br>
		
		<?php 
		include './connection.php';
		$com1 = '<div width = "30%" style ="border: 3px solid #003D7E; padding: 10px; margin-right: 500px; margin-left: 500px; background-color: white;">
		<table>';
		$sqlcm = "select * from `Comment` cm INNER JOIN user ON cm.`Mã nhân viên` = user.`Mã nhân viên` Where `Mã công việc` = '$idcv'";		
		$rescm = mysqli_query ($con, $sqlcm);
		$rescm2 = mysqli_query ($con, $sqlcm);
		if ($rows2=mysqli_fetch_array($rescm2)){
			echo $com1;
		}
		while($rows=mysqli_fetch_array($rescm)){ 
			echo "<tr><td class ='info' style = ''>".$rows['Họ tên']."</td>
			<td class ='info' style = ''>".$rows['Nội dung']."</td></tr>";
		}
		
		$con -> close();
		?>
		</table>
		</div>
		</div>
        </div>		