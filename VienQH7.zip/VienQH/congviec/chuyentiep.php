<?php
	session_start();
	include_once 'connection.php'; 

	if(isset($_POST['submit'])){
		//echo "submit form";

		$trangthai = $_POST['trangthai'];
		$MaGoc = $_POST['idGoc'];
		$thoihan = $_POST['thoihan'];
		//$noinhan = $_POST['noinhan'];
		$idcongviec = $_POST['idcongviec'];
		$ngaytaocv = $_POST['ngaytaocv'];
		$countSend = $_POST['send'];
		$capdo = 1;
		$manguoigui = $_SESSION['idlogin'];
		$manguoiduyet = $manguoigui;
		$maphonggui = $_SESSION['MaphongUser'];
		for ($i=0; $i<=$countSend; $i++){
			echo 'dong 20 count send = '.$countSend.'<br>';
			$j = ($i==0) ? '' : $i;
			$noi = 'noinhan'.$j.'';
			$noinhan[$i] = $_POST[$noi];
			$noiduyet[$i] = $manguoiduyet;
				
			$noi_ = $noinhan[$i];
			$sqls = mysqli_query ($con, "select * from user where user.`Mã nhân viên` = '$noi_'") or die(mysqli_error());
			while($rows=mysqli_fetch_assoc($sqls)){
			$maphongnhan[$i] = $rows['Mã phòng'];
			}
		}

		for ($i=0; $i<=$countSend; $i++){
			for ($j=$i+1; $j<=$countSend; $j++){
				$m = ($i==0) ? '' : $i;
				$n = ($j==0) ? '' : $j;
			$attm = 'noinhan'.$m.'';
			$attn = 'noinhan'.$n.'';
			if ($_POST[$attm] == $_POST[$attn]){
				header('location:../?msg=Người nhận trùng nhau!&page=createWork&id='.$MaGoc.'&idcv='.$idcongviec.'&ngaytao='.$ngaytaocv.'&type=chuyentiep');
				exit;
				break;
			}
		}
		}
		$con -> close();
		
		$con = mysqli_connect('localhost', 'root', '12345678') or die(mysqli_error($con));
		$db = mysqli_select_db($con,'quanlyvanban');
		$con -> autocommit(FALSE);

		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiangui = date("Y-m-d H:i:s", time());
		$getGuiNhan = True;
		for ($k=0; $k<=$countSend && $getGuiNhan; $k++){
			$m = ($k==0) ? '' : $k;							
		$GuiNhan = "INSERT INTO `gửi và nhận cv` (`Mã công việc`,`Mã người gửi`, `Mã người nhận`, `Mã người duyệt`, `Thời gian gửi`,`Thời hạn`, `Mã phòng gửi`, `Mã phòng nhận`, `Trạng thái duyệt`) ".
					"VALUES ('$idcongviec', '$manguoigui', '$noinhan[$k]', '$noiduyet[$k]', '$thoigiangui', '$thoihan', '$maphonggui', '$maphongnhan[$k]', '$trangthai' )";
		$getGuiNhan = mysqli_query ($con,$GuiNhan);
		}
		if ($getGuiNhan){
			$con -> commit();
			$con -> close();
			header("location:../?page=listWorkDetails&msg=Chuyển tiếp công việc thành công!&manhan=".$noinhan[0]."&data=".$idcongviec);
			//echo $qry.'<br>'.$sql.'<br>'.$query;
			exit();	
		} else {
			$con -> rollback();
			$con -> close();
			header('location:../?msg=Người nhận trùng nhau!&page=createWork&id='.$MaGoc.'&idcv='.$idcongviec.'&ngaytao='.$ngaytaocv.'&type=chuyentiep');
			//echo $qry.'<br>'.$sql.'<br>'.$query;
			exit();
		}	
	
	}
	
?>
