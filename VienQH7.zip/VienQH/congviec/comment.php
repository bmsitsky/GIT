<?php
	session_start();
	ob_start();
    include_once '../connection.php';
	if(isset($_POST['submit'])){
		//echo "submit form";
		$cm = $_POST['comment'];
		$id = $_POST['id'];
		$idnv = $_POST['idnv'];
		if (isset($_POST['comment']) && isset($_POST['id'])){
			$q1 = "Insert into `Comment` (`Mã nhân viên`, `Mã công việc`, `Nội dung`) values ('$idnv', '$id','$cm')";			
			mysqli_query($con, $q1);

		}
		//echo $q1.'<br>'.$q2.' tt '.$trangthai;
		header("location:../?msg=Thêm nhận xét thành công!&page=listWorkDetails&data=$id");
		exit;			
	}
		ob_end_flush();
		exit;
?>
