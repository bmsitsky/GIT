<?php
	session_start();
	$tenvanban = $_SESSION['tenvanban'];
	$sohieu = $_SESSION['sohieu'];
	$trichyeu = $_SESSION['trichyeu'];
	$loaivanban = $_SESSION['loaivanban'];
	$ngaytao = $_SESSION['ngaytao'];
	$bancung = $_SESSION['bancung'];
	$maphonguser = $_SESSION['MaphongUser'];
	$noinhan = $_SESSION['noinhan'];
	$currentID = $_SESSION['idlogin'];
	//$maphongnhan = $_SESSION['maphongnhan'];
?>
<div class="uplaoder-container__container___1JPbU" style = "width: 100%; padding-top: 60px;">
<form name="Myform" id="Myform" action= "upload/uploadProcess.php" method="post" enctype="multipart/form-data" accept-charset="utf-8" width = "100%">
<div class="upload-styles__container___3zZBa" style ="border: 8px solid #003D7E;
  padding: 20px;
  margin: 20px;"><br>
<h1 class="upload-styles__title___4kBN1" align = "center" style = "padding-right:85px;">[Văn thư] Nhập văn bản</h1>
<div class="upload-styles__dialog___69i7A">


<table width = "100%" >

  <tr>
    <td width ="10%">
		<div class="upload-table__uploadButton___3gEmR">
		<div class="react-fine-uploader-file-input-container button-uploader__fileInput___22I4V" style="display: inline-block; position: relative;">
		<button class="MuiButtonBase-root MuiButton-root MuiButton-contained button__button___3kagF MuiButton-containedPrimary" onclick ="onClickHandler('add')" tabindex="0" type="button" style ="bottom:0;">
		<span class="MuiButton-label">Thêm mới</span>
		<span class="MuiTouchRipple-root">
		</span>
		</button>
		<input id="703c5a21-b86b-4842-95d4-7a06c4ac7fc0" onchange ="onClickHandler('add')" name ="add" type="file" style="bottom: 0px; height: 100%; left: 0px; margin: 0px; opacity: 0; padding: 0px; position: absolute; right: 0px; top: 0px; width: 100%;">
		
		</div>
		</div>
			
	</td>
    <td style = "padding-left:35px;" width = "10%">
		<div class="upload-styles__inputWrapper___AY1Wy">
		<label for="product-name" class="upload-styles__label___1DnuM">Tên văn bản: </label>
		</div>
	</td>
	<td width = "60%">
		<input class="upload-styles__input___1zxpo" name = "tenvanban" id="tenvanban" type="text" value ="<?php echo $tenvanban; ?>" required="">
	</td>
    <td style = "padding-left:35px;">Số hiệu</td>
	<td style = "padding-left:35px; padding-right:25px;">
		<input class="upload-styles__input___1zxpo" name = "sohieu" id="sohieu" type="text" value ="<?php echo $sohieu; ?>" required="">
	</td>
  </tr>

  <tr>
    <td style = "padding-left:12px; padding-right:12px;">
	<!--<img src="" id="out" />-->
	<div class="progress">
    <div class="progress-bar progress-bar-striped active" id="add" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="color: #F5F5F5; width:0%;">
    </div>
	</div>
	</td>
    <td style = "padding-left:35px;">
		<div class="upload-styles__inputWrapper___AY1Wy">
		<label for="product-name" class="upload-styles__label___1DnuM">Trích yếu: </label>
		</div>
	</td>
	<td>
		<input class="upload-styles__input___1zxpo" name = "trichyeu" id="trichyeu" type="text" value ="<?php echo $trichyeu; ?>" required="">
	</td>
    <td style = "padding-left:35px;">Loại văn bản</td>
	<td style = "padding-left:35px; padding-right:25px;">
		<input class="upload-styles__input___1zxpo" name = "loaivanban" id="loaivanban" type="text" value ="<?php echo $loaivanban; ?>" required="">
	</td>
  </tr>
  <tr>
	<td colspan ='2' style = "padding-left:10px;">
	<input type ="hidden" name = "noinhan" value = "<?php echo "vanthu" ?>">
	
	</td>
    <td>
		<div class="upload-table__uploadButton___3gEmR">
		<div class="react-fine-uploader-file-input-container button-uploader__fileInput___22I4V" style="display: inline-block; position: relative;">
		<button class="MuiButtonBase-root MuiButton-root MuiButton-contained button__button___3kagF MuiButton-containedPrimary" onclick ="onClickHandler('attach')" ( tabindex="0" type="button" style ="bottom:0;">
		<span class="MuiButton-label">Đính kèm</span>
		<span class="MuiTouchRipple-root">
		</span>
		</button>
		<input id="1ec23130-dbd6-4a7f-812e-f8737119a590" onchange ="onClickHandler('attach')" class="react-fine-uploader-file-input" name = "attach" type="file" style="bottom: 0px; height: 100%; left: 0px; margin: 0px; opacity: 0; padding: 0px; position: absolute; right: 0px; top: 0px; width: 100%;">
		
		</div>
		</div>
	</td>
    <td style = "padding-left:35px;">Nơi lưu bản cứng</td>
	<td style = "padding-left:35px; padding-right:25px;">
		<input class="upload-styles__input___1zxpo" name = "bancung" type="text" value="<?php echo $bancung; ?>" required=""/>
	</td>
  </tr>
  <tr>
	<td>	
	
	</td>
	<td></td>
	<td style = "padding-left:390px; padding-right:390px;">
	<div class="progress">
    <div class="progress-bar progress-bar-striped active" id="attach" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="color: #F5F5F5; width:0%;">
    </div>
	</div>
	</td>
    <td style = "padding-left:35px;">
	</td>
	<td>
	
	</td>
  </tr>
  <tr>
	<td></td>
	<td></td>
	<td></td>
    <td style = "padding-left:35px;">Ngày tạo</td>
	<td style = "padding-left:35px; padding-right:25px;">
		<input class="upload-styles__input___1zxpo" name = "ngaytao" type="date" value="<?php  if (isset($_SESSION['ngaytao'])) echo $_SESSION['ngaytao'];
																								else echo date('Y-m-d'); ?>" required=""/>
	</td>
  </tr>
<tr>
<td></td><td></td></td><td>
<td style = "padding-left:25px;">
<input type ="hidden" name = "vanthu" value ="True"/>
<input name="submit" type="submit" class="MuiButtonBase-root MuiButton-root MuiButton-contained upload-styles__greenButton___2jueh button__button___3kagF MuiButton-containedPrimary" id="upload" value=" Lưu trữ ">
</td>
</td><td>
<tr>
</table>


</div>
</div>
<br><br><br><br><br><br><br><br><br><br>
</form>
</div>