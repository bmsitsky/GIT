<?php
	session_start();
	$id = $_SESSION['idlogin'];
	$rulelogin = $_SESSION['rule'];
	$idcv = $_REQUEST['data'];
	$currentPhong = $_SESSION['tenphongUser'];
	$checkDuyet = False;
	if ($type == 'sent'){
		$title = 'Đã gửi đến';
	} else {
		$title = 'Được gửi bởi';
	}
	$sql_ = "select fdk.`Mã File`, fdk.`Tên file`, fdk.`Loại file`, fdk.`Nơi lưu` as noiluu, 
								cv.*, qhcv.`MCV gốc`, u1.`Họ tên` as `Tên người nhận`, u2.`Họ tên` as `Tên người gửi`, 
								pb.`Tên phòng` as `Tên phòng nhận`, pb2.`Tên phòng` as `Tên phòng gửi`, gvn.* 
								from `Phòng ban` pb INNER JOIN user u1	
								ON pb.`Mã phòng` = u1.`Mã phòng` INNER JOIN `gửi và nhận cv` gvn								
								ON u1.`Mã nhân viên` = gvn.`Mã người duyệt` INNER JOIN user u2 
								ON gvn.`Mã người gửi` = u2.`Mã nhân viên` INNER JOIN `Phòng ban` pb2
								ON pb2.`Mã phòng` = u2.`Mã phòng` INNER JOIN `Công việc` cv
								ON gvn.`Mã công việc` = cv.`Mã công việc` INNER JOIN `Quan hệ công việc` qhcv
								ON cv.`Mã công việc` = qhcv.`MCV con` LEFT JOIN `Đính kèm cv` dkcv
								ON cv.`Mã công việc` = dkcv.`Mã công việc` LEFT JOIN `file đính kèm` fdk
								ON dkcv.`Mã File` = fdk.`Mã File` Where cv.`Mã công việc` = '$idcv' order by gvn.`Thời gian gửi`";
								
	$qry_ = mysqli_query ($con, $sql_);							
    $qry = mysqli_query ($con, $sql_);
	
	if ($row_ = mysqli_fetch_array($qry_)){
		if ($row_['Mã người gửi'] == $id){
			$checkDuyet = True;
		}
	}
								
    while($row = mysqli_fetch_array($qry)){
		$macv = $row['Mã công việc'];
		$maGoc = $row['MCV gốc'];
        $tencv = $row['Tên công việc'];
		$nguoigui = $row['Tên người gửi'];
		$nguoinhan = $row['Tên người nhận'];
		$trangthai = $row['Trạng thái']; //sohieu
		$mota = $row['Mô tả'];
		$ngaytao = $row['Ngày tạo'];
		$noisanxuat = $row['Nơi sản xuất']; //loaivanban
		$loaifile = $row['Loại File'];		
		$thoihan = $row['Thời hạn']; //bancung
		$noinhan = $row['Tên phòng nhận'];
		$noigui = $row['Tên phòng gửi'];
		$thoigiangui = $row['Thời gian gửi'];
		$thoigiannhan = $row['Thời gian nhận'];
		$tendinhkem = $row['Tên file'];
		$loaidk = $row['Loại file'];
		$saveVB = $row['Nơi lưu'];
		$saveDK = $row['noilưu'];
		$idfile = $row['Mã File'];
		
		$tennguoigui = $row['Tên người gửi'];
		$tennguoinhan = $row['Tên người nhận'];
		if ($row['Mã người gửi'] == $currentID){
			$tennguoigui = 'Bạn'; $target = $row['Mã người nhận'];
		}
		if ($row['Mã người nhận'] == $currentID){
			$tennguoinhan = 'Bạn'; $target = $row['Mã người gửi'];
		}
		
		if ($noinhan == $currentPhong){
		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiannhan = date("Y-m-d H:i:s", time());
		$queryTime = "UPDATE `gửi và nhận cv` SET `Thời gian nhận` = '$thoigiannhan' WHERE `Mã công việc` = '$macv'";
		$qryTime = mysqli_query ($con, $queryTime);
	}
		
		if ($noinhan != $currentPhong){
			$noinhan = 'Phòng '.$noinhan;
		} else $noinhan = $nguoinhan;
		if ($noigui != $currentPhong){
			$noigui = 'Phòng '.$noigui;
		} else $noigui = $nguoigui;
    }
?>
<script type="text/javascript" src="assets/js/Registration.js"></script>

<h2 style="text-align: center; padding-right:20px;">Thông tin chi tiết công việc</h2><br>
<form name="Myform" id="Myform" action="congviec/update.php" method="post">
    <table align = "center" id="viewdata">
			<tr>
			<td colspan='2' style="text-align: left; font-size: 30px;">
				
			</td>
			</tr>
            <tr>
                <td class ="info">Tên công việc</td>
				<td class ="info"><?php echo $tencv; ?></td>
            </tr> 
			<tr>			
                <td class ="info">Trạng thái</td>   
				<!--td class ="info"><?php echo $trangthai; ?></td-->
				<?php
								$s = " selected";
								$s1 = $s2 = $s3 = $s4 = $s5 = '';
								if ($trangthai == 'Giao việc') $s1 = $s;
								if ($trangthai == 'Đang tiến hành') $s2 = $s;
								if ($trangthai == 'Đã xong') $s3 = $s;
								if ($trangthai == 'Phê duyệt') $s4 = $s;
								if ($trangthai == 'Hoàn thành') $s5 = $s;
								
								echo "	<td>
										<select style='width: 150px; height: 32px;' name='trangthai' id='trangthai' onkeydown='HideError()'>
										<option value='Giao việc' $s1>Giao việc</option>
										<option value='Đang tiến hành' $s2>Đang tiến hành</option>
										<option value='Đã xong' $s3>Đã xong</option>";
								if ($checkDuyet == True)
									echo"<option value='Phê duyệt' $s4>Phê duyệt</option>
										<option value='Hoàn thành' $s5>Hoàn thành</option>
										";
									echo "</select>";
				?>
				
			</tr>
            <tr> 
                <td class ="info">Mô tả công việc</td>
				<td class ="info"><?php echo $mota; ?></td>
            </tr> 
			<tr>
                <td class ="info">Ngày tạo</td> 
				<td class ="info"><?php echo $ngaytao; ?></td>
            </tr> 
			<tr>
                <td class ="info">Nơi sản xuất</td>  
				<td class ="info"><?php echo $noisanxuat; ?></td>
			</tr>
			<tr>
                <td class ="info">Thời hạn</td>
				<td class ="info"><?php echo $thoihan; ?></td>
            </tr> 	
			<tr>			
				<td class ="info">Người gửi</td>
				<td class ="info"><?php echo $tennguoigui; ?></td>
            </tr>
			<tr>			
				<td class ="info">Người nhận</td>
				<td class ="info"><?php echo $tennguoinhan; ?></td>
            </tr>
			<tr>			
				<td class ="info">Thời gian gửi</td>
				<td class ="info"><?php echo $thoigiangui; ?></td>
            </tr> 
			<tr>			
				<td class ="info">Thời gian nhận</td>
				<td class ="info">				
				<?php 
				if (!empty($thoigiannhan))
				echo $thoigiannhan; 
				else 
				echo "Chưa có";
				?></td>
            </tr> 
			<tr>			
				<td class ="info">Tải công việc</td>
				<td class ="info"><a align = "center" href="congviec/download.php?type=congviec&data=<?php echo $idcv; ?>">Download </a>(.<?php echo  $loaifile;?>)</td>
			</tr>
				<?php $downfile='';
				if (!empty($idfile)){
				$downfile = 
				'<tr> 				
				<td class ="info">Tải tệp đính kèm</td>
				<td class ="info"><a align = "center" href="congviec/download.php?type=file&data='.$idfile.'">Download </a>(.'.$loaidk.')</td>
				</tr>';
				} 
				echo $downfile;
				?>
			<tr>
                <td style = "text-align: center; padding-right:50px;">	
				<input type = "hidden" name = "id" value = "<?php echo $maGoc; ?>">				
				<a href = "?page=createWork&id=<?php echo $maGoc; ?>&target=<?php echo $target; ?>">
				<input style ="height: 42px;" id="update" type="button" name="phanhoi" value="Phản hồi" />
				</a>
				</td>
				<td> <input style =" text-align: center; height: 42px;" id="update" type="submit" name="submit" value="Update" /> </td>
	
            </tr>              
    </table>
	
</form>

