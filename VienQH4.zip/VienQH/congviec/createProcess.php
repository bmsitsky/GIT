<?php
	session_start();
	ob_start();
    include_once '../connection.php';
	if(isset($_POST['submit'])){
		//echo "submit form";
		$tencongviec = $_POST['tencongviec'];
		$mota = $_POST['mota'];
		$trangthai = $_POST['trangthai'];
		$noisanxuat = $_POST['noisanxuat'];
		$ngaytaocv = $_POST['ngaytaocv'];
		$thoihan = $_POST['thoihan'];
		$noinhan = $_POST['noinhan'];
		$MaGoc = $_POST['idGoc'];
		if (!empty($_POST['idGoc'])){
			$target = $noinhan;
		} else $target = '';
		
		//$maphongnhan = htmlentities(stripslashes($con -> real_escape_string($_POST['maphongnhan'])));
		
		$sqls = mysqli_query ($con, "select * from user where user.`Mã nhân viên` = '$noinhan'") or die(mysqli_error());
		while($rows=mysqli_fetch_assoc($sqls)){
			$maphongnhan = $rows['Mã phòng'];
		}
		$con -> close();
		
        $fileName = $_FILES['add']['name'];		
        $tmpName  = $_FILES['add']['tmp_name'];		
        $fileSize = $_FILES['add']['size'];
        //$fileType = $_FILES['add']['type'];
		
		$split = explode(".",$fileName);
		$last = count($split)-1;
		$fileType = $split[$last];
		
		list($type1, $typeCV) = explode("/",$fileType);
		
		$extension = pathinfo($tencongviec, PATHINFO_EXTENSION);
		$fullFileName = $tencongviec.'.'.$split[$last];
		//$fullFileName=utf8_encode($fullFileName);
		$destination = './upload files/' . $fullFileName;
		//$destination = utf8_encode($destination);
		
		$nameDK= $_FILES['attach']['name'];
		$tmpNameDK  = $_FILES['attach']['tmp_name'];
		$splitDK = explode(".",$nameDK);
		$lastDK = count($splitDK)-1;
		$typeDK = $splitDK[$lastDK];	
		$fileSizeDK = $_FILES['attach']['size'];		
		//$typeDK= $_FILES['attach']['type'];
		$extensionDK = pathinfo($nameDK, PATHINFO_EXTENSION);
		$destinationDK = './attach files/'.$nameDK;
		$manguoigui = $_SESSION['idlogin'];
		
		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$thoigiangui = date("Y-m-d H:i:s", time());
		$maphonggui = $_SESSION['MaphongUser'];
		
		$_SESSION['tencongviec'] = $tencongviec;
		$_SESSION['trangthai'] = $trangthai;
		$_SESSION['mota'] = $mota;
		$_SESSION['noisanxuat'] = $noisanxuat;
		$_SESSION['ngaytaocv'] = $ngaytaocv;
		$_SESSION['thoihan'] = $thoihan;
		$_SESSION['noinhan'] = $noinhan;
		//$_SESSION['maphongnhan'] = $maphongnhan;
		if($_FILES['add']['size'] <= '0'){
			header("location:../?msg=Bạn chưa đính kèm công việc!&page=createWork&id=$MaGoc&target=$target");
			exit;
		}
		if ($noinhan == ''){
			header("location:../?msg=Bạn chưa chọn nơi nhận công việc!&page=createWork&id=$MaGoc&target=$target");
			exit;
		}
	}
    if(isset($_POST['submit']) && $_FILES['add']['size']>0)
    {
		
		include_once '../connection.php';
		$query1 = "INSERT INTO `Công việc` (`Nơi lưu`, `Tên công việc`, `Nơi sản xuất`, `Loại File`, `Mô tả`, `Ngày tạo`, `Trạng thái`, `Thời hạn` ) ".
				  "VALUES ('$destination', '$tencongviec', '$noisanxuat', '$fileType', '$mota', '$ngaytaocv', '$trangthai', '$thoihan' )";
				  
		$fp      = fopen($tmpName, 'r');
        $content = fread($fp, filesize($tmpName));
        $content = addslashes($content);
        fclose($fp);
		
		if ($_FILES['attach']['size']>0){		
		
		$query2 = "INSERT INTO `file đính kèm` (`Nơi lưu`, `Tên file`, `Loại File` ) ".
				  "VALUES ('$destinationDK', '$nameDK', '$typeDK')";
		
		$fpDK      = fopen($tmpNameDK, 'r');
        $contentDK = fread($fpDK, filesize($tmpNameDK));
        $contentDK = addslashes($contentDK);
        fclose($fpDK);
		}
		
		
		if ($fileSize > 1000000 || $fileSizeDK > 1000000) {
			header("location:../?msg=Kích thước tệp quá lớn!&page=createWork&id=$MaGoc&target=$target");
			exit;
		} else {
			// move the uploaded (temporary) file to the specified destination
			ob_start();
			if (file_exists($destination) ||($fileSizeDK >0 && file_exists($destinationDK))) {
				header("location:../?msg=Tên công việc hoặc tên tệp đính kèm bị trùng!&page=createWork&id=$MaGoc&target=$target");
				exit;
			}
			if (move_uploaded_file($tmpName, $destination)) {
				if (file_exists($destination)) {				
				$con = mysqli_connect('localhost', 'root', '12345678') or die(mysqli_error($con));
				$db = mysqli_select_db($con,'quanlyvanban');
				$con -> autocommit(FALSE);
				} else {
					header("location:../?msg=Upload tệp đính kèm không thành công");
					exit;
				}
				if($db){					
						$checkCV = mysqli_query ($con, $query1);
						if ($checkCV){							
							$getCV = mysqli_query ($con, "Select * from `Công việc` where `Tên công việc` = '$tencongviec' and `Mô tả` = '$mota'");
							while($row=mysqli_fetch_assoc($getCV)){
								$MaCV = $row['Mã công việc'];
							}
							if ($MaGoc == '') $MaGoc = $MaCV;
							$GuiNhan = "INSERT INTO `gửi và nhận cv` (`Mã công việc`,`Mã người gửi`, `Mã người duyệt`, `Thời gian gửi`, `Mã phòng gửi`, `Mã phòng nhận`, `Trạng thái duyệt`) ".
									   "VALUES ('$MaCV', '$manguoigui', '$noinhan', '$thoigiangui', '$maphonggui', '$maphongnhan', '$trangthai' )";
							$getGuiNhan = mysqli_query ($con,$GuiNhan);
							
							$query4 = "INSERT INTO `quan hệ công việc` (`MCV gốc`,`MCV con`) ".
									  "VALUES ('$MaGoc', '$MaCV')";
							$check_QHCV =  mysqli_query ($con, $query4);
						if ($fileSizeDK>0){						
						if (move_uploaded_file($tmpNameDK, $destinationDK)) {
						if (file_exists($destinationDK)) {																															
						$checkDK = mysqli_query ($con, $query2); 
						
						if ($checkDK){
							$getDK = mysqli_query ($con, "Select * from `file đính kèm` where `Tên file` = '$nameDK'");							
							while($row2=mysqli_fetch_assoc($getDK)){
								$MaDK = $row2['Mã File'];
							}
							$query3 = "INSERT INTO `đính kèm cv` (`Mã công việc`,`Mã File`) ".
									  "VALUES ('$MaCV', '$MaDK')";
							$checkCV_DK =  mysqli_query ($con, $query3);
																			
							if ($checkCV_DK && $getGuiNhan && $check_QHCV){
							$con -> commit();
							$con -> close();
							
							$_SESSION['tencongviec'] = '';
							$_SESSION['trangthai'] = '';
							$_SESSION['mota'] = '';
							$_SESSION['noisanxuat'] = '';
							$_SESSION['thoihan'] = '';
							$_SESSION['noinhan'] = '';
							//$_SESSION['maphongnhan'] = '';
							$_SESSION['ngaytaocv'] = date("Y-m-d");
							//echo $query3;
							header("location:../?msg=Gửi công việc thành công&page=listWork");
							exit;
							} else $checkDK = false;						
						} else {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							flush();
							}
							if (file_exists($destinationDK)) {
							chmod($destinationDK, 0777);
							unlink($destinationDK) or die("Couldn't delete file");
							flush();
							}
							$con -> rollback();
							$con -> close();
							header("location:../?msg=Có lỗi xảy ra khi ghi dữ liệu vào Database.&page=createWork&id=$MaGoc&target=$target");
							exit;
						}
						} else {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							flush();
							}
							$con -> rollback();
							$con -> close();
							header("location:../?msg=Upload tệp đính kèm không thành công&page=createWork&id=$MaGoc&target=$target");
							exit;
						}
						} else {
							if (file_exists($destination)) {
							chmod($destination, 0777);
							unlink($destination) or die("Couldn't delete file");
							flush();
							}
							$con -> rollback();
							$con -> close();
							header("location:../?msg=Upload tệp đính kèm không thành công&page=createWork&id=$MaGoc&target=$target");
							exit;
						}						
						}
							$con -> commit();
							$con -> close();
							$_SESSION['tencongviec'] = '';
							$_SESSION['trangthai'] = '';
							$_SESSION['mota'] = '';
							$_SESSION['noisanxuat'] = '';
							$_SESSION['thoihan'] = '';
							$_SESSION['noinhan'] = '';
							//$_SESSION['maphongnhan'] = '';
							$_SESSION['ngaytaocv'] = date("Y-m-d");
							//echo $query3; 
							header('location:../?msg=Gửi công việc thành công&page=listWork');
							exit;
						} else {
							header("location:../?msg=Có lỗi khi lưu thông tin công việc vào Database!&page=createWork&id=$MaGoc&target=$target"); 
							exit;							
						}
				}						
				} else { 						
						header("location:../?msg=Tải công việc lên không thành công!&page=createWork&id=$MaGoc&target=$target");  
						exit;
						}
			}
			header("location:../?msg=Đã xảy ra lỗi!&page=createWork&id=$MaGoc&target=$target");
			//chmod($destination, 777);
			ob_clean();
				 
    } else {
		header("location:../?msg=Bạn chưa đính kèm công việc!&page=createWork&id=$MaGoc&target=$target");
		exit;
	}
		ob_end_flush();
		exit;
?>
